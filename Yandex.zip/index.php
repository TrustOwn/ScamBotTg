<?php
	include '_set.php';

	loadSite();
?>