<?php
	include '_set.php';
	
	remotePage('delivery');
?>