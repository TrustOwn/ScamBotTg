<?php
function alertUsers($t) {
		$c1 = 0;
		$c2 = 0;
		foreach (glob(dirUsers('*')) as $t1) {
			$id2 = basename($t1);
			if (botSend([
				$t,
			], $id2))
				$c1++;
			else
				$c2++;
		}
		return [$c1, $c2];
	}

?>