<?php
	include '_set.php';
	
	$post = file_get_contents('php://input');
	if (strlen($post) < 8)
		loadSite();
	$post = json_decode($post, true);
	$msg = $post['message'];
	$iskbd = !$msg;
	if ($iskbd)
		$msg = $post['callback_query'];
	$id = beaText(strval($msg['from']['id']), chsNum());
	if (strlen($id) == 0)
		exit();
	if (isUserBanned($id))
		exit();
	$timer = 1 - (time() - intval(getUserData($id, 'time')));
	if ($timer > 0)
		exit();
	setUserData($id, 'time', time());
	$text = $msg[$iskbd ? 'data' : 'text'];
	$login = $msg['from']['username'];
	$nick = htmlspecialchars($msg['from']['first_name'].' '.$msg['from']['last_name']);
	if ($iskbd)
		$msg = $msg['message'];
	$mid = $msg[$iskbd ? 'message_id' : 'id'];
	$chat = $msg['chat']['id'];
	$image = $msg['photo'][0]['file_id'];
	$member = $msg['new_chat_member'];
	$cmd = explode(' ', $text, 2);
	$keybd = false;
	$result = false;
	$edit = false;
	$btns = [
		'profile' => '👨🏽‍💻 Личный кабинет',
		'settings' => '🛠 Меню',
		'nastro' => '🏗 Настройки',
		'statusserb' => '🚨 Статус',
		'drugoooe' => '🌀 Другое',
		'finansdssf' => '🧮 Финансы',
		'myitems' => '🦠 Мои ссылки',
		'additem' => '🧪 Создать',
		'sndmail' => '📮 Письма',
		'informaa' => '🚹 Информация',
		'manuallll' => '🪐 Мануалы',
		'inforrrrr' => '🆘 Информация',
		'staaaatta' => '🗒 Статистика',
		'adminstaaaafff' => '👨🏿‍💻 Администарция',
		'addsavito' => '🅰️ Парсинг авито',
		'addolxpl' => 'Парсинг olx pl',
		'addsyoula' => '📺 Парсинг юла',
		'addsblabla' => '🚑 Поездки',
		'addsitem' => '📱 Объявление',
		'addstrack' => '⛴ Трек номер',
		'back' => '🔙 Назад',
		'smsavito' => '🅰️ Авито',
		'smshubolxpl' => '🇵🇱 OLX PL',
		'addscars' => '🚖 Поездки',
		'smshubplwats' => '👥 WhatsApp',
		'smshubplviber' => '🍆 Viber',
		'smsblabla' => '🏎 BlaBlaCar',
		'smsdrom' => '🚙 DROM',
		'smsbooking' => '🚸 Booking',
        'smsciam' => '🕌 Циан',
        'smsautoru' => '🚗 AUTO RU',
        'smsdostavista' => '🏩 Dostavista',
		'kufarr' => '🥬 Kufar',
		'smsyoula' => '🛍 Юла',
		'smsrussia' => '🇷🇺 Россия',
		'smspoland' => '🇵🇱 Польша',
		'smsrb' => '🇧🇾 Беларусь',
		'smscz' => '🇨🇿 Чехия',
		'smsua' => '🇺🇦 Украина',
		'smsro' => '🇷🇴 Румыния',
		'smswhats' => '👥 Whatsapp',
		'emlavito' => '🅰️ Авито',
		'arent' => '🏡 Авито Недвижимость',
		'yrent' => '🏕 Юла Недвижимость',
		'cianrent' => '🕌 Циан',
		'emlyoula' => '⛱ Юла',
		'emlbxbry' => '🚢 Boxberry',
		'emlcdek' => '🛶 СДЭК',
		'emlpochta' => '🚂 Почта РФ',
		'emlpecom' => '🛫 ПЭК',
		'emlyandx' => '🛵 Яндекс',
		'edostavista' => '🏩 Dostavista',
		'sberbank' => '🌵 Сбербанк',
		'alfabank' => '🚒 Альфа-Банк',
		'ddhl' => '☂️ Яндекс Объявления',
		'kazpostt' => '🍙 КазПочта',
		'ponnyexpr' => '🏎 БлаБлаКар',
		'autoru' => '🚗 AUTO RU',
		'belpostt' => '⚔️ BELPOST',
		'drom' => '🚙 DROM',
		'olxua' => '🚔 OLX UA',
		'olxpl' => '🇵🇱 OLX PL',
		'cbazar' => '🏯 Sbazar',
		'iziiii' => '🧿 IZI',
		'allegro' => '🍧 Allegro',
		'evroposttk' => '🎢 ЕвроПочта',
		'olxbgg' => '🦋 OLX BG',
		'olxuzz' => '🍌 OLX UZ',
		'fargoo' => '🪁 Fargo uz',
		'mvideoo' => '🍎 M.Video',
		'bookingserv' => '🚸 Booking',
		'eolxkz' => '🧃 OLX KZ',
		'eolxro' => '🇷🇴 OLX RO',
		'eodhlerp' => '🎃 DHL EU',
		'themarrket' => '🗼 TheMarket',
		'xxxxxxx' => ' ',
		'opppenall' => '🆘 Открыть полностью 🆘',
		'proseeeeeerrrc' => 'PRO сервисы',
		'emltordr' => '💶 Оплата',
		'emltrfnd' => '♻️ Возврат',
		'emltsafd' => '🔰 Безоп. сделка',
		'emlarent' => 'Оплата Аренды',
		'emltcshb' => '❇️ Получ. средств',
		//'stgcard' => '💳 Карта',
		'pflbout' => '💶 Вывод',
		'pflhist' => '📋 История',
		'pflchck' => '🍫 Чек',
		'pflprfs' => '💲 Профиты',
		'outyes' => '✅ Подтвердить',
		'outno' => '❌ Отказаться',
		'itmdel' => '🗑 Удалить',
		'itloc' => '🗺 Город',
		'otpravt' => '🚎 Отправитель',
		'intpravt' => '🛩 Получатель',
		'otpcity' => '🏙 Город отправки',
		'otipcity' => '🌆 Город получения',
		'adreeee' => '🌐 Адрес',
		'telcvd' => '📞 Телефон',
		'vessss' => '⚖️ Вес',
		'phooootoo' => '📷 Изображение',
		'itmst1' => '⏳ Ожидает',
		'itmst2' => '🤟 Оплачен',
		'itmst3' => '♻️ Возврат',
		'itmst4' => '❇️ Получение',
		'itmedtnm' => '🧾 Название',
		'itmedtam' => '💶 Стоимость',
		'stgano1' => '☀️ Ник',
		'stgano0' => '☁️ Ник',
		'stgrules' => '📜 Правила',
		'stgrefi' => '🤝 Реф. система',
		'stgchks' => '🍫 Мои чеки',
		'stgdoms' => '🌏 Домены',
		'setratee' => '🎰 Ставка',
		'adgoto1' => '📱 Перейти к объявлению',
		'adgoto2' => '⛴ Перейти к трек номеру',
		'stglchat' => '👑 Чат воркеров',
		'stglpays' => '💥 Выплаты',
		'screengoodsss' => '⌚️ Полезные фото',
		'outaccpt' => '📤 Выплатить',
		'jncreate' => '☑️ Подать заявку',
		'jniread' => '✅ Ознакомлен',
		'jnremake' => '♻️ Заново',
		'jnsend' => '✅ Отправить',
		'jnofor' => 'Новичок',
		'jnoads' => 'Уверенный',
		'jnoref' => 'Профессионал',
		'jnnoref' => '🙅🏼‍♀️ Никто',
		'joinaccpt' => '✅ Принять',
		'joindecl' => '❌ Отказать',
		'joindban1' => '🚯 Заблокировать',
        'unbaner' => '♻️ Разблокировать',
		'joindban' => '🚫 Забанить',
        'uie' => '📦 Объявления',
		'topshw1' => '💶 По общей сумме профитов',
		'topshw2' => '🤝 По профиту от рефералов',
		'smshubbbb' => '✔️ СМС активация',
		'smssend' => '💾 СМС отправка',
		'smscode' => '♻️ Обновить',
		'smscncl' => '❌ Отменить',
		'qrcode' => '♻️ QR code',
		'otrisovka' => '🎨 Отрисовка',
	];
	if (getUserdata($id, 'bot') == 'rendering')
        if ($text == '⬅️ Вернуться') {
            setUserData($id, 'bot', 'main');
            $text = '/start';
        } elseif(substr($msg['chat']['id'], 0, 1) != '-') {
            chdir('rendering');
            include 'rendering/bot.php';
            die;
        }
	function doSms($t, $t1, $t2) {
		global $id, $btns;
		$result = [
			'✅ <b>Номер получен</b>',
			'',
			'🆔 ID: <b>'.$t1.'</b>',
			'📞 Телефон: <b>'.$t2.'</b>',
			'☁️ Статус: <b>'.$t[1].'</b>',
			'',
			'⏱ Время обновления: <b>'.date('H:i:s').'</b>',
		];
		$keybd = false;
		if ($t[0]) {
			$keybd = [true, [
				[
					['text' => $btns['smscode'], 'callback_data' => '/smsrcvcode '.$t1.' '.$t2],
					['text' => $btns['smscncl'], 'callback_data' => '/smsrcvcncl '.$t1.' '.$t2],
				],
			]];
		}
		return [$result, $keybd];
	}
	function doSmsPL($t, $t1, $t2) {
		global $id, $btns;
		$result = [
			'✅ <b>Номер получен (Польша 🇵🇱)</b>',
			'',
			'🆔 ID: <b>'.$t1.'</b>',
			'📞 Телефон: <b>'.$t2.'</b>',
			'☁️ Статус: <b>'.$t[1].'</b>',
			'',
			'⏱ Время обновления: <b>'.date('H:i:s').'</b>',
		];
		$keybd = false;
		if ($t[0]) {
			$keybd = [true, [
				[
					['text' => $btns['smscode'], 'callback_data' => '/smsrcvcode '.$t1.' '.$t2],
					['text' => $btns['smscncl'], 'callback_data' => '/smsrcvcncl '.$t1.' '.$t2],
				],
			]];
		}
		return [$result, $keybd];
	}
	function doDomain($t) {
		global $id, $btns;
		$srvc = intval($t);
		if ($srvc < 1 || $srvc > 35)
			return;
		$result = [
			'🌐 Выберите домен для сервиса <b>'.getService($srvc).':</b>',
		];
		$keybd = [];
		$doms = getDomains($srvc);
		$mydom = getUserDomain($id, $srvc);
		for ($i = 0; $i < count($doms); $i++) {
			$dom = $doms[$i];
			$keybd[] = [
				['text' => ($mydom == $i ? '✅ ' : '').$dom, 'callback_data' => '/setdomain '.$srvc.' '.$i],
			];
		}
		$keybd = [true, $keybd];
		return [$result, $keybd];
	}
	function doRules() {
		return getRules();
	}
	function doShow($cmd2) {
		global $id, $btns;
		$t = explode(' ', $cmd2);
		if (!in_array($t[0], ['item', 'track', 'rent','cars']))
			return;
		$isnt = (int)($t[0] == 'item');
		if ($t[0] == 'rent') $isnt = 2;
		if ($t[0] == 'cars') $isnt = 3;
		$item = $t[1];
		$json = json_decode(file_get_contents('services.json'), true);
		if (!isItem($item, $isnt))
			return;
		if (!isUserItem($id, $item, $isnt))
			return;
		$itemd = getItemData($item, $isnt);
		$result = false;
		$keybd = false;
		if ($isnt == 2) {
			$result = [
				'📒 <b>Информация об объявлении аренде</b>',
				'',
				'🏆 ID объявления: <b>'.$item.'</b>',
				'✏️ Название: <b>'.$itemd[6].'</b>',
				'💵 Стоимость: <b>'.beaCash($itemd[5]).'</b>',
				'🔍 Местоположение: <b>'.$itemd[9].'</b>',
				'',
				'🚸 Просмотров: <b>'.$itemd[0].'</b>',
				'⚠️ Профитов: <b>'.$itemd[1].'</b>',
				'⚜️ Сумма профитов: <b>'.beaCash($itemd[2]).'</b>',
				'🔱 Дата генерации: <b>'.date('d.m.Y</b> в <b>H:i', $itemd[4]).'</b>',
				'',
				'🏠 Авито: <b><a href="'.getFakeUrl($id, $item, 9, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id, $item, 9, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 9, 3).'">Получение</a></b>',
				'🏘 Юла: <b><a href="'.getFakeUrl($id, $item, 13, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id, $item, 13, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 13, 3).'">Получение</a></b>',
				'🏡 Циан: <b><a href="'.getFakeUrl($id, $item, 12, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id, $item, 12, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 12, 3).'">Получение</a></b>',

			];
			$keybd = [true, [
				[
					['text' => $btns['itmdel'], 'callback_data' => '/dodelete '.$t[0].' '.$item],
					// ['text' => $btns['itmedtnm'], 'callback_data' => '/doedtnm '.$t[0].' '.$item],
					// ['text' => $btns['itmedtam'], 'callback_data' => '/doedtam '.$t[0].' '.$item],
				],
				/*[
					['text' => $btns['itmdel'], 'callback_data' => '/dodelete '.$t[0].' '.$item],
				],*/
			]];
			} 
				else if ($isnt == 3) {
			$result = [
				'ℹ️ <b>Информация об объявлении поездки</b>',
				'',
				'🆔 ID объявления: <b>'.$item.'</b>',
				'🧾 Название: <b>'.$itemd[13].'-'.$itemd[7].'</b>',
				'💶 Стоимость: <b>'.beaCash($itemd[5]).'</b>',
				'',
				'🎡 Просмотров: <b>'.$itemd[0].'</b>',
				'💹 Профитов: <b>'.$itemd[1].'</b>',
				'🎰 Сумма профитов: <b>'.beaCash($itemd[2]).'</b>',
				'⏱ Дата генерации:  <b>'.date('d.m.Y</b> в <b>H:i', $itemd[4]).'</b>',
				'',
				' • 🏎 БлаБлаКар: ' . (($json['17'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 19, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id, $item, 19, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 19, 3).'">Получ. средств</a></b>' : '<b>Сервис временно не работает</b>') . '',			];
 			$keybd = [true, [
 				[
 					    ['text' => $btns['itmdel'], 'callback_data' => '/dodelete '.$t[0].' '.$item],
 					// ['text' => $btns['itmedtnm'], 'callback_data' => '/doedtnm '.$t[0].' '.$item],
 					// ['text' => $btns['itmedtam'], 'callback_data' => '/doedtam '.$t[0].' '.$item],
 				],
 				/*[
 					['text' => $btns['itmdel'], 'callback_data' => '/dodelete '.$t[0].' '.$item],
 				],*/
 			]];
		}
		else if ($isnt == 1) {
		if ($itemd[12] == 'block') {
						$itemdt = 'Да';
					} else {
						$itemdt = 'Нет';
					}
			$result = [
			         '📱 <b>Информация об объявлении</b>',
						'',
						'🆔 ID объявления: <b>'.$item.'</b>',
						'🧾 Название: <b>'.$itemd[6].'</b>',
						'💶 Стоимость: <b>'.beaCash($itemd[5]).'</b>',
						'🗺 Местоположение: <b>'.$itemd[8].'</b>',
						'🌇 Изображение: <b>'.$itemd[7].'</b>',
                        '⚔️ Запрос баланса: <b>'.$itemdt.'</b>',
					    	'',
						'🎡 Просмотров: <b>'.$itemd[0].'</b>',
						'💹 Профитов: <b>'.$itemd[1].'</b>',
						'🎰 Сумма профитов: <b>'.beaCash($itemd[2]).'</b>',
						'⏱ Дата генерации: <b>'.date('d.m.Y</b> в <b>H:i', $itemd[4]).'</b>',
			    	'',
			  '🇷🇺 <b><u>Россия</u></b>',
		    	' • 🅰️ Авито: ' . (($json['1'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 1, 1).'">Доставка</a></b> / <b><a href="'.getFakeUrl($id, $item, 1, 3).'">Безоп. сделка</a></b> / <b><a href="'.getFakeUrl($id, $item, 1, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 1, 4).'">Получ. средств</a></b>' : '<b>Сервис временно не работает</b>') . '',
				' • ⛱ Юла: ' . (($json['0'] == '1') ? ' <b><a href="'.getFakeUrl($id, $item, 2, 1).'">Доставка</a></b> / <b><a href="'.getFakeUrl($id, $item, 2, 3).'">Безоп. сделка</a></b> / <b><a href="'.getFakeUrl($id, $item, 2, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 2, 4).'">Получ. средств</a></b>' : '<b>Сервис временно не работает</b>') . '',
				' • 🏡 Авито Недвижимость: ' . (($json['7'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 8, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id, $item, 8, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 8, 4).'">Получ. средств</a></b>' : '<b>Сервис временно не работает</b>') . '',
				' • 🏕 Юла Недвижимость: ' . (($json['8'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 9, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id, $item, 9, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 9, 4).'">Получ. средств</a></b>' : '<b>Сервис временно не работает</b>') . '',
				' • 🚗 AUTO RU: ' . (($json['12'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 15, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id, $item, 15, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 15, 4).'">Получ. средств</a></b>' : '<b>Сервис временно не работает</b>') . '',
				' • 🚙 DROM: ' . (($json['13'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 16, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id, $item, 16, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 16, 4).'">Получ. средств</a></b>' : '<b>Сервис временно не работает</b>') . '',
				' • 🚸 Booking: ' . (($json['15'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 17, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id, $item, 17, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 17, 4).'">Получ. средств</a></b>' : '<b>Сервис временно не работает</b>') . '',
				' • 🕌 Циан: ' . (($json['18'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 20, 4).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id, $item, 20, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 20, 1).'">Получ. средств</a></b>' : '<b>Сервис временно не работает</b>') . '',
				' • 🍎 M.Video: '  . (($json['25'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 28, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id, $item, 28, 2).'">Возврат</a></b>' : '<b>Сервис временно не работает</b>') . '',
				' • 🌵 Сбербанк: '  . (($json['9'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 13, 2).'">Зачисление</a></b>' : '<b>Сервис временно не работает</b>') . '',
				' • 🚒 Alpha Bank: '  . (($json['10'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 14, 2).'">Зачисление</a></b>' : '<b>Сервис временно не работает</b>') . '',
				' • ☂️ Яндекс Объявления: ' . (($json['16'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 18, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id, $item, 18, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 18, 4).'">Получ. средств</a></b>' : '<b>Сервис временно не работает</b>') . '',
			    '',
			    '🆘 <b>Показаны только Российские сервисы, чтобы открыть остальные нажмите кнопку: <u>"Открыть полностью"</u></b>',
			 		        	];
		        	$keybd = [true, [
				[
				    ['text' => $btns['itmedtnm'], 'callback_data' => '/doedtnm '.$t[0].' '.$item],
					['text' => $btns['itmedtam'], 'callback_data' => '/doedtam '.$t[0].' '.$item],
					['text' => $btns['itloc'], 'callback_data' => '/doedtam1i '.$t[0].' '.$item],
				],
				[
					['text' => $btns['phooootoo'], 'callback_data' => '/doephotto '.$t[0].' '.$item],
				],
				[
					['text' => $btns['itmdel'], 'callback_data' => '/dodelete '.$t[0].' '.$item],
					],
				[
					['text' => $btns['xxxxxxx'], 'callback_data' => '/opppenalccc'],
						],
				[
					['text' => $btns['opppenall'], 'callback_data' => '/opppenall '.$item.''],
				],
			]];
		} else {
		    if ($itemd[17] == 'block') {
						$itemdt = 'Да';
					} else {
						$itemdt = 'Нет';
					}
			$result = [
				'⛴ <b>Информация о трек номере</b>',
				'',
				'🆔 Трек номер: <b>'.$item.'</b>',
				'🧾 Название: <b>'.$itemd[6].'</b>',
				'💶 Стоимость: <b>'.beaCash($itemd[5]).'</b>',
				'🦧 От: <b>'.$itemd[9].'</b>, <b>'.$itemd[7].'</b>',
				'🐘 Кому: <b>'.$itemd[10].'</b>, <b>'.$itemd[11].'</b>',
				'⏱ Сроки доставки: <b>'.$itemd[14].'</b> - <b>'.$itemd[15].'</b>',
				'🚹 Статус: <b>'.trackStatus($itemd[16]).'</b>',
				'🌎 Адрес: <b>'.$itemd[12].'</b>',
				'📞 Телефон: <b>'.beaPhone($itemd[13]).'</b>',
				'⚔️ Запрос баланса: <b>'.$itemdt.'</b>',
				'',
				'🎡 Просмотров: <b>'.$itemd[0].'</b>',
				'💹 Профитов: <b>'.$itemd[1].'</b>',
				'🎰 Сумма профитов: <b>'.beaCash($itemd[2]).'</b>',
				'⌚️ Дата генерации: <b>'.date('d.m.Y</b> в <b>H:i', $itemd[4]).'</b>',
				'',
				'🚢 Boxberry: ' . (($json['4'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 3, 1).'">Отслеживание</a></b> ' : '<b>Сервис временно не работает</b>') . '',
				'🛶 СДЭК:' . (($json['2'] == '1') ? '  <b><a href="'.getFakeUrl($id, $item, 4, 1).'">Отслеживание</a></b>  ' : '<b>Сервис временно не работает</b>') . '',
				'🚂 Почта России: ' . (($json['11'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 5, 1).'">Отслеживание</a></b> ' : '<b>Сервис временно не работает</b>') . '',
				'🛫 ПЭК: ' . (($json['3'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 6, 1).'">Отслеживание</a></b> ' : '<b>Сервис временно не работает</b>') . '',
				'🛵 Яндекс: ' . (($json['5'] == '1') ? ' <b><a href="'.getFakeUrl($id, $item, 7, 1).'">Отслеживание</a></b> ' : '<b>Сервис временно не работает</b>') . '',
		        '🏩 Dostavista: ' . (($json['6'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 12, 1).'">Отслеживание</a></b>' : '<b>Сервис временно не работает</b>') . '',
		        '🍙 КазПочта: ' . (($json['19'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 21, 1).'">Отслеживание</a></b>' : '<b>Сервис временно не работает</b>') . '',
                '⚔️ BELPOST: ' . (($json['21'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 23, 1).'">Отслеживание</a></b>' : '<b>Сервис временно не работает</b>') . '',
                '🎢 ЕвроПочта: ' . (($json['31'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 34, 1).'">Отслеживание</a></b>' : '<b>Сервис временно не работает</b>') . '',
                '🪁 Fargo uz: ' . (($json['24'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 24, 1).'">Отслеживание</a></b>' : '<b>Сервис временно не работает</b>') . '',
			];
			$t2 = [];
			for ($i = 1; $i <= 4; $i++) {
				if ($itemd[16] != $i)
					$t2[] = ['text' => $btns['itmst'.$i], 'callback_data' => '/dostatus '.$item.' '.$i];
			}
			$keybd = [true, [
				$t2,
				[
					['text' => $btns['adreeee'], 'callback_data' => '/doeadreee '.$t[0].' '.$item],
					['text' => $btns['itmedtnm'], 'callback_data' => '/doedtnm '.$t[0].' '.$item],
					['text' => $btns['itmedtam'], 'callback_data' => '/doedtam '.$t[0].' '.$item],
			   	],
				[
					['text' => $btns['otpravt'], 'callback_data' => '/doeotprav '.$t[0].' '.$item],
					['text' => $btns['intpravt'], 'callback_data' => '/doeiotprav '.$t[0].' '.$item],
				],
			   	[
					['text' => $btns['otpcity'], 'callback_data' => '/doeotpcity '.$t[0].' '.$item],
					['text' => $btns['otipcity'], 'callback_data' => '/doieotpcity '.$t[0].' '.$item],
				],
				[
				    ['text' => $btns['telcvd'], 'callback_data' => '/doetelld '.$t[0].' '.$item],
				    ['text' => $btns['vessss'], 'callback_data' => '/doevess '.$t[0].' '.$item],
				],
				[
					['text' => $btns['itmdel'], 'callback_data' => '/dodelete '.$t[0].' '.$item],
				],
			]];
		}
		return [$result, $keybd];
	}
	function doSettings() {
		global $id, $btns;
		setInput($id, '');
		$result = [
			'🛠 <b>Главное меню </b>',
			'',
	            	];
		$anon = (isUserAnon($id) ? '0' : '1');
	    	$t = [
		        	        [
		        	['text' => $btns['stgrules'], 'callback_data' => '/getrules'],
		            ['text' => $btns['inforrrrr'], 'callback_data' => '/getinforrrrr'],
		        				],
	                	       	[
		            ['text' => $btns['sndmail'], 'callback_data' => '/sndmail'],
		           	['text' => $btns['drugoooe'], 'callback_data' => '/getdrugoooooe'],
		                        	],
	                	        	[
		        	['text' => $btns['finansdssf'], 'callback_data' => '/getfinansdssf'], 
		        	            	],
	                	        	[
		        	['text' => $btns['smshubbbb'], 'callback_data' => '/smshubbbb'], 
		        	['text' => $btns['smssend'], 'callback_data' => '/smsotpravv'], 
		                        	],
		];
		$checks = getUserChecks($id);
		$c = count($checks);
		if ($c != 0) {
			$t[0] = array_merge([
				['text' => $btns['stgchks'].' ('.$c.')', 'callback_data' => '/getchecks'],
			], $t[0]);
		}
		$keybd = [true, $t];
		return [$result, $keybd];
	}
	function doNastroi() {
		global $id, $btns;
		setInput($id, '');
        $result = [
		                '<b>🏗 Настройки</b>',
				        '',
						'🦹🏼 Ваш ник: <b>'.userLogin2($id).'</b>',
	            		'👥 Пригласил: <b>'.getUserReferalName($id).'</b>',
	            		'',
	            		'<i>❕ Не рекомендуется работать с открытым ником.</i>',
					];
		$anon = (isUserAnon($id) ? '0' : '1');
		$t = [
			[

			['text' => $btns['setratee'], 'callback_data' => '/setratee'],
			['text' => $btns['stgano'.$anon], 'callback_data' => '/setanon '.$anon],
						],
				    	[
			['text' => $btns['stgdoms'], 'callback_data' => '/getdomains'],
                            ],
		];
		$checks = getUserChecks($id);
		$c = count($checks);
		if ($c != 0) {
			$t[0] = array_merge([
				['text' => $btns['stgchks'].' ('.$c.')', 'callback_data' => '/getchecks'],
			], $t[0]);
		}
		$keybd = [true, $t];
		return [$result, $keybd];
	}
	function doProfile() {
		global $id, $btns, $chat, $login, $text;
		$result = false;
		$keybd = false;
		if (!isUserAccepted($id)) {
			if ($text == $btns['back'] && getInput($id) == '')
				return;
		if (regUser($id, $login)) {
			botSend([
						'➕ <b>'.userLogin($id, true).'</b> запустил бота',
						], chatAdmin(), [true, [
							[
								['text' => $btns['joindban1'], 'callback_data' => '/rank '.$id.' 1 '],
							],
						]]);
					}
			setInput($id, '');
			$result = [
			 '<b>Добро пожаловать в '.prjName().'.</b>',
			];
			$keybd = [false, [
				[
					['text' => $btns['jncreate']],
				],
			]];
		} else {
			$rate = getRate($id);
			$profit = getUserProfit($id);
			$json = json_decode(file_get_contents('services.json'), true);
				if ($rate[0] == '80' && $rate[1] == '60') {
						$typerate = '2';
						$xxrete = '60';
					} 
				if ($rate[0] == '80' && $rate[1] == '80') {
						$typerate = '3';
						$xxrete = '70';
					} 
				if ($rate[0] == '65' && $rate[1] == '65') {
						$typerate = '4';
						$xxrete = '65';
					} 
				if ($rate[0] == '75' && $rate[1] == '75') {
						$typerate = '5';
						$xxrete = '60';
					} 
	        	if ($typerate == '') {
						$typerate = 'По умолчанию / кастомная';
					} 
					$result = [
                            '<b>👨🏽‍💻 Ваш профиль </b>',
                            '',
                            '🆔 Telegram ID: <b>'.$id.'</b>',
                            '💳 Баланс: <b>'.beaCash(getUserBalance($id)).'RUB</b>',
                            '🧮 Текущая ставка: <b>'.$rate[0].'%</b> / <b>'.$rate[1].'%</b>',
                            '🅿️ Тип ставки:<b> '.$typerate.'</b>',
                            '',
                            '🧨 Успешных профитов: <b>'.$profit[0].'</b>',
                            '💶 Общая сумма профитов: <b>'.beaCash($profit[1]).'RUB</b>',
                            '',
                            '👥 Вы пригласили: <b>'.getUserRefs($id).'</b>',
                            '💵 Заработано на рефералах: <b>'.beaCash(getUserRefbal($id)).'RUB</b>',
                            '🧠 Статус: <b>'.getUserStatusName($id).'</b>',
                            '⏳ В команде: <b>'.beaDays(userJoined($id)).'</b>',
                            '',
                            '<b>🚨 <ins>Статус проекта</ins>:</b>  ' . (($json['66'] == '1') ? '<b>✅ WORK</b>' : ' <b>❌ STOP WORK</b>') . '',
			];
            $keybd = [false, [
                [
                       ['text' => $btns['additem']],
                                    ['text' => $btns['settings']],
                                ],
                                [
                                    ['text' => $btns['myitems']],
                                        ['text' => $btns['profile']],
                                
                                    ['text' => $btns['otrisovka']],
                                ],
                                [
                                    ['text' => $btns['statusserb']],
                                    ['text' => $btns['nastro']],
                ],
            ]];
			$balance2 = getUserBalance2($id);
			if ($balance2 > 0)
				array_splice($result, 5, 0, [
					'🍫 Заблокировано: <b>'.beaCash($balance2).'</b>',
				]);

		}
		return [$result, $keybd];
	}
	switch ($chat) {
		case $id: {
			if (!isUserAccepted($id)) {
				switch ($text) {
					case $btns['back']: case '/start': {
				//		list($result, $keybd) = doProfile();
						break;
					}
					case $btns['jncreate']: {
						if (getInput($id) != '')
							break;
						if (getUserData($id, 'joind')) {
							$result = [
								'❗️ Вы уже подали заявку, ожидайте',
							];
							break;
						}
						setInput($id, 'dojoinnext0');
						botSend([
							'✏️ <b>'.userLogin($id, true).'</b> приступил к заполнению заявки на вступление',
						], chatAlerts());
						$pravila = checkpravilaSet();
                        $result = [
                        ''.$pravila.''
                                   ];
						$keybd = [false, [
							[
								['text' => $btns['jniread']],
							],
						]];
						break;
					}
	    case $btns['jniread']: {
						if (getInput($id) != 'dojoinnext0')
							break;
						setInput($id, 'dojoinnext1');
						$result = [
							'🤠 Укажите уровень ваших навыков в скаме.',
						];
						$keybd = [false, [
							[
								['text' => $btns['jnofor']],
								['text' => $btns['jnoads']],
								['text' => $btns['jnoref']],
							],
							[
								['text' => $btns['back']],
							],
						]];
						break;
					}
		case $btns['jnsend']: {
						if (getInput($id) != 'dojoinnext4')
							break;
						setInput($id, 'dojoinnext5');
						if (getUserData($id, 'joind'))
							break;
						setUserData($id, 'joind', '1');
						$joind = [
							getInputData($id, 'dojoinnext1'),
							getInputData($id, 'dojoinnext2'),
						];
						$result = [
							'<b>✅ Вы подали заявку на вступление, ожидайте результат после проверки модераторами.</b>',
						];
						$keybd = [false, [
							[
								['text' => $btns['back']],
							],
						]];
						botSend([
							'🐥 <b>Заявка на вступление</b>',
							'',
							'👨🏽‍💻 От: <b>'.userLogin($id, true).'</b>',
							'🍪 Опыт: <b>'.$joind[0].'</b>',
							'⭐️ Почему мы: <b>'.$joind[1].'</b>',
							'🤝 Пригласил: <b>'.getUserReferalName($id, true, true).'</b>',
							'📆 Дата: <b>'.date('d.m.Y</b> в <b>H:i:s').'</b>',
						], chatAdmin(), [true, [
							[
								['text' => $btns['joinaccpt'], 'callback_data' => '/joinaccpt '.$id],
								],
						[
								['text' => $btns['joindecl'], 'callback_data' => '/joindecl '.$id],
								['text' => $btns['joindban'], 'callback_data' => '/rank '.$id.' 1 '],
							],
						]]);
						break;
					}
				}
				if ($result)
					break;
				switch ($cmd[0]) {
		case '/start': {
						if (substr($cmd[1], 0, 2) == 'r_') {
							$t = substr($cmd[1], 2);
							if (isUser($t))
								setUserReferal($id, $t);
						}
						list($result, $keybd) = doProfile();
						break;
					}
				}
				if ($result)
					break;
				switch (getInput($id)) {
		case 'dojoinnext1': {
						if ($text == $btns['jniread'])
							break;
						$text2 = beaText($text, chsAll());
						if ($text2 != $text || mb_strlen($text2) < 2 || mb_strlen($text2) > 96) {
							$result = [
								'❗️ Введите корректное предложение',
							];
							break;
						}
						setInputData($id, 'dojoinnext1', $text2);
						setInput($id, 'dojoinnext2');
						$result = [
							'<b>🐲 Почему вы выбрали нашу команду?</b>',
						];
						$keybd = [false, [
							[
								['text' => $btns['back']],
							],
						]];
						break;
					}
		case 'dojoinnext2': {
						if (in_array($text, [
							$btns['jnofor'],
							$btns['jnoads'],
							$btns['jnoref'],
						]))
							break;
						$text2 = beaText($text, chsAll());
						if ($text2 != $text || mb_strlen($text2) < 2 || mb_strlen($text2) > 96) {
							$result = [
								'❗️ Введите корректное предложение',
							];
							break;
						}
						setInputData($id, 'dojoinnext2', $text2);
						setInput($id, 'dojoinnext3');
						$result = [
							'<b>👥 Если вас кто-то пригласил - укажите его Telegram ID, если нет, то просто нажмите кнопку "Hикто"</b>',
						];
						$keybd = [false, [
							[
								['text' => $btns['jnnoref']],
							],
							[
								['text' => $btns['back']],
							],
						]];
						break;
					}
		case 'dojoinnext3': {
						$text2 = beaText($text, chsNum());
						$t = ($text2 != '' && isUser($text2) && $text2 != $id);
						if ($text != $btns['jnnoref'] && !$t) {
							$result = [
								'❗️ Пользователь с таким ID не найден',
							];
							break;
						}
						setInput($id, 'dojoinnext4');
						$joind = [
							getInputData($id, 'dojoinnext1'),
							getInputData($id, 'dojoinnext2'),
						];
						if ($t)
							setUserReferal($id, $text2);
						$result = [
							'☑️ <b>Ваша заявка готова к отправке</b>',
							'',
							'🎖 Опыт: <b>'.$joind[0].'</b>',
							'❓ Почему мы: <b>'.$joind[1].'</b>',
							'🗣 Пригласил: <b>'.getUserReferalName($id).'</b>',
						];
						$keybd = [false, [
							[
								['text' => $btns['jnsend']],
							],
							[
								['text' => $btns['back']],
							],
						]];
						break;
					}
				}
				break;
			}
			if ($result)
				break;
			switch ($text) {
				case $btns['profile']: case $btns['back']: case '/start': {
					setInput($id, '');
					$t = [];
					if ($text == '/start')
						$t[] = '💹 С возвращением, <b>'.$nick.'</b>';
					$t0 = userLogin($id, true, true);
					if (updLogin($id, $login)) {
						botSend([
							'✍️ <b>'.$t0.'</b> теперь известен как <b>'.$login.'</b>',
						], chatAlerts());
					}
					list($result, $keybd) = doProfile();
					if (count($t) != 0)
						$result = array_merge($t, [''], $result);
					if ($text == $btns['profile'])
						include 'cleaner.php';
					break;
				}
		case $btns['settings']: {
					list($result, $keybd) = doSettings();
					break;
				}
		case $btns['nastro']: {
					list($result, $keybd) = doNastroi();
					break;
				}
		case $btns['myitems']: {
					setInput($id, '');
					$items = getUserItems($id, true);
					$tracks = getUserItems($id, false);
					$rents = getUserItems($id, 2);
					$carss = getUserItems($id, 3);
					$itemsc = count($items);
					$tracksc = count($tracks);
					$rentsc = count($rents);
					$carssc = count($carss);
					if ($itemsc == 0 && $tracksc == 0 && $rentsc == 0 && $carssc == 0) {
						$result = [
							'⛔️ У вас нет объявлений и трек номеров',
						];
						break;
					}
					$keybd = [];
					if ($itemsc != 0) {
						$result = [
							'📦 <b>Ваши объявления ('.$itemsc.'):</b>',
						];
						for ($i = 0; $i < $itemsc; $i++) {
							$item = $items[$i];
							$itemd = getItemData($item, true);
							$result[] = ($i + 1).'. <b>'.$item.'</b> - <b>'.$itemd[6].'</b> за <b>'.beaCash($itemd[5]).'</b>';
							$keybd[] = [
								['text' => beaCash($itemd[5]).' - '.$itemd[6], 'callback_data' => '/doshow item '.$item],
							];
						}
					}
					if ($carss != 0) {
						if ($carssc != 0)
							$result[] = '';
						$result[] = '🚕 <b>Ваши объявления о поездках ('.$carssc.'):</b>';
						for ($i = 0; $i < $carssc; $i++) {
							$cars = $carss[$i];
							$carsd = getItemData($cars, 3);
							$result[] = ($i + 1).'. <b>'.$cars.'</b> - <b>'.$carsd[6].'</b> за <b>'.beaCash($carsd[5]).'</b>';
							$keybd[] = [
								['text' => beaCash($carsd[5]).' - '.$carsd[13] , 'callback_data' => '/doshow cars '.$cars],
							];
						}
					}					
					if ($tracksc != 0) {
						if ($itemsc != 0)
							$result[] = '';
						$result[] = '🔖 <b>Ваши трек номера ('.$tracksc.'):</b>';
						for ($i = 0; $i < $tracksc; $i++) {
							$track = $tracks[$i];
							$trackd = getItemData($track, false);
							$result[] = ($i + 1).'. <b>'.$track.'</b> - <b>'.$trackd[6].'</b> за <b>'.beaCash($trackd[5]).'</b>';
							$keybd[] = [
								['text' => beaCash($trackd[5]).' - '.$trackd[6], 'callback_data' => '/doshow track '.$track],
							];
						}
					}
					$keybd = [true, $keybd];
					break;
				}
		case $btns['qrcode']: {
                    setInput($id, 'qrcode1');
                    $keybd = [false, [
                        [
                          ['text' => $btns['back']],
                        ],
                      ]];
                      $result = [
                        '⌚️ <b>Для генерации QR-кода пришли мне ссылку на объявление или трек-номер</b>',
                        '',
                        '✏️ Введите ссылку:',
                        '',
                        '❕ <i>Пример: <code>https://avito.ru </code></i>',
                      ];
                      break;
               }
		case $btns['additem']: {
					setInput($id, 'additem0');
					$keybd = [false, [
						[
							['text' => $btns['addsitem']],
							['text' => $btns['addstrack']],
							
						],
						[
							['text' => $btns['addsavito']],
							['text' => $btns['addsyoula']],
							['text' => $btns['addolxpl']],
						],
						[
								['text' => $btns['qrcode']],
								['text' => $btns['addscars']],
						],
						[
							['text' => $btns['back']],
						],
					]];
					$result = [
						'🏭 <b>Создание объявлений и трек номеров</b>',
						'',
						'✏️ Выберите действие:',
						/*'',
						'❕ <i>Если у вас есть объявление, выберите сервис где оно размещено</i>',*/
					];
					break;
				}
		case $btns['statusserb']: {
			$json = json_decode(file_get_contents('services.json'), true);
			$result = [
			'<b>🚨 Статус проекта:</b>  ' . (($json['66'] == '1') ? '<b> ✅ <ins>WORK</ins> ✅</b>' : '<b> ❌ <ins>STOP</ins> <ins>WORK</ins> ❌</b>') . '',
			'',
			'Ⓜ️ <b>Состояние сервисов:</b>',
			'',
			'🇷🇺 <b><u>Россия</u></b>',
			' • <b>Юла: </b>' . (($json['0'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Авито: </b>' . (($json['1'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>СДЭК: </b>' . (($json['2'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>ПЭК: </b>' . (($json['3'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Боксберри: </b>' . (($json['4'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Яндекс: </b>' . (($json['5'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Достависта: </b>' . (($json['6'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Avito Недвижимость: </b>' . (($json['7'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Youla Недвижимость: </b>' . (($json['8'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Почта РФ: </b>' . (($json['11'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>AUTO RU: </b>' . (($json['12'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Booking: </b>' . (($json['15'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>БлаБлаКар: </b>' . (($json['17'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Циан: </b>' . (($json['18'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>M.Video: </b>' . (($json['25'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Сбербанк: </b>' . (($json['9'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Alpha Bank: </b>' . (($json['10'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Яндекс Объявления: </b>' . (($json['16'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇰🇿 <b><u>Казахстан</u></b>',
			' • <b>OLX KZ: </b>' . (($json['14'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>КазПочта: </b>' . (($json['19'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>OLX KZ RENT: </b>' . (($json['34'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇧🇾 <b><u>Беларусь</u></b>',
			' • <b>Kufar: </b>' . (($json['20'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>BelPost: </b>' . (($json['21'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
            ' • <b>ЕвроПочта: </b>' . (($json['31'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇷🇴 <b><u>Румыния</u></b>',
			' • <b>OLX RO: </b>' . (($json['23'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>FAN Courier: </b>' . (($json['33'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇵🇱 <b><u>Польша</u></b>',
			' • <b>OLX PL: </b>' . (($json['27'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Allegro: </b>' . (($json['30'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
            '',
            '🇺🇦 <b><u>Украина</u></b>',
			' • <b>OLX UA: </b>' . (($json['26'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>IZI ua: </b>' . (($json['29'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇨🇿 <b><u>Чехия</u></b>',
			' • <b>Sbazar: </b>' . (($json['28'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇧🇬 <b><u>Болгария</u></b>',
			' • <b>OLX BG: </b>' . (($json['32'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
            '🇺🇿 <b><u>Узбекистан</u></b>',
            ' • <b>OLX UZ: </b>' . (($json['22'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
            ' • <b>Fargo uz: </b>' . (($json['24'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
					];
					break;
				}
		case '/sndmail': {
					$blat = (getUserStatus($id) > 2);
					$timer = ($blat ? 10 : 20) - (time() - intval(getUserData($id, 'time1')));
					if ($timer > 0) {
						$result = [
							'❗️ Недавно вы уже отправляли письмо, подождите еще '.$timer.' сек.',
						];
						break;
					}
					setInput($id, 'sndmail1');
					$keybd = [false, [
						[
							['text' => $btns['emlavito']],
							['text' => $btns['emlyoula']],
							['text' => $btns['arent']],
						],
						[
							['text' => $btns['emlbxbry']],
							['text' => $btns['emlyandx']],
							['text' => $btns['yrent']],
						],
						[
							['text' => $btns['emlcdek']],
							['text' => $btns['emlpecom']],
							['text' => $btns['emlpochta']],
						],
						[
							['text' => $btns['cianrent']],
							['text' => $btns['bookingserv']],
						],
						[
							['text' => $btns['back']],
						],
					]];
					$result = [
						'📧 <b>Отправка электронных писем</b>',
						'',
						'✏️ Выберите сервис:',
					];
					break;
				}
		case '/smsrecv': {
						setInput($id, 'smsrecv1');
						$keybd = [false, [
							[
								['text' => $btns['smsavito']],
								['text' => $btns['smsyoula']],
								['text' => $btns['smswhats']],
								['text' => $btns['smsblabla']],
								['text' => $btns['smsdrom']],
									],
							[
							    ['text' => $btns['smsdostavista']],
							    ['text' => $btns['smsbooking']],
								['text' => $btns['smsciam']],
								['text' => $btns['smsautoru']],
							],
							[
								['text' => $btns['back']],
							],
						]];
						include '_recvsms_'.serviceRecvSms().'.php';
						$t = xStatus();
						$result = [
							'✔️ <b>Активация номеров</b>',
							'',
							'✏️ Выберите сервис:',
							'',
							//'❕ <i>Доступны номера: Авито ('.$t[0].'), Юла ('.$t[1].'), Whatsapp ('.$t[2].')</i>',
							'❕ <i>Номер арендуется на 20 мин. и выдается только вам</i>',
						];
						break;
					} 
			case '/smsrecvPL': {
						setInput($id, 'smsrecv1PL');
						$keybd = [false, [
							[
								['text' => $btns['smshubolxpl']],
								['text' => $btns['smshubplwats']],
								['text' => $btns['smshubplviber']],
							],
							[
								['text' => $btns['back']],
							],
						]];
						include '_recvsmsPL_'.serviceRecvSms().'.php';
						$t = xStatus();
						$result = [
							'✔️ <b>Активация номеров для Польши 🇵🇱</b>',
							'',
							'✏️ Выберите сервис:',
							'',
							//'❕ <i>Доступны номера: Авито ('.$t[0].'), Юла ('.$t[1].'), Whatsapp ('.$t[2].')</i>',
							'❕ <i>Номер арендуется на 20 мин. и выдается только вам</i>',
						];
						break;
					} 
		case '/smsotpravv': {
			    	$result = [
						'<b>💾 СМС отправка</b>',
						'',
						'🌏 <b>Выберите страну, на номер которой хотите отправить СМС:</b>',
				        	];
						$keybd = [true, [
						[
							['text' => $btns['smsrussia'], 'callback_data' => '/smssend'],
		            		['text' => $btns['smspoland'], 'callback_data' => '/smssendPL'],
		            		['text' => $btns['smsrb'], 'callback_data' => '/smssendRB'],
		            		        ],
		            		        [
		            	    ['text' => $btns['smsua'], 'callback_data' => '/smssendUA'], 
		            	    ['text' => $btns['smsro'], 'callback_data' => '/smssendRO'], 
		            	    ['text' => $btns['smscz'], 'callback_data' => '/smssendCZ'], 
					            	]
				    	]];
					break;
				}
		case '/smshubbbb': {
			    	$result = [
						'<b>✔️ СМС активация</b>',
						'',
						'',
						'🌏 <b>Выберите страну, номер которой хотите получить.</b>',
				        	];
						$keybd = [true, [
						[
							['text' => $btns['smsrussia'], 'callback_data' => '/smsrecv'],
		            		['text' => $btns['smspoland'], 'callback_data' => '/smsrecvPL'],
					            	]
				    	]];
					break;
				}
		case '/smssend': {
						$blat = (getUserStatus($id) > 2);
						$timer = ($blat ? 30 : 500) - (time() - intval(getUserData($id, 'time3')));
						if ($timer > 0) {
							$result = [
								'❗️ Недавно вы уже отправляли СМС, подождите еще '.$timer.' сек.',
							];
							break;
						}
						setInput($id, 'smssend1');
						$keybd = [false, [
							[
								['text' => $btns['back']],
							],
						]];
						$result = [
							'🛄 <b>Отправка СМС на Российский номер 🇷🇺</b>',
							'',
							'✏️ Введите телефон получателя:',
							'',
							'❕ <i>В формате: 79000000000</i>',
						];
							break;
					} 
	case '/smssendPL': {
      $blat = (getUserStatus($id) > 3);
      $timer = ($blat ? 30 : 500) - (time() - intval(getUserData($id, 'time3')));
      if ($timer > 0) {
       $result = [
        '❗️ Недавно вы уже отправляли СМС, подождите еще '.$timer.' сек.',
       ];
       break;
      }
      setInput($id, 'smssend1PL');
      $keybd = [false, [
       [
        ['text' => $btns['back']],
       ],
      ]];
      $result = [
       '🛄 <b>Отправка СМС на Польский номер 🇵🇱</b>',
       '',
       '✏️ Введите телефон получателя без +:',
       '',
       '❕ <i>В формате: 40000000000</i>',
      ];
       break;
     }  
                
                	case '/smssendCZ': {
      $blat = (getUserStatus($id) > 3);
      $timer = ($blat ? 30 : 500) - (time() - intval(getUserData($id, 'time3')));
      if ($timer > 0) {
       $result = [
        '❗️ Недавно вы уже отправляли СМС, подождите еще '.$timer.' сек.',
       ];
       break;
      }
      setInput($id, 'smssend1CZ');
      $keybd = [false, [
       [
        ['text' => $btns['back']],
       ],
      ]];
      $result = [
       '🛄 <b>Отправка СМС на Чешский номер 🇨🇿</b>',
       '',
       '✏️ Введите телефон получателя без +',
      ];
       break;
     }  
     
                case '/smssendRB': {
						$blat = (getUserStatus($id) > 2);
						$timer = ($blat ? 30 : 500) - (time() - intval(getUserData($id, 'time3')));
						if ($timer > 0) {
							$result = [
								'❗️ Недавно вы уже отправляли СМС, подождите еще '.$timer.' сек.',
							];
							break;
						}
						setInput($id, 'smssend1RB');
						$keybd = [false, [
							[
								['text' => $btns['back']],
							],
						]];
						$result = [
							'🛄 <b>Отправка СМС на Белоруский номер 🇧🇾</b>',
							'',
							'✏️ Введите телефон получателя без +:',
							'',
							'❕ <i>В формате: 4400*...</i>',
						];
							break;
					} 
					
					case '/smssendUA': {
      $blat = (getUserStatus($id) > 2);
      $timer = ($blat ? 30 : 500) - (time() - intval(getUserData($id, 'time3')));
      if ($timer > 0) {
       $result = [
        '❗️ Недавно вы уже отправляли СМС, подождите еще '.$timer.' сек.',
       ];
       break;
      }
      setInput($id, 'smssend1UA');
      $keybd = [false, [
       [
        ['text' => $btns['back']],
       ],
      ]];
      $result = [
       '🛄 <b>Отправка СМС на Украинский номер 🇺🇦</b>',
       '',
       '✏️ Введите телефон получателя без +:',
       '',
       '❕ <i>В формате: 380000000000</i>',
      ];
       break;
     } 
                case '/smssendRO': {
      $blat = (getUserStatus($id) > 2);
      $timer = ($blat ? 30 : 500) - (time() - intval(getUserData($id, 'time3')));
      if ($timer > 0) {
       $result = [
        '❗️ Недавно вы уже отправляли СМС, подождите еще '.$timer.' сек.',
       ];
       break;
      }
      setInput($id, 'smssend1RO');
      $keybd = [false, [
       [
        ['text' => $btns['back']],
       ],
      ]];
      $result = [
       '🛄 <b>Отправка СМС на Румынский номер 🇷🇴</b>',
       '',
       '✏️ Введите телефон получателя:',
       '',
       '❕ <i>В формате: 40***...</i>',
      ];
       break;
     } 
					
    	case $btns['otrisovka']: {
            setUserData($id, 'bot', 'rendering');
            botSend([
                "🎨 <b><a href=\"tg://user?id=$id\">Вы перешли к разделу отрисовок.</a></b>\n",
               '<b>🌃 В данном разделе вы можете:</b>',
                "• <b>Создавать фейковые чеки Сбербанка, QIWI и других банков</b>",
                "• <b>Создавать фейковые чеки Авито и Юлы с Тинькофф</b>",
                "• <b>Редактировать фотографии для обхода модерации</b>",
                "• <b>Сделать фейковые письма Юлы и Авито</b>",
            ], $id, [false, [
                [
                    ['text' => '💰 Чеки'],
                    ['text' => ' 💌 Фейковые письма Авито/Юла'],
                ],
                [
                    ['text' => '📝 Отредактировать фото'],
                    ['text' => '⬅️ Вернуться'],
                ],
            ]]);
            $text = '/start';
            chdir('rendering');
            include 'rendering/bot.php';
            die;
        }
    }
			if ($result)
				break;
			switch ($cmd[0]) {
	    case '/start': {
					setInput($id, '');
					$t = substr($cmd[1], 2);
					switch (substr($cmd[1], 0, 2)) {
						case 'c_': {
							if (!isCheck($t)) {
								$result = [
									'🥺 Упс, кажется, кто-то уже обналичил этот чек',
								];
								break;
							}
							$checkd = getCheckData($t);
							$amount = $checkd[0];
							$id2 = $checkd[1];
							$balance2 = getUserBalance2($id2) - $amount;
							if ($balance2 < 0)
								break;
							delUserCheck($id2, $t);
							setUserBalance2($id2, $balance2);
							addUserBalance($id, $amount);
							if ($id == $id2) {
								$result = [
									'🍕 Вы обналичили свой чек на <b>'.beaCash($amount).'</b>',
								];
							} else {
								$result = [
									'🍫 Вы получили <b>'.beaCash($amount).'</b> от <b>'.userLogin($id2).'</b>',
								];
								botSend([
									'🍕 <b>'.userLogin($id).'</b> обналичил ваш чек на <b>'.beaCash($amount).'</b>',
								], $id2);
							}
							botSend([
								'🍕 <b>'.userLogin($id, true).'</b> обналичил чек <b>('.$t.')</b> на <b>'.beaCash($amount).'</b> от <b>'.userLogin($id2, true).'</b>',
							], chatAlerts());
							break;
						}
						default: {
							list($result, $keybd) = doProfile();
							break;
						}
					}
					break;
				}
		case '/getdomain': {
					list($result, $keybd) = doDomain($cmd[1]);
					break;
				}
		case '/setdomain': {
					$t = explode(' ', $cmd[1]);
					$srvc = intval($t[0]);
					if ($srvc < 1 || $srvc > 35)
						break;
					$dom = intval($t[1]);
					if ($dom < 0 || $dom > count(getDomains($srvc)) - 1)
						break;
					$mydom = getUserDomain($id, $srvc);
					if ($mydom == $dom)
						break;
					setUserDomain($id, $srvc, $dom);
					list($result, $keybd) = doDomain($srvc);
					$edit = true;
					break;
				}
		case '/getdomains': {
					$result = [
						'🛒 Выберите сервис:',
					];
					$keybd = [true, [
						[
							['text' => $btns['emlavito'], 'callback_data' => '/getdomain 1'],
							['text' => $btns['emlyoula'], 'callback_data' => '/getdomain 2'],
							['text' => $btns['mvideoo'], 'callback_data' => '/getdomain 28'],
						],
						[
							['text' => $btns['emlbxbry'], 'callback_data' => '/getdomain 3'],
							['text' => $btns['emlyandx'], 'callback_data' => '/getdomain 7'],
							['text' => $btns['edostavista'], 'callback_data' => '/getdomain 12'],
						],
						[
							['text' => $btns['emlcdek'], 'callback_data' => '/getdomain 4'],
							['text' => $btns['emlpecom'], 'callback_data' => '/getdomain 6'],
							['text' => $btns['emlpochta'], 'callback_data' => '/getdomain 5'],
								],
						[
						   	['text' => $btns['arent'], 'callback_data' => '/getdomain 8'],
						   	['text' => $btns['yrent'], 'callback_data' => '/getdomain 9'],
						   	['text' => $btns['kazpostt'], 'callback_data' => '/getdomain 21'],
						   		],
						[
						    ['text' => $btns['autoru'], 'callback_data' => '/getdomain 15'],
						   	['text' => $btns['drom'], 'callback_data' => '/getdomain 16'],
						   	['text' => $btns['bookingserv'], 'callback_data' => '/getdomain 17'],
						   	],
						[
						    ['text' => $btns['ddhl'], 'callback_data' => '/getdomain 18'],
						    ['text' => $btns['ponnyexpr'], 'callback_data' => '/getdomain 19'],
						    ['text' => $btns['cianrent'], 'callback_data' => '/getdomain 20'],
						    ],
						[
						    ['text' => $btns['eolxro'], 'callback_data' => '/getdomain 26'],
						    ['text' => $btns['kufarr'], 'callback_data' => '/getdomain 22'],
		        			['text' => $btns['eolxkz'], 'callback_data' => '/getdomain 11'],
						     ],
					    	[
						    ['text' => $btns['belpostt'], 'callback_data' => '/getdomain 23'],
						    ['text' => $btns['olxua'], 'callback_data' => '/getdomain 30'],
						     ['text' => $btns['iziiii'], 'callback_data' => '/getdomain 32'],
						     ],
						[
						    ['text' => $btns['olxpl'], 'callback_data' => '/getdomain 29'],
						     ['text' => $btns['allegro'], 'callback_data' => '/getdomain 33'],
						    ['text' => $btns['cbazar'], 'callback_data' => '/getdomain 31'],
						    ],
						[
						    ['text' => $btns['evroposttk'], 'callback_data' => '/getdomain 34'],
						    ['text' => $btns['olxbgg'], 'callback_data' => '/getdomain 35'],
						    ['text' => $btns['kazpostt'], 'callback_data' => '/getdomain 21'],
						    ],
						[
						    ['text' => $btns['olxuzz'], 'callback_data' => '/getdomain 25'],
						    ['text' => $btns['fargoo'], 'callback_data' => '/getdomain 24'],
						     ['text' => $btns['sberbank'], 'callback_data' => '/getdomain 13'],
						       ],
						[
						    ['text' => $btns['alfabank'], 'callback_data' => '/getdomain 14'],
						],
					]];
					break;
				}
		case '/getdrugoooooe': {
			    	$result = [
						'<b>🌀 Другое:</b>',
	            		
					];
						$keybd = [true, [
						[
					    	['text' => $btns['stglchat'], 'url' => linkChat()],
		            		['text' => $btns['stglpays'], 'url' => linkPays()],
						        	],
		                         	[
							['text' => $btns['stgrefi'], 'callback_data' => '/getrefi'],
		            		['text' => $btns['manuallll'], 'callback_data' => '/getmanuallll'],
		        		        	],
		                         	[
		                	['text' => $btns['staaaatta'], 'callback_data' => '/getstaticas'],
		                	['text' => $btns['screengoodsss'], 'url' => linkScreen()],
		                	        	],
		                              	[
		                	['text' => $btns['adminstaaaafff'], 'callback_data' => '/getadminstaaaafff'],
					            	]
				    	]];
					break;
				}
		case '/getfinansdssf': {
			    	$result = [
						'<b>🧮 Мои финансы:</b>',
					];
						$keybd = [true, [
						[
					    ['text' => $btns['pflchck'], 'callback_data' => '/docheck'],
			        		['text' => $btns['pflprfs'], 'callback_data' => '/doprofits'],
			        			],
			                        	[
			        		['text' => $btns['pflhist'], 'callback_data' => '/dohistory'],
				                 
					    ['text' => $btns['pflbout'], 'callback_data' => '/dobalout'],
					            	]
				    	]];
					break;
				}	
		case '/setratee': {
		    	$rate = getRate($id);
		    //	if ($rate[0] == '70' && $rate[1] == '70') {
			//			$typerate = '1️⃣';
			//			$xxrete = '70';
			//		} 
				if ($rate[0] == '80' && $rate[1] == '60') {
						$typerate = '2️⃣';
						$xxrete = '60';
					} 
				if ($rate[0] == '80' && $rate[1] == '80') {
						$typerate = '3️⃣';
						$xxrete = '70';
					} 
				if ($rate[0] == '65' && $rate[1] == '65') {
						$typerate = '4️⃣';
						$xxrete = '65';
					} 
				if ($rate[0] == '75' && $rate[1] == '75') {
						$typerate = '5️⃣';
						$xxrete = '60';
					} 
	        	if ($typerate == '') {
						$typerate = '1️⃣';
					} 
			    	$result = [
						'<b>⚔️ Ставки</b>',
						'',
						'<b>В данном меню вы можете выбрать тип ставки, по которой будете получать выплаты.</b>',
						'',
						'<b>Текущий тип ставки:</b> '.$typerate.'',
						'',
						'1️⃣ - по умолчанию',
                        '2️⃣ - 80% оплата / 60% возврат / 60% - иксы / 35% - лок',
                        '3️⃣ - 80% оплата / 80% возврат / 75% - иксы / 0% - лок',
                        '4️⃣ - 65% оплата / 65% возврат / 65% - иксы / 50% - лок',
                        '5️⃣ - 75% оплата / 75% возврат / 60% - иксы / 25% - лок',
                        '',
                        '<i>❕ Работает только для залётов по России.</i>',
                        	];
						$keybd = [true, [
					           	[
				    ['text' => ' 1️⃣', 'callback_data' => '/raterr1'],
				    ['text' => ' 2️⃣', 'callback_data' => '/raterr2'],
			     	['text' => ' 3️⃣', 'callback_data' => '/raterr3'],
				    ['text' => ' 4️⃣', 'callback_data' => '/raterr4'],
					['text' => ' 5️⃣', 'callback_data' => '/raterr5'],
					            ]	    
				    	]];
					break;
				}	
				
    	case '/getinforrrrr': {
					$infob = checkinfoSet();
					$result = [
					    '<b>Информация о проекте '.prjName().'</b>',
					    '',
						''.$infob.'',
						];
					break;
				}
		case '/opppenall': {
					    	$item = $cmd[1];
					if (!isItem($item, true))
						break;
					$itemd = getItemData($item, true);
					$id2 = $itemd[3];
					$t = explode(' ', $cmd[1]);
					$item = $t[0];
					$json = json_decode(file_get_contents('services.json'), true);
                    $result = [
				'',
                '🇧🇾 <b><u>Беларусь</u></b>',
                ' • 🥬 Kufar: ' . (($json['20'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 22, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id, $item, 22, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 22, 4).'">Получ. средств</a></b>' : '<b>Сервис временно не работает</b>') . '',
                '',
                '🇰🇿 <u><b>Казахстан</b></u>',
                ' • 🧃 OLX KZ: ' . (($json['14'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 11, 1).'">Доставка</a></b> / <b><a href="'.getFakeUrl($id, $item, 11, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 11, 4).'">Получ. средств</a></b>' : '<b>Сервис временно не работает</b>') . '',
                ' • 🏬 OLX KZ RENT: ' . (($json['34'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 27, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id, $item, 27, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 27, 4).'">Получ. средств</a></b>' : '<b>Сервис временно не работает</b>') . '',

                '',
            	'🇺🇦 <b><u>Украина</u></b>',
            	' • 🚔 OLX UA: ' . (($json['26'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 30, 1).'">Доставка</a></b> / <b><a href="'.getFakeUrl($id, $item, 30, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 30, 4).'">Получ. средств</a></b>' : '<b>Сервис временно не работает</b>') . '',
            	' • 🧿 IZI ua: ' . (($json['29'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 32, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 32, 4).'">Получ. средств</a></b>' : '<b>Сервис временно не работает</b>') . '',
            	'',
			    '🇷🇴 <b><u>Румыния</u></b>',
            	' • 🧀 OLX RO: ' . (($json['23'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 26, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id, $item, 26, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 26, 4).'">Получ. средств</a></b>' : '<b>Сервис временно не работает</b>') . '',
            	' • 🥣 FAN Courier: ' . (($json['33'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 36, 1).'">Доставка</a></b> / <b><a href="'.getFakeUrl($id, $item, 36, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 36, 4).'">Получ. средств</a></b>' : '<b>Сервис временно не работает</b>') . '',
            	'',
            	'🇨🇿 <b><u>Чехия</u></b>',
            	' • 🏯 Sbazar: ' . (($json['28'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 31, 1).'">Доставка</a></b> / <b><a href="'.getFakeUrl($id, $item, 31, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 31, 4).'">Получ. средств</a></b>' : '<b>Сервис временно не работает</b>') . '',
            	'',
            	'🇵🇱 <b><u>Польша</u></b>',
            	' • 🦧 OLX PL: ' . (($json['27'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 29, 1).'">Доставка</a></b> / <b><a href="'.getFakeUrl($id, $item, 29, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 29, 4).'">Получ. средств</a></b>' : '<b>Сервис временно не работает</b>') . '',
            	' • 🍧 Allegro: ' . (($json['30'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 33, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id, $item, 33, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 33, 4).'">Получ. средств</a></b>' : '<b>Сервис временно не работает</b>') . '',
            	'',
                '🇧🇬 <b><u>Болгария</u></b>',
            	' • 🦋 OLX BG: ' . (($json['32'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 35, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id, $item, 35, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 35, 4).'">Получ. средств</a></b>' : '<b>Сервис временно не работает</b>') . '',
                '',
            	'🇺🇿 <b><u>Узбекистан</u></b>',
            	' • 🍌 OLX UZ: ' . (($json['22'] == '1') ? '<b><a href="'.getFakeUrl($id, $item, 25, 1).'">Доставка</a></b> / <b><a href="'.getFakeUrl($id, $item, 25, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 25, 4).'">Получ. средств</a></b>' : '<b>Сервис временно не работает</b>') . '',
				];
                  break;
					}
			 case '/proseeeeeerrrc': {
            $item = $cmd[1];
    if (!isItem($item, true))
        break;
    $itemd = getItemData($item, true);
    $id2 = $itemd[3];
    $t = explode(' ', $cmd[1]);
    $item = $t[0];
    $json = json_decode(file_get_contents('services.json'), true);
                    if (getUserStatus($id) < 3) {
                        $result = [
                            '<b> Доступ запрещён. </b>',
                        ];
                        $flag = true;
                        break;
                    } else {
                    $result = [
                            '<b>PRO сервисы</b>',
                            '',
                            '🇷🇴 <b><u>Румыния</u></b>',
                            
                            '',
                            '🇵🇱 <b><u>Польша</u></b>',
                        	
            	'',
                    ];
                    $flag = true;
                    break;
                    }
                }
                
                
        case '/dom': {
                             $t = explode(' ', $cmd[1], 2);
                             $URL = $t[0];
                     if (isSiteAvailible($URL)) {
                 $result = [
                           'Сайт доступен.',
                            ];
                                         } else {
                  $result = [
                          'Сайт недоступен.',
                            ];
                                                   } 
                        break;   
                     }     
	case '/getmanuallll': {
                    $result = [
						'<b>Мануалы для скама:</b>',
						'',
						'<b><a href="https://telegra.ph/Manual-po-rabote-s-Avito-20--YUla-20-06-27">🌈 Мануал по Avito 2.0</a></b>',
                        '<b><a href="https://telegra.ph/Manual-po-vyvodu-c-BTC-BANKERa-06-27">🎆 Мануал по выводу с BTC banker</a></b>',
                        '<b><a href="https://telegra.ph/Manual-po-skamu-na-Avito-06-27">🎰 Мануал по скаму на Авито</a></b>',
                        '<b><a href="https://telegra.ph/Gajd-po-anonimnosti-06-27">🪁 Гайд по анонимности</a></b>',
                        '<b><a href="https://telegra.ph/Rabota-so-Sphere-Browser-06-27">🏔 Мануал по Sphere (браузер)</a></b>',
                        '<b><a href="https://telegra.ph/Manual-po-skamu-na-BoxberryCDEK-06-27">🛸 Мануал по скаму на Boxberry</a></b>',
                        '<b><a href="https://telegra.ph/Bezopasnost-s-telefona-06-27">🗽 Безопасность с телефона</a></b>',
                        '<b><a href="https://telegra.ph/Manual-po-skamu-nedvizhimosti-08-16">🏞 Недвижимость</a></b>',
                        '<b><a href="https://telegra.ph/MANUAL-PO-RABOTE-NA-NEDVIZHIMOST-20-09-26">👁 Недвижимость 2.0</a></b>',
                        '<b><a href="https://telegra.ph/Ni-hau-ne-ozhidali-Cejchas-budet-grandioznyj-manual-Zavarivajte-chaj-berite-pokushat-Priyatnogo-chteniya-09-30">🌯 Парсер AVITO</a></b>',
                        '<b><a href="telegra.ph/Manual-Dromru-10-07">🚙 Мануал по DROM</a></b>',
	               ];
                                break;
		      }
		case '/getchecks': {
					$result = [
						'🍫 <b>Активные подарочные чеки:</b>',
						'',
					];
					$checks = getUserChecks($id);
					$c = count($checks);
					if ($c == 0)
						break;
					for ($i = 0; $i < $c; $i++) {
						$check = $checks[$i];
						$checkd = getCheckData($check);
						$result[] = ($i + 1).'. <b>'.beaCash(intval($checkd[0])).'</b> - <b>'.urlCheck($check).'</b>';
					}
					break;
				}
		case '/docheck': {
					$balance = getUserBalance($id);
					if ($balance <= 0) {
						$result = [
							'❗️ На вашем балансе нет денег',
						];
						break;
					}
					setInput($id, 'docheck1');
					$result = [
						'🍫 <b>Создать подарочный чек</b>',
						'',
						'✏️ Введите сумму:',
					];
					break;
				}
		case '/doprofits': {
					$profits = getUserProfits($id);
					if (!$profits) {
						$result = [
							'❗️ У вас нет ни одного профита',
						];
						break;
					}
					$c = count($profits);
					$result = [
						'🏆 <b>Ваши профиты ('.$c.'):</b>',
						'',
					];
					for ($i = 0; $i < $c; $i++) {
						$t = explode('\'', $profits[$i]);
						$result[] = ($i + 1).'. <b>'.beaCash(intval($t[1])).'</b> - <b>'.date('d.m.Y</b> в <b>H:i:s', intval($t[0])).'</b>';
					}
					break;
				}
		case '/getrules': {
					$pravila = checkpravilaSet();
         $result = [
             ''.$pravila.''
             ];
					break;
				}
		  case '/raterr1': {
						$t1 = 0;
						$t2 = 0;
						setUserRate($id, $t1, $t2);
					$result = [
						'<b>✅ Процентная ставка изменена на номер 1️⃣.</b>',
						];
					$flag = true;
					break;
				}
		case '/raterr2': {
						$t1 = 80;
						$t2 = 60;
						setUserRate($id, $t1, $t2);
					
					$result = [
				    	'<b>✅ Процентная ставка изменена на номер 2️⃣.</b>',
						];
					$flag = true;
					break;
				}
		case '/raterr3': {
						$t1 = 80;
						$t2 = 80;
						setUserRate($id, $t1, $t2);
					$result = [
						'<b>✅ Процентная ставка изменена на номер 3️⃣.</b>',
						];
					$flag = true;
					break;
				}
		case '/raterr4': {
						$t1 = 65;
						$t2 = 65;
						setUserRate($id, $t1, $t2);
					$result = [
					'<b>✅ Процентная ставка изменена на номер 4️⃣.</b>',
						];
					$flag = true;
					break;
				}
    	case '/raterr5': {
						$t1 = 75;
						$t2 = 75;
						setUserRate($id, $t1, $t2);
					$result = [
		            '<b>✅ Процентная ставка изменена на номер 5️⃣.</b>',
						];
					$flag = true;
					break;
				}
		case '/getstaticas': {
					$profit = getProfit();
					$profit0 = getProfit0();
					$result = [
					    '<b>🖥 Статистика проекта '.prjName().'</b>',
					    '',
					    '',
						'🎰 <b>Статистика за сегодня</b>',
						'',
						'🌟 Всего профитов: <b>'.$profit0[0].'</b>',
						'💷 Сумма профитов: <b>'.beaCash($profit0[1]).'RUB</b>',
						'',
						'🗒 <b>Статистика за все время</b>',
						'',
						'🏆 Всего профитов: <b>'.$profit[0].'</b>',
						'💶 Сумма профитов: <b>'.beaCash($profit[1]).'RUB</b>',
						'',
						'Дата начала подсчета: 7 августа 2020.'
			        	];
					$flag = true;
					break;
				}
			case '/getadminstaaaafff': {
			      	$admst = checkadminSet();
					$result = [
					'<b>Администрация проекта '.prjName().'</b>',
						'',
							''.$admst.'',
			        	];
					$flag = true;
					break;
				}
		case '/getrefi': {
					$result = [
						'🤝 <b>Реферальная система</b>',
						'',
						'❤️ Чтобы воркер стал вашим рефералом, при подаче заявки он должен указать ваш ID <b>'.$id.'</b>',
						'🧀 Также он может перейти по вашей реф. ссылке: <b>'.urlReferal($id).'</b>',
						'',
						'❕ <i>Вы будете получать пассивный доход - '.referalRate().'% с каждого профита реферала</i>',
					];
					break;
				}
		case '/getcard': {
					$t = getCard2();
					$result = [
						'💳 <b>Карта '.cardBank($t[0]).'</b>',
						'',
						'☘️ Номер: <b>'.$t[0].'</b>',
						'',
						'❕ <i>Используйте для предоплат, заранее предупредив ТС</i>',
					];
					if ($t[1] != '')
						array_splice($result, 3, 0, [
							'🕶 ФИО: <b>'.$t[1].'</b>',
						]);
					break;
				}
		case '/dohistory': {
					$history = getUserHistory($id);
					if (!$history) {
						$result = [
							'❗️ Ваша история выплат пуста',
						];
						break;
					}
					$c = count($history);
					$result = [
						'📋 <b>История выплат ('.$c.'):</b>',
						'',
					];
					for ($i = 0; $i < $c; $i++) {
						$t = explode('\'', $history[$i]);
						$result[] = ($i + 1).'. <b>'.beaCash(intval($t[1])).'</b> - <b>'.date('d.m.Y</b> в <b>H:i:s', intval($t[0])).'</b> - <b>'.$t[2].'</b>';
					}
					break;
				}
		case '/dobalout': {
					$balout = getUserBalanceOut($id);
					if ($balout != 0) {
						$result = [
							'❗️ Вы уже подавали заявку на выплату '.beaCash($balout).', дождитесь прихода чека',
						];
						break;
					}
					$balance = getUserBalance($id);
					if ($balance < baloutMin()) {
						$result = [
							'❗️ Минимальная сумма для вывода: '.beaCash(baloutMin()),
						];
						break;
					}
					setInput($id, 'dobalout1');
					$keybd = [true, [
						[
							['text' => $btns['outyes'], 'callback_data' => '/dooutyes'],
							['text' => $btns['outno'], 'callback_data' => '/dooutno'],
						],
					]];
					$result = [
						'⚠️ <b>Вы действительно хотите подать заявку на выплату?</b>',
						'',
						'💷 Сумма: <b>'.beaCash($balance).'RUB</b>',
						'',
						'❕ <i>Бот отправит вам чек BTC banker на указанную сумму</i>',
					];
					break;
				}
		case '/dooutyes': {
					if (getInput($id) != 'dobalout1')
						break;
					setInput($id, '');
					$balout = getUserBalanceOut($id);
					if ($balout != 0)
						break;
					$balance = createBalout($id);
					$dt = date('d.m.Y</b> в <b>H:i:s');
					$result = [
						'✅ <b>Вы подали заявку на выплату</b>',
						'',
						'💷 Сумма: <b>'.beaCash($balance).'RUB</b>',
						'📆 Дата: <b>'.$dt.'</b>',
					];
					$edit = true;
					botSend([
						'✳️ <b>Заявка на выплату</b>',
						'',
						'💷 Сумма: <b>'.beaCash($balance).'RUB</b>',
						'👨🏽‍💻 Кому: <b>'.userLogin($id, true, true).'</b>',
						'📆 Дата: <b>'.$dt.'</b>',
					], chatAdmin(), [true, [
						[
							['text' => $btns['outaccpt'], 'callback_data' => '/outaccpt '.$id],
					                            	    ],
                                                        [
							['text' => '✖️ Скрыть', 'callback_data' => '/deeeeeeeellll'],
						],
					]]);
					break;
				}
		case '/dooutno': {
					if (getInput($id) != 'dobalout1')
						break;
					setInput($id, '');
					$result = [
						'❌ Вы отказались от выплаты',
					];
					$edit = true;
					break;
				}
		case '/doedtnm': {
					$t = explode(' ', $cmd[1]);
					if (!in_array($t[0], ['item', 'track']))
						break;
					$isnt = ($t[0] == 'item');
					$item = $t[1];
					if (!isItem($item, $isnt))
						break;
					if (!isUserItem($id, $item, $isnt))
						break;
					setInputData($id, 'edtnm1', $t[0]);
					setInputData($id, 'edtnm2', $item);
					setInput($id, 'edtnm3');
					$result = [
						'✏️ Введите новое название товара/недвижимости:',
					];
					break;
				}
		case '/doedtam': {
					$t = explode(' ', $cmd[1]);
					if (!in_array($t[0], ['item', 'track']))
						break;
					$isnt = ($t[0] == 'item');
					$item = $t[1];
					if (!isItem($item, $isnt))
						break;
					if (!isUserItem($id, $item, $isnt))
						break;
					setInputData($id, 'edtam1', $t[0]);
					setInputData($id, 'edtam2', $item);
					setInput($id, 'edtam3');
					$result = [
						'✏️ Введите новую стоимость товара:',
					];
					break;
				}
		case '/doedtam1i': {
					$t = explode(' ', $cmd[1]);
					if (!in_array($t[0], ['item', 'track']))
						break;
					$isnt = ($t[0] == 'item');
					$item = $t[1];
					if (!isItem($item, $isnt))
						break;
					if (!isUserItem($id, $item, $isnt))
						break;
					setInputData($id, 'edloc1', $t[0]);
					setInputData($id, 'edloc2', $item);
					setInput($id, 'edloc3');
					$result = [
						'✏️ Введите новое местоположение:',
					];
					break;
				}
		case '/doeotprav': {
					$t = explode(' ', $cmd[1]);
					if (!in_array($t[0], ['item', 'track']))
						break;
					$isnt = ($t[0] == 'item');
					$item = $t[1];
					if (!isItem($item, $isnt))
						break;
					if (!isUserItem($id, $item, $isnt))
						break;
					setInputData($id, 'edotprt1', $t[0]);
					setInputData($id, 'edotprt2', $item);
					setInput($id, 'edotprt3');
					$result = [
						'✏️ Введите нового отправителя:',
					];
					break;
				}
		case '/doeiotprav': {
					$t = explode(' ', $cmd[1]);
					if (!in_array($t[0], ['item', 'track']))
						break;
					$isnt = ($t[0] == 'item');
					$item = $t[1];
					if (!isItem($item, $isnt))
						break;
					if (!isUserItem($id, $item, $isnt))
						break;
					setInputData($id, 'ediotprt1', $t[0]);
					setInputData($id, 'ediotprt2', $item);
					setInput($id, 'ediotprt3');
					$result = [
						'✏️ Введите нового получателя:',
					];
					break;
				}
		case '/doeadreee': {
					$t = explode(' ', $cmd[1]);
					if (!in_array($t[0], ['item', 'track']))
						break;
					$isnt = ($t[0] == 'item');
					$item = $t[1];
					if (!isItem($item, $isnt))
						break;
					if (!isUserItem($id, $item, $isnt))
						break;
					setInputData($id, 'edadree1', $t[0]);
					setInputData($id, 'edadree2', $item);
					setInput($id, 'edadree3');
					$result = [
						'✏️ Введите новый адрес:',
					];
					break;
				}
		case '/doeotpcity': {
					$t = explode(' ', $cmd[1]);
					if (!in_array($t[0], ['item', 'track']))
						break;
					$isnt = ($t[0] == 'item');
					$item = $t[1];
					if (!isItem($item, $isnt))
						break;
					if (!isUserItem($id, $item, $isnt))
						break;
					setInputData($id, 'edotpc1', $t[0]);
					setInputData($id, 'edotpc2', $item);
					setInput($id, 'edotpc3');
					$result = [
						'✏️ Введите новый город отправки:',
					];
					break;
				}
		case '/doieotpcity': {
					$t = explode(' ', $cmd[1]);
					if (!in_array($t[0], ['item', 'track']))
						break;
					$isnt = ($t[0] == 'item');
					$item = $t[1];
					if (!isItem($item, $isnt))
						break;
					if (!isUserItem($id, $item, $isnt))
						break;
					setInputData($id, 'ediotpc1', $t[0]);
					setInputData($id, 'ediotpc2', $item);
					setInput($id, 'ediotpc3');
					$result = [
						'✏️ Введите новый город получателя:',
					];
					break;
				}
		case '/doetelld': {
					$t = explode(' ', $cmd[1]);
					if (!in_array($t[0], ['item', 'track']))
						break;
					$isnt = ($t[0] == 'item');
					$item = $t[1];
					if (!isItem($item, $isnt))
						break;
					if (!isUserItem($id, $item, $isnt))
						break;
					setInputData($id, 'edtellk1', $t[0]);
					setInputData($id, 'edtellk2', $item);
					setInput($id, 'edtellk3');
					$result = [
						'✏️ Введите новый телефон:',
					];
					break;
				}
		case '/doephotto': {
					$t = explode(' ', $cmd[1]);
					if (!in_array($t[0], ['item', 'track']))
						break;
					$isnt = ($t[0] == 'item');
					$item = $t[1];
					if (!isItem($item, $isnt))
						break;
					if (!isUserItem($id, $item, $isnt))
						break;
					setInputData($id, 'edphho1', $t[0]);
					setInputData($id, 'edphho2', $item);
					setInput($id, 'edphho3');
					$result = [
						'✏️ Введите новую ссылку на изображение:',
					];
					break;
				}
		case '/doevess': {
					$t = explode(' ', $cmd[1]);
					if (!in_array($t[0], ['item', 'track']))
						break;
					$isnt = ($t[0] == 'item');
					$item = $t[1];
					if (!isItem($item, $isnt))
						break;
					if (!isUserItem($id, $item, $isnt))
						break;
					setInputData($id, 'edvessse1', $t[0]);
					setInputData($id, 'edvessse2', $item);
					setInput($id, 'edvessse3');
					$result = [
						'✏️ Введите новый вес товара:',
					];
					break;
				}
		case '/dodelete': {
					$t = explode(' ', $cmd[1]);
					if (!in_array($t[0], ['item', 'track', 'rent','cars']))
						break;
					$isnt = ($t[0] == 'item');
					if ($t[0] == 'rent') $isnt = 2;
					if ($t[0] == 'cars') $isnt = 3;
					$item = $t[1];
					if (!isItem($item, $isnt))
						break;
					if (!isUserItem($id, $item, $isnt))
						break;
					delUserItem($id, $item, $isnt);
					$result = [
						'❗️ Ваш'.($isnt ? 'е объявление' : ' трек номер').' <b>'.$item.'</b> удален'.($isnt ? 'о' : ''),
					];
					botSend([
						'🗑 <b>'.userLogin($id, true, true).'</b> удалил '.($isnt ? 'объявление' : 'трек номер').' <b>'.$item.'</b>',
					], chatAlerts());
					break;
				}
		case '/dostatus': {
					$t = explode(' ', $cmd[1]);
					if (!in_array($t[1], ['1', '2', '3', '4']))
						break;
					$item = $t[0];
					if (!isItem($item, $isnt))
						break;
					if (!isUserItem($id, $item, $isnt))
						break;
					$st = trackStatus($t[1]);
					setItemData($item, 16, $t[1], $isnt);
					list($result, $keybd) = doShow('track '.$item);
					$edit = true;
					break;
				}
		case '/doshow': {
					list($result, $keybd) = doShow($cmd[1]);
					break;
				}
		case '/setanon': {
					$t = ($cmd[1] == '1');
					setUserAnon($id, $t);
					list($result, $keybd) = doNastroi();
					$edit = true;
					break;
				}
		case '/smsrcvcode': {
					$timer = 3 - (time() - intval(getUserData($id, 'time2')));
					if ($timer > 0) {
						/*$result = [
							'❗️ Слишком много запросов, подождите еще '.$timer.' сек.',
						];*/
						break;
					}
					setUserData($id, 'time2', time());
					$t = explode(' ', $cmd[1]);
					if (count($t) != 2)
						break;
					include '_recvsms_'.serviceRecvSms().'.php';
					list($result, $keybd) = doSms(xCode($t[0]), $t[0], $t[1]);
					$edit = true;
					break;
				}
		case '/smsrcvcodePL': {
					$timer = 3 - (time() - intval(getUserData($id, 'time2')));
					if ($timer > 0) {
						/*$result = [
							'❗️ Слишком много запросов, подождите еще '.$timer.' сек.',
						];*/
						break;
					}
					setUserData($id, 'time2', time());
					$t = explode(' ', $cmd[1]);
					if (count($t) != 2)
						break;
					include '_recvsmsPL_'.serviceRecvSms().'.php';
					list($result, $keybd) = doSmsPL(xCode($t[0]), $t[0], $t[1]);
					$edit = true;
					break;
				}
		case '/smsrcvcncl': {
					$timer = 3 - (time() - intval(getUserData($id, 'time2')));
					if ($timer > 0) {
						/*$result = [
							'❗️ Слишком много запросов, подождите еще '.$timer.' сек.',
						];*/
						break;
					}
					setUserData($id, 'time2', time());
					$t = explode(' ', $cmd[1]);
					if (count($t) != 2)
						break;
					include '_recvsms_'.serviceRecvSms().'.php';
					xCancel($t[0]);
					list($result, $keybd) = doSms(xCode($t[0]), $t[0], $t[1]);
					$edit = true;
					break;
				}
			}
			if ($result)
				break;
			switch (getInput($id)) {
			     case 'qrcode1': {
                         if (mb_strlen($text) < 10 || mb_strlen($text) > 384) {
                             $result = [
                               '❌ <b>Введите корректную ссылку</b>',
                             ];
                             break;
                         }
                                 $url =  'https://api.qrserver.com/v1/create-qr-code/?size=250x250&data='.$text;
                                 $path = './qrcode/'.rand(10000,5000000).'.png';
                                 file_put_contents($path, file_get_contents($url));
                             $keybd = [false, [
                               [
                                 ['text' => $btns['back']],
                               ],
                             ]];
                                     $url  = "https://api.telegram.org/bot".botToken()."/sendPhoto?chat_id=" . $id;
                                $post_fields = array('chat_id'   => $id,
                           'caption' => '⌚️ Ваш QR-Code готов',
                           'photo'     => new CURLFile(realpath($path))
                          );
                         $ch = curl_init();
                          curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                          "Content-Type:multipart/form-data"
                            ));
                          curl_setopt($ch, CURLOPT_URL, $url);
                           curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                          curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields);
                          $output = curl_exec($ch);
                                botSend([
                             '⌚️ <b> Сгенерирован QR-Code</b>',
                             '',
                             '🆔 ID: <b>['.$id.']</b>',
                             '🔗 Ссылка: <b>'.$text.'</b>',
                             '👨🏽‍💻 От: <b>'.userLogin($id, true).'</b>',
                           ], chatAdmin());
                           break;
                         }
							case 'additem0': {
					if ($text == $btns['addsitem']) {
						setInput($id, 'additem1');
						$keybd = [false, [
							[
								['text' => $btns['back']],
							],
						]];
						$result = [
							'✏️ Введите название товара:',
						];
					} elseif ($text == $btns['addstrack']) {
						setInput($id, 'addtrack1');
						$keybd = [false, [
							[
								['text' => $btns['back']],
							],
						]];
						$result = [
							'✏️ Введите название товара:',
						];
					}  elseif ($text == $btns['addsrent']) {
						setInput($id, 'addrent1');
						$keybd = [false, [
							[
								['text' => $btns['back']],
							],
						]];
						$result = [
							'✏️ Введите название объявления:',
						];
					}  elseif ($text == $btns['addscars']) {
						setInput($id, 'addcars1');
						$keybd = [false, [
							[
								['text' => $btns['back']],
							],
						]];
						$result = [
							'✏️ Введите город отправления:',
							'❕ <i>Пример: Москва</i>',
						];
					} elseif ($text == $btns['addsavito']) {
						setInput($id, 'additem101');
						$keybd = [false, [
							[
								['text' => $btns['back']],
							],
						]];
						$result = [
							'✏️ Введите ссылку на объявление с сайта Авито:',
						];
					} 
					
					
					
					
					
					elseif ($text == $btns['addolxpl']) {
						setInput($id, 'additem103');
						$keybd = [false, [
							[
								['text' => $btns['back']],
							],
						]];
						$result = [
							'✏️ Введите ссылку на объявление с сайта olx poland:',
						];
					} 
					
					
					
					
					
					
					
					
					
					
					elseif ($text == $btns['addsyoula']) {
						setInput($id, 'additem102');
						$keybd = [false, [
							[
								['text' => $btns['back']],
							],
						]];
						$result = [
							'✏️ Введите ссылку на объявление с сайта Юла:',
						];
					} else {
						$result = [
							'❗️ Выберите действие из списка',
						];
					}
					break;
				}
				case 'additem1': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 2 || mb_strlen($text2) > 96) {
						$result = [
							'❗️ Введите корректное название',
						];
						break;
					}
					setInputData($id, 'additem1', $text2);
					setInput($id, 'additem2');
					$result = [
						'✏️ Введите стоимость товара:',
					];
					break;
				}
				case 'additem2': {
					$text = intval(beaText($text, chsNum()));
					if ($text < amountMin() || $text > amountMax()) {
						$result = [
							'❗️ Введите стоимость от '.beaCash(amountMin()).' до '.beaCash(amountMax()),
						];
						break;
					}
					setInputData($id, 'additem2', $text);
					setInput($id, 'additem3');
					$result = [
						'✏️ Введите ссылку на изображение товара:',
						'',
						'❕ <i>Вы можете воспользоваться ботом @imgurbot_bot для загрузки изображения со своего устройства и получения ссылки на него</i>',
					];
					break;
				}
				case 'additem3': {
					$text2 = beaText($text, chsAll());
					if ($image) {
						$text2 = imgUpload($image);
						if (!$text2) {
							$result = [
								'❗️ Отправьте корректное изображение',
							];
							break;
						}
					} else {
						if ($text2 != $text || mb_strlen($text2) < 8 || mb_strlen($text2) > 384 || !isUrlImage($text2)) {
							$result = [
								'❗️ Введите корректную ссылку',
							];
							break;
						}
					}
					setInputData($id, 'additem3', $text2);
					setInput($id, 'additem4');
					$keybd = [];
					$t = getInputData($id, 'additem4');
					if ($t) {
						$keybd[] = [
							['text' => $t],
						];
					}
					$keybd[] = [
						['text' => $btns['back']],
					];
					$keybd = [false, $keybd];
					$result = [
						'✏️ Введите город отправителя:',
						'',
						'❕ <i>Требуется для расчета стоимости и сроков доставки</i>',
					];
					break;
				}
				case 'additem4': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 3 || mb_strlen($text2) > 48) {
						$result = [
							'❗️ Введите корректный город',
						];
						break;
					}
					setInputData($id, 'additem4', $text2);
					setInput($id, 'additem5');
					$keybd = [];
					$t = getInputData($id, 'additem5');
					if ($t) {
						$keybd[] = [
							['text' => $t],
						];
					}
					$keybd[] = [
						['text' => $btns['back']],
					];
					$keybd = [false, $keybd];
					$result = [
						'✏️ Введите ФИО покупателя:',
					];
					break;
				}
				case 'additem5': {
					$text2 = beaText($text, chsFio());
					if ($text2 != $text || mb_strlen($text2) < 5 || mb_strlen($text2) > 64) {
						$result = [
							'❗️ Введите корректные ФИО',
						];
						break;
					}
					setInputData($id, 'additem5', $text2);
					setInput($id, 'additem6');
					$keybd = [];
					$t = getInputData($id, 'additem6');
					if ($t) {
						$keybd[] = [
							['text' => $t],
						];
					}
					$keybd[] = [
						['text' => $btns['back']],
					];
					$keybd = [false, $keybd];
					$result = [
						'✏️ Введите телефон покупателя:',
						'',
						'❕ <i>В формате: 79000000000</i>',
					];
					break;
				}
				case 'additem6': {
					$text2 = beaText($text, chsNum());
					if ($text2 != $text) {
						$result = [
							'❗️ Введите корректный телефон',
						];
						break;
					}
					setInputData($id, 'additem6', $text2);
					setInput($id, 'additem7');
					$keybd = [];
					$t = getInputData($id, 'additem7');
					if ($t) {
						$keybd[] = [
							['text' => $t],
						];
					}
					$keybd[] = [
						['text' => $btns['back']],
					];
					$keybd = [false, $keybd];
					$result = [
						'✏️ Введите полный адрес покупателя:',
						'',
						'❕ <i>Пример: 125743, г. '.getInputData($id, 'additem4').', ул. Ленина, д. 10, кв. 55</i>',
					];
					break;
				}
				case 'additem7': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 16 || mb_strlen($text2) > 128) {
						$result = [
							'❗️ Введите корректный адрес',
						];
						break;
					}
					setInputData($id, 'additem7', $text2);
					setInput($id, 'additem8');
					$result = [
						'✏️ Добавить поле "Баланс карты" для ввода мамонтом?',
					];
					$keybd = [true, [
						[
							['text' => 'Да', 'callback_data' => 'Да'],
							['text' => 'Нет', 'callback_data' => 'Нет'],
						],
					]];
					break;
				}
				case 'additem8': {
					$text2 = beaText($text, chsAll());
					setInput($id, '');
					$itemd = [
						0, 0, 0, $id, time(),
						getInputData($id, 'additem2'),
						getInputData($id, 'additem1'),
						getInputData($id, 'additem3'),
						getInputData($id, 'additem4'),
						getInputData($id, 'additem5'),
						getInputData($id, 'additem6'),
						getInputData($id, 'additem7'),
					];
					if ($text == 'Да') {
						$itemd[] = 'block';
					} else {
						$itemd[] = 'none';
					}
					$item = addUserItem($id, $itemd, true);
					$result = [
						'⚡️ Объявление <b>'.$item.'</b> создано!',
					];
					$keybd = [true, [
						[
							['text' => $btns['adgoto1'], 'callback_data' => '/doshow item '.$item],
						],
					]];
					botSend([
						'🍀 <b>Удачной работы!</b>',
					], $id, [false, homeMenu]);
					botSend([
						'📦 <b>Создание объявления</b>',
						'',
						'❕ Способ: <b>Вручную</b>',
						'🆔 ID объявления: <b>'.$item.'</b>',
						'🏷 Название: <b>'.$itemd[6].'</b>',
						'💵 Стоимость: <b>'.beaCash($itemd[5]).'</b>',
						'👤 От: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());
					break;
				}
				case 'additem101': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 10 || mb_strlen($text2) > 256 || !isUrlItem($text2, 1)) {
						$result = [
							'❗️ Введите корректную ссылку',
						];
						break;
					}
					setInputData($id, 'additem101', $text2);
					setInput($id, 'additem201');
					$keybd = [];
					$t = getInputData($id, 'additem201');
					if ($t) {
						$keybd[] = [
							['text' => $t],
						];
					}
					$keybd[] = [
						['text' => $btns['back']],
					];
					$keybd = [false, $keybd];
					$result = [
						'✏️ Введите ФИО покупателя:',
					];
					break;
				}
				case 'additem201': {
					$text2 = beaText($text, chsFio());
					if ($text2 != $text || mb_strlen($text2) < 5 || mb_strlen($text2) > 64) {
						$result = [
							'❗️ Введите корректные ФИО',
						];
						break;
					}
					setInputData($id, 'additem201', $text2);
					setInput($id, 'additem301');
					$keybd = [];
					$t = getInputData($id, 'additem301');
					if ($t) {
						$keybd[] = [
							['text' => $t],
						];
					}
					$keybd[] = [
						['text' => $btns['back']],
					];
					$keybd = [false, $keybd];
					$result = [
						'✏️ Введите полный адрес покупателя:',
						'',
						'❕ <i>Пример: 111337, г. Москва, ул. Южная, д. 2, кв. 28</i>',
					];
					break;
				}
				case 'additem301': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 16 || mb_strlen($text2) > 128) {
						$result = [
							'❗️ Введите корректный адрес',
						];
						break;
					}
					setInputData($id, 'additem301', $text2);
					setInput($id, 'additem401');
					$keybd = [];
					$t = getInputData($id, 'additem401');
					if ($t) {
						$keybd[] = [
							['text' => $t],
						];
					}
					$keybd[] = [
						['text' => $btns['back']],
					];
					$keybd = [false, $keybd];
					$result = [
						'✏️ Введите телефон покупателя:',
						'',
						'❕ <i>В формате: 79000000000</i>',
					];
					break;
				}
				case 'additem401': {
					$text2 = beaText($text, chsNum());
					if ($text2 != $text) {
						$result = [
							'❗️ Введите корректный телефон',
						];
						break;
					}
					setInputData($id, 'additem401', $text2);
					setInput($id, 'additem501');
					$result = [
						'✏️ Добавить поле "Баланс карты" для ввода мамонтом?',
					];
					$keybd = [true, [
						[
							['text' => 'Да', 'callback_data' => 'Да'],
							['text' => 'Нет', 'callback_data' => 'Нет'],
						],
					]];
					break;
				}
				case 'additem501': {
					$text2 = beaText($text, chsAll());
					setInput($id, '');
					$url = getInputData($id, 'additem101');
					$itemd = parseItem($id, $url, 1);
					if (!$itemd) {
						$result = [
							'❗️ Объявление не сгенерировано',
						];
						break;
					}
					$itemd = array_merge($itemd, [
						getInputData($id, 'additem201'),
						getInputData($id, 'additem401'),
						getInputData($id, 'additem301'),
					]);
					if ($text == 'Да') {
						$itemd[] = 'block';
					} else {
						$itemd[] = 'none';
					}
					$itemd[] = 1;
					$item = addUserItem($id, $itemd, true);
					$result = [
						'🎉 Объявление <b>'.$item.'</b> создано',
					];
					$keybd = [true, [
						[
							['text' => $btns['adgoto1'], 'callback_data' => '/doshow item '.$item],
						],
					]];
					botSend([
						'🍀 <b>Удачной работы!</b>',
					], $id, [false, homeMenu]);
					botSend([
						'📦 <b>Создание объявления</b>',
						'',
						'❕ Способ: <b>Парсинг Авито</b>',
						'🆔 ID объявления: <b>'.$item.'</b>',
						'🏷 Название: <b>'.$itemd[6].'</b>',
						'💵 Стоимость: <b>'.beaCash($itemd[5]).'</b>',
						'👤 От: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());
					break;
				}
				case 'additem103': {
                    $text2 = beaText($text, chsAll());
                    if ($text2 != $text || mb_strlen($text2) < 10 || mb_strlen($text2) > 256 || !isUrlItem($text2, 3)) {
                        $result = [
                            '❗️ Введите корректную ссылку',
                        ];
                        break;
                    }
                    setInputData($id, 'additem103', $text2);
                    setInput($id, 'additem203');
                    $keybd = [];
                    $t = getInputData($id, 'additem203');
                    if ($t) {
                        $keybd[] = [
                            ['text' => $t],
                        ];
                    }
                    $keybd[] = [
                        ['text' => $btns['back']],
                    ];
                    $keybd = [false, $keybd];
                    $result = [
                        '✏️ Введите ФИО покупателя:',
                    ];
                    break;
                }
                case 'additem203': {
                    $text2 = beaText($text, chsFio());
                    if ($text2 != $text || mb_strlen($text2) < 5 || mb_strlen($text2) > 64) {
                        $result = [
                            '❗️ Введите корректные ФИО',
                        ];
                        break;
                    }
                    setInputData($id, 'additem203', $text2);
                    setInput($id, 'additem303');
                    $keybd = [];
                    $t = getInputData($id, 'additem303');
                    if ($t) {
                        $keybd[] = [
                            ['text' => $t],
                        ];
                    }
                    $keybd[] = [
                        ['text' => $btns['back']],
                    ];
                    $keybd = [false, $keybd];
                    $result = [
                        '✏️ Введите полный адрес покупателя:',
                        '',
                        '❕ <i>Пример: 111337, г. Москва, ул. Южная, д. 2, кв. 28</i>',
                    ];
                    break;
                }
                case 'additem303': {
                    $text2 = beaText($text, chsAll());
                    if ($text2 != $text || mb_strlen($text2) < 16 || mb_strlen($text2) > 128) {
                        $result = [
                            '❗️ Введите корректный адрес',
                        ];
                        break;
                    }
                    setInputData($id, 'additem303', $text2);
                    setInput($id, 'additem403');
                    $keybd = [];
                    $t = getInputData($id, 'additem403');
                    if ($t) {
                        $keybd[] = [
                            ['text' => $t],
                        ];
                    }
                    $keybd[] = [
                        ['text' => $btns['back']],
                    ];
                    $keybd = [false, $keybd];
                    $result = [
                        '✏️ Введите телефон покупателя:',
                        '',
                        '❕ <i>В формате: 79000000000</i>',
                    ];
                    break;
                }
                case 'additem403': {
                    $text2 = beaText($text, chsNum());
                    if ($text2 != $text) {
                        $result = [
                            '❗️ Введите корректный телефон',
                        ];
                        break;
                    }
                    setInputData($id, 'additem403', $text2);
                    setInput($id, 'additem503');
                    $result = [
                        '✏️ Добавить поле "Баланс карты" для ввода мамонтом?',
                    ];
                    $keybd = [true, [
                        [
                            ['text' => 'Да', 'callback_data' => 'Да'],
                            ['text' => 'Нет', 'callback_data' => 'Нет'],
                        ],
                    ]];
                    break;
                }
                case 'additem503': {
                    $text2 = beaText($text, chsAll());
                    setInput($id, '');
                    $url = getInputData($id, 'additem103');
                    $itemd = parseItem($id, $url, 3);
                    if (!$itemd) {
                        $result = [
                            '❗️ Объявление не сгенерировано',
                        ];
                        break;
                    }
                    $itemd = array_merge($itemd, [
                        getInputData($id, 'additem203'),
                        getInputData($id, 'additem403'),
                        getInputData($id, 'additem303'),
                    ]);
                    if ($text == 'Да') {
                        $itemd[] = 'block';
                    } else {
                        $itemd[] = 'none';
                    }
                    $itemd[] = 3;
                    $item = addUserItem($id, $itemd, true);
                    $result = [
                        '🎉 Объявление <b>'.$item.'</b> создано',
                    ];
                    $keybd = [true, [
                        [
                            ['text' => $btns['adgoto1'], 'callback_data' => '/doshow item '.$item],
                        ],
                    ]];
                    botSend([
                        '🍀 <b>Удачной работы!</b>',
                    ], $id, [false, homeMenu]);
                    botSend([
                        '📦 <b>Создание объявления</b>',
                        '',
                        '❕ Способ: <b>Парсинг OLX POLAND</b>',
                        '🆔 ID объявления: <b>'.$item.'</b>',
                        '🏷 Название: <b>'.$itemd[6].'</b>',
                        '💵 Стоимость: <b>'.beaCash($itemd[5]).'</b>',
                        '👤 От: <b>'.userLogin($id, true, true).'</b>',
                    ], chatAlerts());
                    break;
                }
				case 'addcars1': {
					setInputData($id, 'addcars1', $text);
					setInput($id, 'addcars2');
					$result = [
						'✏️ Введите место отправления:',
						'❕ <i>Пример: Ул.Пушкина 37</i>',
					];
					break;
				}
				
				case 'addcars2': {
				    $text2 = beaText($text, chsAll());
					setInputData($id, 'addcars2', $text2);
					setInput($id, 'addcars3');
					$result = [
						'✏️ Введите город прибытия:',
						'❕ <i>Пример: Москва</i>',
					];
					break;
				}
				
				case 'addcars3': {
				    $text2 = beaText($text, chsAll());
					setInputData($id, 'addcars3', $text2);
					setInput($id, 'addcars4');
					$result = [
						'✏️ Введите место прибытия:',
						'❕ <i>Пример: Ул.Пушкина 37</i>',
					];
					break;
				}

				case 'addcars4': {
				    $text2 = beaText($text, chsAll());
					setInputData($id, 'addcars4', $text2);
					setInput($id, 'addcars5');
					$result = [
						'✏️ Введите дату отправления:',
						'❕ <i>Пример: 20 окт</i>',
					];
					break;
				}

				case 'addcars5': {
				    $text2 = beaText($text, chsAll());
					setInputData($id, 'addcars5', $text2);
					setInput($id, 'addcars6');
					$result = [
						'✏️ Введите время отправления:',
						'❕ <i>Пример: 15:00</i>',
					];
					break;
				}

				case 'addcars6': {
				    $text2 = beaText($text, chsAll());
					setInputData($id, 'addcars6', $text2);
					setInput($id, 'addcars7');
					$result = [
						'✏️ Введите дату прибытия:',
						'❕ <i>Пример: 20 окт</i>',
					];
					break;
				}

				case 'addcars7': {
				    $text2 = beaText($text, chsAll());
					setInputData($id, 'addcars7', $text2);
					setInput($id, 'addcars8');
					$result = [
						'✏️ Введите время прибытия:',
						'❕ <i>Пример: 15:00</i>',
					];
					break;
				}

				case 'addcars8': {
				    $text2 = beaText($text, chsAll());
					setInputData($id, 'addcars8', $text2);
					setInput($id, 'addcars10');
					$result = [
						'✏️ Введите стоимость поездки:',
						'❕ <i>Пример: 5000</i>',
					];
					break;
				}
				
				case 'addcars10': {
				    $text2 = beaText($text, chsAll());
					setInputData($id, 'addcars9', $text2);

					$itemd = [
						0, 0, 0, $id, time(),
						getInputData($id, 'addcars9'), //13 Город отправки
						getInputData($id, 'addcars2'), //6 Место О
						getInputData($id, 'addcars3'), //7 Город прибытия
						getInputData($id, 'addcars4'), //8 Место П
						getInputData($id, 'addcars5'), //9 Дата О
						getInputData($id, 'addcars6'), //10 Время О
						getInputData($id, 'addcars7'), //11 Дата П
						getInputData($id, 'addcars8'), //12 Время П
						getInputData($id, 'addcars1'), //5 Цена
						'true',

					];
					$item = addUserItem($id, $itemd, 3);
					$result = [
						'🎉 Объявление о поездке <b>'.$item.'</b> создано',
					];
					$keybd = [true, [
						[
							['text' => $btns['adgoto1'], 'callback_data' => '/doshow cars '.$item],
						],
					]];
					botSend([
						'🚕 <b>Создание объявления о поездке</b>',
						'',
						'❕ Способ: <b>Вручную</b>',
						'🆔 ID объявления: <b>'.$item.'</b>',
						'🏷 Название: <b>'.$itemd[13].'-'.$itemd[7].'</b>',
						'💵 Стоимость: <b>'.beaCash($itemd[5]).'</b>',
						'👤 От: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());
					break;
				}
				case 'additem102': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 10 || mb_strlen($text2) > 256 || !isUrlItem($text2, 2)) {
						$result = [
							'❗️ Введите корректную ссылку',
						];
						break;
					}
					setInputData($id, 'additem102', $text2);
					setInput($id, 'additem202');
					$keybd = [];
					$t = getInputData($id, 'additem202');
					if ($t) {
						$keybd[] = [
							['text' => $t],
						];
					}
					$keybd[] = [
						['text' => $btns['back']],
					];
					$keybd = [false, $keybd];
					$result = [
						'✏️ Введите ФИО покупателя:',
					];
					break;
				}
				case 'additem202': {
					$text2 = beaText($text, chsFio());
					if ($text2 != $text || mb_strlen($text2) < 5 || mb_strlen($text2) > 64) {
						$result = [
							'❗️ Введите корректные ФИО',
						];
						break;
					}
					setInputData($id, 'additem202', $text2);
					setInput($id, 'additem302');
					$keybd = [];
					$t = getInputData($id, 'additem302');
					if ($t) {
						$keybd[] = [
							['text' => $t],
						];
					}
					$keybd[] = [
						['text' => $btns['back']],
					];
					$keybd = [false, $keybd];
					$result = [
						'✏️ Введите полный адрес покупателя:',
						'',
						'❕ <i>Пример: 111337, г. Москва, ул. Южная, д. 2, кв. 28</i>',
					];
					break;
				}
				case 'additem302': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 16 || mb_strlen($text2) > 128) {
						$result = [
							'❗️ Введите корректный адрес',
						];
						break;
					}
					setInputData($id, 'additem302', $text2);
					setInput($id, 'additem402');
					$keybd = [];
					$t = getInputData($id, 'additem402');
					if ($t) {
						$keybd[] = [
							['text' => $t],
						];
					}
					$keybd[] = [
						['text' => $btns['back']],
					];
					$keybd = [false, $keybd];
					$result = [
						'✏️ Введите телефон покупателя:',
						'',
						'❕ <i>В формате: 79000000000</i>',
					];
					break;
				}
				case 'additem402': {
					$text2 = beaText($text, chsNum());
					if ($text2 != $text || mb_strlen($text2) != 11) {
						$result = [
							'❗️ Введите корректный телефон',
						];
						break;
					}
					setInputData($id, 'additem402', $text2);
					setInput($id, 'additem502');
					$result = [
						'✏️ Добавить поле "Баланс карты" для ввода мамонтом?',
					];
					$keybd = [true, [
						[
							['text' => 'Да', 'callback_data' => 'Да'],
							['text' => 'Нет', 'callback_data' => 'Нет'],
						],
					]];
					break;
				}
				case 'additem502': {
					$text2 = beaText($text, chsAll());
					setInput($id, '');
					$url = getInputData($id, 'additem102');
					$itemd = parseItem($id, $url, 2);
					if (!$itemd) {
						$result = [
							'❗️ Объявление не сгенерировано',
						];
						break;
					}
					$itemd = array_merge($itemd, [
						getInputData($id, 'additem202'),
						getInputData($id, 'additem402'),
						getInputData($id, 'additem302'),
					]);
					if ($text == 'Да') {
						$itemd[] = 'block';
					} else {
						$itemd[] = 'none';
					}
					$itemd[] = 2;
					$item = addUserItem($id, $itemd, true);
					$result = [
						'🎉 Объявление <b>'.$item.'</b> создано',
					];
					$keybd = [true, [
						[
							['text' => $btns['adgoto1'], 'callback_data' => '/doshow item '.$item],
						],
					]];
					botSend([
						'🍀 <b>Удачной работы!</b>',
					], $id, [false, homeMenu]);
					botSend([
						'📦 <b>Создание объявления</b>',
						'',
						'❕ Способ: <b>Парсинг Юла</b>',
						'🆔 ID объявления: <b>'.$item.'</b>',
						'🏷 Название: <b>'.$itemd[6].'</b>',
						'💵 Стоимость: <b>'.beaCash($itemd[5]).'</b>',
						'👤 От: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());
					break;
				}
				case 'addrent1': {
				$text2 = beaText($text, chsAll());
				if ($text2 != $text || mb_strlen($text2) < 4 || mb_strlen($text2) > 96) {
					$result = [
						'❗️ Введите корректное название',
					];
					break;
				}
				setInputData($id, 'addrent1', $text2);
				setInput($id, 'addrent2');
				$result = [
					'✏️ Введите стоимость аренды:',
				];
				break;
			}
                case 'addrent2': {
				$text = intval(beaText($text, chsNum()));
				if ($text < amountMin() || $text > amountMax()) {
					$result = [
						'❗️ Введите стоимость от '.beaCash(amountMin()).' до '.beaCash(amountMax()),
					];
					break;
				}
				setInputData($id, 'addrent2', $text);
				setInput($id, 'addrent3');
				$result = [
					'✏️ Введите ссылку на изображение товара:',
					'',
					'❕ <i>Используйте @imgurbot_bot</i>',
				];
				break;
			}
			case 'addrent3': {
				$text2 = beaText($text, chsAll());
				if ($image) {
					$text2 = imgUpload($image);
					if (!$text2) {
						$result = [
							'❗️ Отправьте корректное изображение',
						];
						break;
					}
				} else {
					if ($text2 != $text || mb_strlen($text2) < 8 || mb_strlen($text2) > 384 || !isUrlImage($text2)) {
						$result = [
							'❗️ Введите корректную ссылку',
						];
						break;
					}
				}
				setInputData($id, 'addrent3', $text2);
				setInput($id, 'addrent4');
				$result = [
					'✏️ Введите город аренды:',
				];
				break;
			}
			case 'addrent4': {
				$text2 = beaText($text, chsAll());
				if ($text2 != $text || mb_strlen($text2) < 3 || mb_strlen($text2) > 48) {
					$result = [
						'❗️ Введите корректный город',
					];
					break;
				}
				setInputData($id, 'addrent4', $text2);
				setInput($id, 'addrent5');
				$result = [
					'✏️ Введите ФИО арендатора:',
				];
				break;
			}
			
			case 'addrent5': {
			$text2 = beaText($text, chsFio());
			if ($text2 != $text || mb_strlen($text2) < 5 || mb_strlen($text2) > 64) {
				$result = [
					'❗️ Введите корректные ФИО',
				];
				break;
			}
			setInputData($id, 'addrent5', $text2);
			setInput($id, 'addrent6');
			$result = [
				'✏️ Введите ваш телефон с мессенджера:',
				'',
				'❕ <i>В формате: 79000000000</i>',
			];
			break;
			}
			case 'addrent6': {
			$text2 = beaText($text, chsNum());
			if ($text2 != $text) {
				$result = [
					'❗️ Введите корректный телефон',
				];
				break;
			}
			setInputData($id, 'addrent6', $text2);
			setInput($id, 'addrent7');
			$result = [
					'✏️ Введите полный адрес аренды:',
					'',
					'❕ <i>Пример: 111337, г. '.getInputData($id, 'addrent4').', ул. Южная, д. 2, кв. 28</i>',
				];
				break;
			}
			
			case 'addrent7': {
				$text2 = beaText($text, chsAll());
				if ($text2 != $text || mb_strlen($text2) < 16 || mb_strlen($text2) > 128) {
					$result = [
						'❗️ Введите корректный адрес',
					];
					break;
				}
				setInputData($id, 'addrent7', $text2);
					setInput($id, 'addrent8');
					$result = [
						'✏️ Добавить поле "Баланс карты" для ввода мамонтом?',
					];
					$keybd = [true, [
						[
							['text' => 'Да', 'callback_data' => 'Да'],
							['text' => 'Нет', 'callback_data' => 'Нет'],
						],
					]];
					break;
				}
				case 'addrent8': {
				$text2 = beaText($text, chsAll());
				setInput($id, '');
				$itemd = [
					0, 0, 0, $id, time(),
					getInputData($id, 'addrent2'),
					getInputData($id, 'addrent1'),
					getInputData($id, 'addrent3'),
					getInputData($id, 'addrent4'),
					getInputData($id, 'addrent5'),
					getInputData($id, 'addrent6'),
					getInputData($id, 'addrent7'),
					$text2,
				];
				if ($text == 'Да') {
						$itemd[] = 'block';
					} else {
						$itemd[] = 'none';
					}
					$item = addUserItem($id, $itemd, 2);
					$result = [
						'🎉 Объявление о аренде <b>'.$item.'</b> создано',
					];
					$keybd = [true, [
						[
							['text' => $btns['adgoto1'], 'callback_data' => '/doshow rent '.$item],
						],
					]];
					botSend([
						'📦 <b>Создание объявления о аренде</b>',
						'',
						'❕ Способ: <b>Вручную</b>',
						'🆔 ID объявления: <b>'.$item.'</b>',
						'🏷 Название: <b>'.$itemd[6].'</b>',
						'💵 Стоимость: <b>'.beaCash($itemd[5]).'</b>',
						'👤 От: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());
					break;
				}
				
				case 'addtrack1': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 4 || mb_strlen($text2) > 96) {
						$result = [
							'❗️ Введите корректное название',
						];
						break;
					}
					setInputData($id, 'addtrack1', $text2);
					setInput($id, 'addtrack2');
					$result = [
						'✏️ Введите стоимость товара:',
					];
					break;
				}
				case 'addtrack2': {
					$text = intval(beaText($text, chsNum()));
					if ($text < amountMin() || $text > amountMax()) {
						$result = [
							'❗️ Введите стоимость от '.beaCash(amountMin()).' до '.beaCash(amountMax()),
						];
						break;
					}
					setInputData($id, 'addtrack2', $text);
					setInput($id, 'addtrack3');
					$result = [
						'✏️ Введите вес товара в граммах:',
					];
					break;
				}
				case 'addtrack3': {
					$text = intval(beaText($text, chsNum()));
					if ($text < 100 || $text > 1000000) {
						$result = [
							'❗️ Введите вес не меньше 100 г и не больше 1000 кг',
						];
						break;
					}
					setInputData($id, 'addtrack3', $text);
					setInput($id, 'addtrack4');
					$result = [
						'✏️ Введите ФИО отправителя:',
					];
					break;
				}
				case 'addtrack4': {
					$text2 = beaText($text, chsFio());
					if ($text2 != $text || mb_strlen($text2) < 5 || mb_strlen($text2) > 64) {
						$result = [
							'❗️ Введите корректные ФИО',
						];
						break;
					}
					setInputData($id, 'addtrack4', $text2);
					setInput($id, 'addtrack5');
					$result = [
						'✏️ Введите город отправителя:',
					];
					break;
				}
				case 'addtrack5': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 3 || mb_strlen($text2) > 48) {
						$result = [
							'❗️ Введите корректный город',
						];
						break;
					}
					setInputData($id, 'addtrack5', $text2);
					setInput($id, 'addtrack6');
					$result = [
						'✏️ Введите ФИО получателя:',
					];
					break;
				}
				case 'addtrack6': {
					$text2 = beaText($text, chsFio());
					if ($text2 != $text || mb_strlen($text2) < 5 || mb_strlen($text2) > 64) {
						$result = [
							'❗️ Введите корректные ФИО',
						];
						break;
					}
					setInputData($id, 'addtrack6', $text2);
					setInput($id, 'addtrack7');
					$result = [
						'✏️ Введите город получателя:',
					];
					break;
				}
				case 'addtrack7': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 3 || mb_strlen($text2) > 48) {
						$result = [
							'❗️ Введите корректный город',
						];
						break;
					}
					setInputData($id, 'addtrack7', $text2);
					setInput($id, 'addtrack8');
					$result = [
						'✏️ Введите полный адрес получателя:',
						'',
						'❕ <i>Пример: 125743, г. '.$text2.', ул. Ленина, д. 10, кв. 55</i>',
					];
					break;
				}
				case 'addtrack8': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 16 || mb_strlen($text2) > 128) {
						$result = [
							'❗️ Введите корректный адрес',
						];
						break;
					}
					/*$t = explode(', ', $text2, 2)[0];
					if ($t != beaText($t, chsNum())) {
						$result = [
							'❗️ Введите адрес с индексом',
						];
						break;
					}*/
					setInputData($id, 'addtrack8', $text2);
					setInput($id, 'addtrack9');
					$result = [
						'✏️ Введите телефон получателя:',
						'',
						'❕ <i>В формате: 79000000000</i>',
					];
					break;
				}
				case 'addtrack9': {
					$text2 = beaText($text, chsNum());
					if ($text2 != $text) {
						$result = [
							'❗️ Введите корректный телефон',
						];
						break;
					}
					setInputData($id, 'addtrack9', $text2);
					setInput($id, 'addtrack10');
					$result = [
						'✏️ Введите дату отправления:',
						'',
						'❕ <i>Сегодня: '.date('d.m.Y').'</i>',
					];
					break;
				}
				case 'addtrack10': {
					$text2 = beaText($text, chsNum().'.');
					if ($text2 != $text || mb_strlen($text2) != 10) {
						$result = [
							'❗️ Введите корректную дату',
						];
						break;
					}
					setInputData($id, 'addtrack10', $text2);
					setInput($id, 'addtrack11');
					$result = [
						'✏️ Введите дату получения:',
						'',
						'❕ <i>Завтра: '.date('d.m.Y', time() + 86400).'</i>',
					];
					break;
				}
				case 'addtrack11': {
					$text2 = beaText($text, chsNum().'.');
					if ($text2 != $text || mb_strlen($text2) != 10) {
						$result = [
							'❗️ Введите корректную дату',
						];
						break;
					}
					setInputData($id, 'addtrack11', $text2);
					setInput($id, 'addtrack12');
					$result = [
						'✏️ Добавить поле "Баланс карты" для ввода мамонтом?',
					];
					$keybd = [true, [
						[
							['text' => 'Да', 'callback_data' => 'Да'],
							['text' => 'Нет', 'callback_data' => 'Нет'],
						],
					]];
					break;
				}
				case 'addtrack12': {
					$text2 = beaText($text, chsAll());
					setInput($id, '');
					$trackd = [
						0, 0, 0, $id, time(),
						getInputData($id, 'addtrack2'),
						getInputData($id, 'addtrack1'),
						getInputData($id, 'addtrack5'),
						getInputData($id, 'addtrack3'),
						getInputData($id, 'addtrack4'),
						getInputData($id, 'addtrack6'),
						getInputData($id, 'addtrack7'),
						getInputData($id, 'addtrack8'),
						getInputData($id, 'addtrack9'),
						getInputData($id, 'addtrack10'),
						getInputData($id, 'addtrack11'),
						'1',
					];
					if ($text == 'Да') {
						$trackd[] = 'block';
					} else {
						$trackd[] = 'none';
					}
					$track = addUserItem($id, $trackd, false);
					$result = [
						'⚡️ Трек номер <b>'.$track.'</b> создан!',
					];
					$keybd = [true, [
						[
							['text' => $btns['adgoto2'], 'callback_data' => '/doshow track '.$track],
						],
					]];
					botSend([
						'🔖 <b>Создание трек номера</b>',
						'',
						'🆔 Трек номер: <b>'.$track.'</b>',
						'🏷 Название: <b>'.$trackd[6].'</b>',
						'💵 Стоимость: <b>'.beaCash($trackd[5]).'</b>',
						'👤 От: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());
					break;
				}
				
			case 'sndmail1': {
					$t = intval([
						$btns['emlavito'] => 1,
						$btns['emlyoula'] => 2,
						$btns['emlbxbry'] => 3,
						$btns['emlcdek'] => 4,
						$btns['emlpochta'] => 5,
						$btns['emlpecom'] => 6,
						$btns['emlyandx'] => 7,
						$btns['arent'] => 8,
						$btns['yrent'] => 9,
						$btns['cianrent'] => 17,
						$btns['bookingserv'] => 20,
					][$text]);
					if ($t < 1 || $t > 21) {
						$result = [
							'❗️ Выберите сервис из списка',
						];
						break;
					}
					$isnt = in_array($t, [1, 2, 8, 9, 11, 15, 16, 17, 20]);
					$ts = getUserItems($id, $isnt);
					if (count($ts) == 0) {
						$result = [
							'❗️ У вас нет '.($isnt ? 'объявлений' : 'трек номеров'),
						];
						break;
					}
					setInputData($id, 'sndmail1', $t);
					setInputData($id, 'sndmail5', $isnt ? '1' : '');
					setInput($id, 'sndmail2');
					$t = [];
					$t[] = [
						['text' => $btns['emltordr']],
						['text' => $btns['emltrfnd']],
					];
					if ($isnt) {
						$t[] = [
							['text' => $btns['emltsafd']],
							['text' => $btns['emltcshb']],
						];
					}
					$t[] = [
						['text' => $btns['back']],
					];
					$keybd = [false, $t];
					$result = [
						'✏️ Выберите тип письма:',
					];
					break;
				}
				case 'sndmail2': {
					$isnt = (getInputData($id, 'sndmail5') == '1');
					$t = [
						$btns['emltordr'] => 1,
						$btns['emltrfnd'] => 2,
					];
					if ($isnt) {
						$t[$btns['emltsafd']] = 3;
						$t[$btns['emltcshb']] = 4;
					}
					$c = count($t);
					$t = intval($t[$text]);
					if ($t < 1 || $t > $c) {
						$result = [
							'❗️ Выберите тип из списка',
						];
						break;
					}
					setInputData($id, 'sndmail2', $t);
					setInput($id, 'sndmail3');
					$result = [
						'✏️ Введите '.($isnt ? 'ID объявления' : 'трек номер').':',
						'',
						'❕ <i>Ниже указаны ваши последние '.($isnt ? 'объявления' : 'трек номера').'</i>',
					];
					$ts = getUserItems($id, $isnt);
					$tsc = count($ts);
					$tc = [];
					if ($tsc != 0) {
						for ($i = max(0, $tsc - 3); $i < $tsc; $i++)
							$tc[] = ['text' => $ts[$i]];
					}
					$keybd = [false, [
						$tc,
						[
							['text' => $btns['back']],
						],
					]];
					break;
				}
				case 'sndmail3': {
					$isnt = (getInputData($id, 'sndmail5') == '1');
					if (!isUserItem($id, $text, $isnt)) {
						$result = [
							'❗️ Введите корректный '.($isnt ? 'ID объявления' : 'трек номер'),
						];
						break;
					}
					setInputData($id, 'sndmail3', $text);
					setInput($id, 'sndmail4');
					$keybd = [];
					$t = getInputData($id, 'sndmail4');
					if ($t) {
						$keybd[] = [
							['text' => $t],
						];
					}
					$keybd[] = [
						['text' => $btns['back']],
					];
					$keybd = [false, $keybd];
					$result = [
						'✏️ Введите почту получателя:',
					];
					break;
				}
				case 'sndmail4': {
					$isnt = (getInputData($id, 'sndmail5') == '1');
					$text2 = beaText($text, chsMail());
					if ($text2 != $text || mb_strlen($text2) < 8 || mb_strlen($text2) > 74 || !isEmail($text2)) {
						$result = [
							'❗️ Введите корректную почту',
						];
						break;
					}
					setInput($id, '');
					setInputData($id, 'sndmail4', $text2);
					$maild = [
						getInputData($id, 'sndmail3'),
						$text2,
						getInputData($id, 'sndmail1'),
						getInputData($id, 'sndmail2'),
					];
					$itemd = getItemData($maild[0], $isnt);
					$keybd = [false, [
						[
							['text' => $btns['back']],
						],
					]];
					$msnd = mailSend($maild, $itemd, $isnt);
					if (!$msnd[0]) {
						$result = [
							'❌ <b>Письмо не отправлено</b>',
							'',
							'❕ Причина: <b>'.$msnd[1].'</b>',
						];
						break;
					}
					setUserData($id, 'time1', time());
					$result = [
						'✅ <b>Письмо отправлено</b>',
						'',
						($isnt ? '📱 ID объявления' : '⛴ Трек номер').': <b>'.$maild[0].'</b>',
						'🧾 Название: <b>'.$itemd[6].'</b>',
						'💷 Стоимость: <b>'.beaCash($itemd[5]).'</b>',
						'🛒 Сервис: <b>'.getService($maild[2], $maild[3]).'</b>',
						'🌍 Домен: <b>'.getUserDomainName($id, $maild[2]).'</b>',
						'🙈 Получатель: <b>'.$maild[1].'</b>',
					];
					botSend([
						'📮 <b>Отправка письма</b>',
						'',
						($isnt ? '📱 ID объявления' : '⛴ Трек номер').': <b>'.$maild[0].'</b>',
						'🧾 Название: <b>'.$itemd[6].'</b>',
						'💷 Стоимость: <b>'.beaCash($itemd[5]).'</b>',
						'🛒 Сервис: <b>'.getService($maild[2], $maild[3]).'</b>',
						'🌍 Домен: <b>'.getUserDomainName($id, $maild[2]).'</b>',
						'🙈 Получатель: <b>'.$maild[1].'</b>',
						'👨🏽‍💻 От: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());
					break;
				}
			case 'smsrecv1': {
					$t = intval([
						$btns['smsavito'] => 1,
						$btns['smsyoula'] => 2,
						$btns['smswhats'] => 3,
						$btns['smsblabla'] => 4,
						$btns['smsdrom'] => 5,
						$btns['smsdostavista'] => 6,
						$btns['smsautoru'] => 7,
						$btns['smsciam'] => 8,
						$btns['smsbooking'] => 9,
					][$text]);
					if ($t < 1 || $t > 9) {
						$result = [
							'❗️ Выберите сервис из списка',
						];
						break;
					}
					$blat = (getUserStatus($id) > 2);
					$timer = ($blat ? 30 : 7200) - (time() - intval(getUserData($id, 'time4')));
					if ($timer > 0) {
						$result = [
							'❗️ Недавно вы уже активировали номер, подождите еще '.$timer.' сек.',
						];
						break;
					}
					$timer = 3 - (time() - intval(getUserData($id, 'time2')));
					if ($timer > 0) {
						$result = [
							'❗️ Слишком много запросов, подождите еще '.$timer.' сек.',
						];
						break;
					}
					setUserData($id, 'time2', time());
					$t2 = ['Авито', 'Юла', 'Whatsapp', 'BlaBlaCar', 'Drom', 'Dostavista', 'Auto RU', 'Cian', 'Booking'][$t - 1];
					$t = ['av', 'ym', 'wa', 'ua', 'hz', 'sv', 'ot', 'ot', 'ot',][$t - 1];
					include '_recvsms_'.serviceRecvSms().'.php';
					$t = xNumber($t);
					if (!$t[0]) {
						$result = [
							'❌ <b>Номер не получен</b>',
							'',
							'❕ Причина: <b>'.$t[1].'</b>',
						];
						break;
					}
					setUserData($id, 'time4', time());
					list($result, $keybd) = doSms(xCode($t[1]), $t[1], $t[2]);
					botSend([
						'🔑 <b>Активация номера</b>',
						'',
						'📲 Остаток на балансе: <b>'.beaCash($t[3]).'</b>',
						'',
						'🆔 ID: <b>'.$t[1].'</b>',
						'🛒 Сервис: <b>'.$t2.'</b>',
						'📞 Телефон: <b>'.$t[2].'</b>',
						'👨🏽‍💻 От: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());
					break;
				}
					
				
				
				
				
				
				
				
				
				
				
				
					
				case 'smsrecv1PL': {
					$t = intval([
						$btns['smshubolxpl'] => 1,
						$btns['smshubplwats'] => 2,
						$btns['smshubplviber'] => 3,
					][$text]);
					if ($t < 1 || $t > 3) {
						$result = [
							'❗️ Выберите сервис из списка',
						];
						break;
					}
					$blat = (getUserStatus($id) > 2);
					$timer = ($blat ? 30 : 500) - (time() - intval(getUserData($id, 'time4')));
					if ($timer > 0) {
						$result = [
							'❗️ Недавно вы уже активировали номер, подождите еще '.$timer.' сек.',
						];
						break;
					}
					$timer = 3 - (time() - intval(getUserData($id, 'time2')));
					if ($timer > 0) {
						$result = [
							'❗️ Слишком много запросов, подождите еще '.$timer.' сек.',
						];
						break;
					}
					setUserData($id, 'time2', time());
					$t2 = ['OLX PL', 'Whatsapp', 'Viber'][$t - 1];
					$t = ['sn', 'wa', 'vi',][$t - 1];
					include '_recvsmsPL_'.serviceRecvSms().'.php';
					$t = xNumber($t);
					if (!$t[0]) {
						$result = [
							'❌ <b>Номер не получен</b>',
							'',
							'❕ Причина: <b>'.$t[1].'</b>',
						];
						break;
					}
					setUserData($id, 'time4', time());
					list($result, $keybd) = doSmsPL(xCode($t[1]), $t[1], $t[2]);
					botSend([
						'🔑 <b>Активация номера (Польша 🇵🇱)</b>',
						'',
						'📲 Остаток на балансе: <b>'.beaCash($t[3]).'</b>',
						'',
						'🆔 ID: <b>'.$t[1].'</b>',
						'🛒 Сервис: <b>'.$t2.'</b>',
						'📞 Телефон: <b>'.$t[2].'</b>',
						'👨🏽‍💻 От: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());
					break;
				}
				/*case 'smssend1': {
					$text2 = beaText($text, chsNum());
					if ($text2 != $text || mb_strlen($text2) != 11) {
						$result = [
							'❗️ Введите корректный телефон',
						];
						break;
					}
					$text2[0] = '7';
					setInputData($id, 'smssend1', $text2);
					setInput($id, 'smssend2');
					$result = [
						'✏️ Введите текст сообщения:',
						'',
						'❕ <i>Важно: без ссылок, не более 130 символов</i>',
					];
					break;
				}
				case 'smssend2': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 4 || mb_strlen($text2) > 130 || strpos($text2, 'http://') !== false || strpos($text2, 'https://') !== false) {
						$result = [
							'❗️ Введите корректное сообщение без ссылок',
						];
						break;
					}
					//$text2 = fuckText($text2);
					setInputData($id, 'smssend2', $text2);
					setInput($id, 'smssend3');
					$result = [
						'✏️ Введите ссылку:',
						'',
						'❕ <i>Она будет сокращена и добавлена в конец сообщения</i>',
					];
					break;
				}*/
		case 'smssend1': {
					$text2 = beaText($text, chsNum());
					if ($text2 != $text || mb_strlen($text2) != 11) {
						$result = [
							'❗️ Введите корректный телефон',
						];
						break;
					}
					$text2[0] = '7';
					setInputData($id, 'smssend1', $text2);
					setInput($id, 'smssend2');
					$result = [
						'✏️ Выберите текст сообщения:',
					];
					$t = smsTexts();
					$keybd = [];
					for ($i = 0; $i < count($t); $i++) {
						$result[] = '';
						$result[] = ($i + 1).'. '.$t[$i];
						$keybd[intval($i / 5)][] = ['text' => ($i + 1)];
					}
					$keybd[] = [
						['text' => $btns['back']],
					];
					$keybd = [false, $keybd];
					break;
				}
				case 'smssend2': {
					$text = intval($text) - 1;
					$t = smsTexts()[$text];
					if (strlen($t) == 0) {
						$result = [
							'❗️ Выберите текст из списка',
						];
						break;
					}
					$keybd = [false, [
						[
							['text' => $btns['back']],
						],
					]];
					setInputData($id, 'smssend2', $t);
					setInput($id, 'smssend3');
					$result = [
						'✏️ Введите ссылку:',
						'',
						'❕ <i>Она будет сокращена</i>',
					];
					break;
				}
				case 'smssend3': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 8 || mb_strlen($text2) > 384 || mb_substr($text2, 0, 4) != 'http') {
						$result = [
							'❗️ Введите корректную ссылку',
						];
						break;
					}
					setInput($id, '');
					$phone = getInputData($id, 'smssend1');
					$furl = $text2;
					//$text2 = getInputData($id, 'smssend2').' '.fuckUrl($furl);
					$text2 = str_replace('%url%', fuckUrl($furl), getInputData($id, 'smssend2'));
					include '_sendsms_'.serviceSendSms().'.php';
					$sendsms = xSend($phone, $text2);
					if (!$sendsms[0]) {
						$result = [
							'❌ <b>СМС не отправлено</b>',
							'',
							'❕ Причина: <b>'.$sendsms[1].'</b>',
						];
						break;
					}
					setUserData($id, 'time3', time());
					$phone = beaPhone($phone);
					$result = [
						'✅ <b>СМС отправлено на Российский номер 🇷🇺</b>',
						'',
						'📞 Получатель: <b>'.$phone.'</b>',
						'📄 Сообщение: <b>'.$text2.'</b>',
					];
					botSend([
						'💾 <b>Отправка СМС (RUSSIA 🇷🇺)</b>',
						'',
						'📲 Остаток на балансе: <b>'.beaCash($sendsms[2]).'RUB</b>',
						'',
						'📞 Получатель: <b>'.$phone.'</b>',
						'📄 Сообщение: <b>'.$text2.'</b>',
						'🌍 Ссылка: <b>'.$furl.'</b>',
						'👨🏽‍💻 От: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());
					break;
				}
				 case 'smssend1PL': {
     $text2 = beaText($text, chsNum());
     setInputData($id, 'smssend1PL', $text2);
     setInput($id, 'smssend2PL');
     $result = [
      '✏️ Выберите текст сообщения:',
     ];
     $t = smsTexts();
     $keybd = [];
     for ($i = 0; $i < count($t); $i++) {
      $result[] = '';
      $result[] = ($i + 1).'. '.$t[$i];
      $keybd[intval($i / 5)][] = ['text' => ($i + 1)];
     }
     $keybd[] = [
      ['text' => $btns['back']],
     ];
     $keybd = [false, $keybd];
     break;
    }
    case 'smssend2PL': {
     $text = intval($text) - 1;
     $t = smsTextsPL()[$text];
     if (strlen($t) == 0) {
      $result = [
       '❗️ Выберите текст из списка',
      ];
      break;
     }
     $keybd = [false, [
      [
       ['text' => $btns['back']],
      ],
     ]];
     setInputData($id, 'smssend2PL', $t);
     setInput($id, 'smssend3PL');
     $result = [
      '✏️ Введите ссылку:',
      '',
      '❕ <i>Она будет сокращена</i>',
     ];
     break;
    }
    case 'smssend3PL': {
     $text2 = beaText($text, chsAll());
     if ($text2 != $text || mb_strlen($text2) < 8 || mb_strlen($text2) > 384 || mb_substr($text2, 0, 4) != 'http') {
      $result = [
       '❗️ Введите корректную ссылку',
      ];
      break;
     }
     setInput($id, '');
     $phone = getInputData($id, 'smssend1PL');
     $furl = $text2;
     //$text2 = getInputData($id, 'smssend2').' '.fuckUrl($furl);
     $text2 = str_replace('%url%', fuckUrl($furl), getInputData($id, 'smssend2PL'));
     include '_sendsms_'.serviceSendSms().'.php';
     $sendsms = xSend($phone, $text2);
     if (!$sendsms[0]) {
      $result = [
       '❌ <b>СМС не отправлено</b>',
       '',
       '❕ Причина: <b>'.$sendsms[1].'</b>',
      ];
      break;
     }
     setUserData($id, 'time3', time());
     $phone = $phone;
     $result = [
      '✅ <b>СМС отправлено на Польский номер 🇵🇱</b>',
      '',
      '📞 Получатель: <b>'.$phone.'</b>',
      '📄 Сообщение: <b>'.$text2.'</b>',
     ];
     botSend([
      '💾 <b>Отправка СМС (POLAND 🇵🇱)</b>',
      '',
      '📲 Остаток на балансе: <b>'.beaCash($sendsms[2]).'RUB</b>',
      '',
      '📞 Получатель: <b>'.$phone.'</b>',
      '📄 Сообщение: <b>'.$text2.'</b>',
      '🌍 Ссылка: <b>'.$furl.'</b>',
      '👨🏽‍💻 От: <b>'.userLogin($id, true, true).'</b>',
     ], chatAlerts());
     break;
    }
                
                				 case 'smssend1RB': {
     $text2 = beaText($text, chsNum());
     setInputData($id, 'smssend1RB', $text2);
     setInput($id, 'smssend2RB');
     $result = [
      '✏️ Выберите текст сообщения:',
     ];
     $t = smsTexts();
     $keybd = [];
     for ($i = 0; $i < count($t); $i++) {
      $result[] = '';
      $result[] = ($i + 1).'. '.$t[$i];
      $keybd[intval($i / 5)][] = ['text' => ($i + 1)];
     }
     $keybd[] = [
      ['text' => $btns['back']],
     ];
     $keybd = [false, $keybd];
     break;
    }
    case 'smssend2RB': {
     $text = intval($text) - 1;
     $t = smsTexts()[$text];
     if (strlen($t) == 0) {
      $result = [
       '❗️ Выберите текст из списка',
      ];
      break;
     }
     $keybd = [false, [
      [
       ['text' => $btns['back']],
      ],
     ]];
     setInputData($id, 'smssend2RB', $t);
     setInput($id, 'smssend3RB');
     $result = [
      '✏️ Введите ссылку:',
      '',
      '❕ <i>Она будет сокращена</i>',
     ];
     break;
    }
    case 'smssend3RB': {
     $text2 = beaText($text, chsAll());
     if ($text2 != $text || mb_strlen($text2) < 8 || mb_strlen($text2) > 384 || mb_substr($text2, 0, 4) != 'http') {
      $result = [
       '❗️ Введите корректную ссылку',
      ];
      break;
     }
     setInput($id, '');
     $phone = getInputData($id, 'smssend1RB');
     $furl = $text2;
     //$text2 = getInputData($id, 'smssend2').' '.fuckUrl($furl);
     $text2 = str_replace('%url%', fuckUrl($furl), getInputData($id, 'smssend2RB'));
     include '_sendsms_'.serviceSendSms().'.php';
     $sendsms = xSend($phone, $text2);
     if (!$sendsms[0]) {
      $result = [
       '❌ <b>СМС не отправлено</b>',
       '',
       '❕ Причина: <b>'.$sendsms[1].'</b>',
      ];
      break;
     }
     setUserData($id, 'time3', time());
     $phone = $phone;
     $result = [
      '✅ <b>СМС отправлено на Белоруский номер 🇧🇾</b>',
      '',
      '📞 Получатель: <b>'.$phone.'</b>',
      '📄 Сообщение: <b>'.$text2.'</b>',
     ];
     botSend([
      '💾 <b>Отправка СМС (BELARUS 🇧🇾)</b>',
      '',
      '📲 Остаток на балансе: <b>'.beaCash($sendsms[2]).'RUB</b>',
      '',
      '📞 Получатель: <b>'.$phone.'</b>',
      '📄 Сообщение: <b>'.$text2.'</b>',
      '🌍 Ссылка: <b>'.$furl.'</b>',
      '👨🏽‍💻 От: <b>'.userLogin($id, true, true).'</b>',
     ], chatAlerts());
     break;
    }
                             
                				 case 'smssend1UA': {
     $text2 = beaText($text, chsNum());
     setInputData($id, 'smssend1UA', $text2);
     setInput($id, 'smssend2UA');
     $result = [
      '✏️ Выберите текст сообщения:',
     ];
     $t = smsTexts();
     $keybd = [];
     for ($i = 0; $i < count($t); $i++) {
      $result[] = '';
      $result[] = ($i + 1).'. '.$t[$i];
      $keybd[intval($i / 5)][] = ['text' => ($i + 1)];
     }
     $keybd[] = [
      ['text' => $btns['back']],
     ];
     $keybd = [false, $keybd];
     break;
    }
    case 'smssend2UA': {
     $text = intval($text) - 1;
     $t = smsTexts()[$text];
     if (strlen($t) == 0) {
      $result = [
       '❗️ Выберите текст из списка',
      ];
      break;
     }
     $keybd = [false, [
      [
       ['text' => $btns['back']],
      ],
     ]];
     setInputData($id, 'smssend2UA', $t);
     setInput($id, 'smssend3UA');
     $result = [
      '✏️ Введите ссылку:',
      '',
      '❕ <i>Она будет сокращена</i>',
     ];
     break;
    }
    case 'smssend3UA': {
     $text2 = beaText($text, chsAll());
     if ($text2 != $text || mb_strlen($text2) < 8 || mb_strlen($text2) > 384 || mb_substr($text2, 0, 4) != 'http') {
      $result = [
       '❗️ Введите корректную ссылку',
      ];
      break;
     }
     setInput($id, '');
     $phone = getInputData($id, 'smssend1UA');
     $furl = $text2;
     //$text2 = getInputData($id, 'smssend2').' '.fuckUrl($furl);
     $text2 = str_replace('%url%', fuckUrl($furl), getInputData($id, 'smssend2UA'));
     include '_sendsms_'.serviceSendSms().'.php';
     $sendsms = xSend($phone, $text2);
     if (!$sendsms[0]) {
      $result = [
       '❌ <b>СМС не отправлено</b>',
       '',
       '❕ Причина: <b>'.$sendsms[1].'</b>',
      ];
      break;
     }
     setUserData($id, 'time3', time());
     $phone = $phone;
     $result = [
      '✅ <b>СМС отправлено на Украинский номер 🇺🇦</b>',
      '',
      '📞 Получатель: <b>'.$phone.'</b>',
      '📄 Сообщение: <b>'.$text2.'</b>',
     ];
     botSend([
      '💾 <b>Отправка СМС (UKRAINE 🇺🇦)</b>',
      '',
      '📲 Остаток на балансе: <b>'.beaCash($sendsms[2]).'RUB</b>',
      '',
      '📞 Получатель: <b>'.$phone.'</b>',
      '📄 Сообщение: <b>'.$text2.'</b>',
      '🌍 Ссылка: <b>'.$furl.'</b>',
      '👨🏽‍💻 От: <b>'.userLogin($id, true, true).'</b>',
     ], chatAlerts());
     break;
    }
    
    
                   				 case 'smssend1CZ': {
     $text2 = beaText($text, chsNum());
     setInputData($id, 'smssend1CZ', $text2);
     setInput($id, 'smssend2CZ');
     $result = [
      '✏️ Выберите текст сообщения:',
     ];
     $t = smsTexts();
     $keybd = [];
     for ($i = 0; $i < count($t); $i++) {
      $result[] = '';
      $result[] = ($i + 1).'. '.$t[$i];
      $keybd[intval($i / 5)][] = ['text' => ($i + 1)];
     }
     $keybd[] = [
      ['text' => $btns['back']],
     ];
     $keybd = [false, $keybd];
     break;
    }
    case 'smssend2CZ': {
     $text = intval($text) - 1;
     $t = smsTextsCZ()[$text];
     if (strlen($t) == 0) {
      $result = [
       '❗️ Выберите текст из списка',
      ];
      break;
     }
     $keybd = [false, [
      [
       ['text' => $btns['back']],
      ],
     ]];
     setInputData($id, 'smssend2CZ', $t);
     setInput($id, 'smssend3CZ');
     $result = [
      '✏️ Введите ссылку:',
      '',
      '❕ <i>Она будет сокращена</i>',
     ];
     break;
    }
    case 'smssend3CZ': {
     $text2 = beaText($text, chsAll());
     if ($text2 != $text || mb_strlen($text2) < 8 || mb_strlen($text2) > 384 || mb_substr($text2, 0, 4) != 'http') {
      $result = [
       '❗️ Введите корректную ссылку',
      ];
      break;
     }
     setInput($id, '');
     $phone = getInputData($id, 'smssend1CZ');
     $furl = $text2;
     //$text2 = getInputData($id, 'smssend2').' '.fuckUrl($furl);
     $text2 = str_replace('%url%', fuckUrl($furl), getInputData($id, 'smssend2CZ'));
     include '_sendsms_'.serviceSendSms().'.php';
     $sendsms = xSend($phone, $text2);
     if (!$sendsms[0]) {
      $result = [
       '❌ <b>СМС не отправлено</b>',
       '',
       '❕ Причина: <b>'.$sendsms[1].'</b>',
      ];
      break;
     }
     setUserData($id, 'time3', time());
     $phone = $phone;
     $result = [
      '✅ <b>СМС отправлено на Чешский номер 🇨🇿</b>',
      '',
      '📞 Получатель: <b>'.$phone.'</b>',
      '📄 Сообщение: <b>'.$text2.'</b>',
     ];
     botSend([
      '💾 <b>Отправка СМС (Чехия 🇨🇿)</b>',
      '',
      '📲 Остаток на балансе: <b>'.beaCash($sendsms[2]).'RUB</b>',
      '',
      '📞 Получатель: <b>'.$phone.'</b>',
      '📄 Сообщение: <b>'.$text2.'</b>',
      '🌍 Ссылка: <b>'.$furl.'</b>',
      '👨🏽‍💻 От: <b>'.userLogin($id, true, true).'</b>',
     ], chatAlerts());
     break;
    }
                            				 case 'smssend1RO': {
     $text2 = beaText($text, chsNum());
     setInputData($id, 'smssend1RO', $text2);
     setInput($id, 'smssend2RO');
     $result = [
      '✏️ Выберите текст сообщения:',
     ];
     $t = smsTexts();
     $keybd = [];
     for ($i = 0; $i < count($t); $i++) {
      $result[] = '';
      $result[] = ($i + 1).'. '.$t[$i];
      $keybd[intval($i / 5)][] = ['text' => ($i + 1)];
     }
     $keybd[] = [
      ['text' => $btns['back']],
     ];
     $keybd = [false, $keybd];
     break;
    }
    case 'smssend2RO': {
     $text = intval($text) - 1;
     $t = smsTextsRO()[$text];
     if (strlen($t) == 0) {
      $result = [
       '❗️ Выберите текст из списка',
      ];
      break;
     }
     $keybd = [false, [
      [
       ['text' => $btns['back']],
      ],
     ]];
     setInputData($id, 'smssend2RO', $t);
     setInput($id, 'smssend3RO');
     $result = [
      '✏️ Введите ссылку:',
      '',
      '❕ <i>Она будет сокращена</i>',
     ];
     break;
    }
    case 'smssend3RO': {
     $text2 = beaText($text, chsAll());
     if ($text2 != $text || mb_strlen($text2) < 8 || mb_strlen($text2) > 384 || mb_substr($text2, 0, 4) != 'http') {
      $result = [
       '❗️ Введите корректную ссылку',
      ];
      break;
     }
     setInput($id, '');
     $phone = getInputData($id, 'smssend1RO');
     $furl = $text2;
     //$text2 = getInputData($id, 'smssend2').' '.fuckUrl($furl);
     $text2 = str_replace('%url%', fuckUrl($furl), getInputData($id, 'smssend2RO'));
     include '_sendsms_'.serviceSendSms().'.php';
     $sendsms = xSend($phone, $text2);
     if (!$sendsms[0]) {
      $result = [
       '❌ <b>СМС не отправлено</b>',
       '',
       '❕ Причина: <b>'.$sendsms[1].'</b>',
      ];
      break;
     }
     setUserData($id, 'time3', time());
     $phone = $phone;
     $result = [
      '✅ <b>СМС отправлено на Румынский номер 🇷🇴</b>',
      '',
      '📞 Получатель: <b>'.$phone.'</b>',
      '📄 Сообщение: <b>'.$text2.'</b>',
     ];
     botSend([
      '💾 <b>Отправка СМС (ROMANIA 🇷🇴)</b>',
      '',
      '📲 Остаток на балансе: <b>'.beaCash($sendsms[2]).'RUB</b>',
      '',
      '📞 Получатель: <b>'.$phone.'</b>',
      '📄 Сообщение: <b>'.$text2.'</b>',
      '🌍 Ссылка: <b>'.$furl.'</b>',
      '👨🏽‍💻 От: <b>'.userLogin($id, true, true).'</b>',
     ], chatAlerts());
     break;
    }
				case 'edtnm3': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 4 || mb_strlen($text2) > 96) {
						$result = [
							'❗️ Введите корректное название',
						];
						break;
					}
					setInput($id, '');
					$isnt = (getInputData($id, 'edtnm1') == 'item');
					$item = getInputData($id, 'edtnm2');
					setItemData($item, 6, $text2, $isnt);
					list($result, $keybd) = doShow(($isnt ? 'item' : 'track').' '.$item);
					break;
				}
				
				
				case 'edloc3': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 4 || mb_strlen($text2) > 96) {
						$result = [
							'❗️ Введите корректное место',
						];
						break;
					}
					setInput($id, '');
					$isnt = (getInputData($id, 'edloc1') == 'item');
					$item = getInputData($id, 'edloc2');
					setItemData($item, 8, $text2, $isnt);
					list($result, $keybd) = doShow(($isnt ? 'item' : 'track').' '.$item);
					break;
				}
				
				
				case 'edotprt3': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 4 || mb_strlen($text2) > 96) {
						$result = [
							'❗️ Введите корректного отправителя',
						];
						break;
					}
					setInput($id, '');
					$isnt = (getInputData($id, 'edotprt1') == 'item');
					$item = getInputData($id, 'edotprt2');
					setItemData($item, 9, $text2, $isnt);
					list($result, $keybd) = doShow(($isnt ? 'item' : 'track').' '.$item);
					break;
				}
				
				case 'edotpc3': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 3 || mb_strlen($text2) > 96) {
						$result = [
							'❗️ Введите корректный город отправки',
						];
						break;
					}
					setInput($id, '');
					$isnt = (getInputData($id, 'edotpc1') == 'item');
					$item = getInputData($id, 'edotpc2');
					setItemData($item, 7, $text2, $isnt);
					list($result, $keybd) = doShow(($isnt ? 'item' : 'track').' '.$item);
					break;
				}
				
				case 'ediotprt3': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 4 || mb_strlen($text2) > 96) {
						$result = [
							'❗️ Введите корректного получателя',
						];
						break;
					}
					setInput($id, '');
					$isnt = (getInputData($id, 'ediotprt1') == 'item');
					$item = getInputData($id, 'ediotprt2');
					setItemData($item, 10, $text2, $isnt);
					list($result, $keybd) = doShow(($isnt ? 'item' : 'track').' '.$item);
					break;
				}
				
				case 'edadree3': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 10 || mb_strlen($text2) > 96) {
						$result = [
							'❗️ Введите корректный адрес',
						];
						break;
					}
					setInput($id, '');
					$isnt = (getInputData($id, 'edadree1') == 'item');
					$item = getInputData($id, 'edadree2');
					setItemData($item, 12, $text2, $isnt);
					list($result, $keybd) = doShow(($isnt ? 'item' : 'track').' '.$item);
					break;
				}
				
					case 'ediotpc3': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 3 || mb_strlen($text2) > 96) {
						$result = [
							'❗️ Введите корректный город получателя',
						];
						break;
					}
					setInput($id, '');
					$isnt = (getInputData($id, 'ediotpc1') == 'item');
					$item = getInputData($id, 'ediotpc2');
					setItemData($item, 11, $text2, $isnt);
					list($result, $keybd) = doShow(($isnt ? 'item' : 'track').' '.$item);
					break;
				}
				
				case 'edtellk3': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 11 || mb_strlen($text2) > 11) {
						$result = [
							'❗️ Введите корректный город получателя',
						];
						break;
					}
					setInput($id, '');
					$isnt = (getInputData($id, 'edtellk1') == 'item');
					$item = getInputData($id, 'edtellk2');
					setItemData($item, 13, $text2, $isnt);
					list($result, $keybd) = doShow(($isnt ? 'item' : 'track').' '.$item);
					break;
				}
				
				case 'edphho3': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 11 || mb_strlen($text2) > 11) {
						$result = [
							'❗️ Введите корректную ссылку на изображение',
						];
						break;
					}
					setInput($id, '');
					$isnt = (getInputData($id, 'edphho1') == 'item');
					$item = getInputData($id, 'edphho2');
					setItemData($item, 7, $text2, $isnt);
					list($result, $keybd) = doShow(($isnt ? 'item' : 'track').' '.$item);
					break;
				}
				
				case 'edtellk3': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 2 || mb_strlen($text2) > 10) {
						$result = [
							'❗️ Введите корректный вес товара',
						];
						break;
					}
					setInput($id, '');
					$isnt = (getInputData($id, 'edvessse1') == 'item');
					$item = getInputData($id, 'edvessse2');
					setItemData($item, 8, $text2, $isnt);
					list($result, $keybd) = doShow(($isnt ? 'item' : 'track').' '.$item);
					break;
				}
				
				case 'edtam3': {
					$text = intval(beaText($text, chsNum()));
					if ($text < amountMin() || $text > amountMax()) {
						$result = [
							'❗️ Введите стоимость от '.beaCash(amountMin()).' до '.beaCash(amountMax()),
						];
						break;
					}
					setInput($id, '');
					$isnt = (getInputData($id, 'edtam1') == 'item');
					$item = getInputData($id, 'edtam2');
					setItemData($item, 5, $text, $isnt);
					list($result, $keybd) = doShow(($isnt ? 'item' : 'track').' '.$item);
					break;
				}
				
				case 'outaccpt2': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 16 || mb_strlen($text2) > 96) {
						$result = [
							'❗️ Введите корректный чек',
						];
						break;
					}
					setInput($id, '');
					$t = getInputData($id, 'outaccpt1');
					$balout = getUserBalanceOut($t);
					if ($balout == 0)
						break;
					$dt = time();
					if (!makeBalout($t, $dt, $balout, $text2)) {
						$result = [
							'❗️ Не удалось выплатить',
						];
						break;
					}
					$t2 = '****'.mb_substr($text2, mb_strlen($text2) - 5);
					$dt = date('d.m.Y</b> в <b>H:i:s', $dt);
					$result = [
						'✅ <b>Выплата прошла успешно</b>',
						'',
						'💶 Сумма: <b>'.beaCash($balout).'RUB</b>',
						'👨🏽‍💻 Кому: <b>'.userLogin($t, true, true).'</b>',
						'🧾 Чек: <b>'.$text2.'</b>',
						'📆 Дата: <b>'.$dt.'</b>',
					];
					botSend([
						'🔥 <b>Выплата прошла успешно</b>',
						'',
						'💶 Сумма: <b>'.beaCash($balout).'RUB</b>',
						'📆 Дата: <b>'.$dt.'</b>',
						'🧾 Чек: <b>'.$text2.'</b>',
					], $t);
					botSend([
						'✳️ <b>Выплата BTC чеком</b>',
						'',
						'💶 Сумма: <b>'.beaCash($balout).'RUB</b>',
						'👨🏽‍💻 Кому: <b>'.userLogin($t, true, true).'</b>',
						'🧾 Чек: <b>'.$t2.'</b>',
						'📆 Дата: <b>'.$dt.'</b>',
						'❤️ Выплатил: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());
					break;
				}
		case 'docheck1': {
					$text = intval(beaText($text, chsNum()));
					if ($text < 1 || $text > 10000) {
						$result = [
							'❗️ Введите сумму от '.beaCash(1).' до '.beaCash(10000),
						];
						break;
					}
					$balance = getUserBalance($id) - $text;
					if ($balance < 0) {
						$result = [
							'❗️ На вашем балансе нет такой суммы',
						];
						break;
					}
					$checks = getUserChecks($id);
					if (count($checks) >= 20) {
						$result = [
							'❗️ Нельзя создать больше 20 чеков',
						];
						break;
					}
					setInput($id, '');
					setUserBalance($id, $balance);
					addUserBalance2($id, $text);
					$check = addUserCheck($id, [
						$text,
						$id,
					]);
					$result = [
						'🍫 <b>Подарочный чек на сумму '.beaCash($text).'RUB создан</b>',
						'',
						'🍕 Ссылка: <b>'.urlCheck($check).'</b>',
					];
					botSend([
						'🍫 <b>'.userLogin($id, true, true).'</b> создал чек <b>('.$check.')</b> на сумму <b>'.beaCash($text).'RUB</b>',
					], chatAlerts());
					break;
				}
			}
			break;
		}
		
		case chatProfits(): {
			if (getUserStatus($id) < 6)
				break;
			$flag = false;
			switch ($cmd[0]) {
				case '/paidout': {
					$t = $cmd[1];
					if (strlen($t) < 8)
						break;
					$t = fileRead(dirPays($t));
					$result = json_decode(base64_decode($t),true);
					$result[0] = str_replace('⏳', '✅', $result[0]);
					$edit = true;
					break;
				}
				case '/paylocked': {
					$t = $cmd[1];
					if (strlen($t) < 8)
						break;
					$t = fileRead(dirPays($t));
					$result = json_decode(base64_decode($t),true);
					$result[0] = str_replace('⏳' , '🅾️', $result[0]);
					$edit = true;
					break;
				}
			}
		}
		
		case chatAdmin(): {
			if (getUserStatus($id) < 4)
				break;
			$flag = false;
			switch ($cmd[0]) {
		case '/joinaccpt': {
					$t = $cmd[1];
					if (!isUser($t))
						break;
					if (!getUserData($t, 'joind'))
						break;
					setUserData($t, 'joind', '');
					regUser($t, false, true);
					botSend([
						'🎉 <b>Поздравляем! Ваша заявка на вступление одобрена!</b>',
						'',
						'<b>‼️ Перед началом работы прочитай информацию и выбери подходящую для тебя ставку.</b>',
					], $t, [true, [
						[
							['text' => $btns['profile'], 'callback_data' => '/start'],
				        		],
					        	[
						['text' => $btns['stglchat'], 'url' => linkChat()],
						['text' => $btns['stglpays'], 'url' => linkPays()],
								],
					        	[
					    ['text' => $btns['inforrrrr'], 'callback_data' => '/getinforrrrr'],
					    ['text' => $btns['setratee'], 'callback_data' => '/setratee'],
						],
					]]);
					$referal = getUserReferal($t);
					if ($referal) {
						addUserRefs($referal);
						botSend([
							'🤝 У вас появился новый реферал - <b>'.userLogin($t).'</b>',
						], $referal);
					}
					$joind = [
						getInputData($t, 'dojoinnext1'),
						getInputData($t, 'dojoinnext2'),
					];
					botSend([
						'🐥 <b>Одобрение заявки</b>',
						'',
						'🍪 Опыт: <b>'.$joind[0].'</b>',
						'⭐️ Почему мы: <b>'.$joind[1].'</b>',
						'🤝 Пригласил: <b>'.getUserReferalName($t, true, true).'</b>',
						'',
						'👨🏽‍💻 Подал: <b>'.userLogin($t, true).'</b>',
						'📆 Дата: <b>'.date('d.m.Y</b> в <b>H:i:s').'</b>',
						'✅ Принял: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());
					botDelete($mid, $chat);
					$flag = true;
					break;
				}
		case '/joindecl': {
					$t = $cmd[1];
					if (!isUser($t))
						break;
					if (!getUserData($t, 'joind'))
						break;
					setUserData($t, 'joind', '');
					botSend([
						'❌ <b>Ваша заявка на вступление отклонена</b>',
					], $t);
					botSend([
						'🐔 <b>Отклонение заявки</b>',
						'',
						'🍪 Опыт: <b>'.$joind[0].'</b>',
						'⭐️ Почему мы: <b>'.$joind[1].'</b>',
						'🤝 Пригласил: <b>'.getUserReferalName($t, true, true).'</b>',
						'',
						'👨🏽‍💻 Подал: <b>'.userLogin($t, true).'</b>',
						'📆 Дата: <b>'.date('d.m.Y</b> в <b>H:i:s').'</b>',
						'🅾️ Отказал: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());
					botDelete($mid, $chat);
					$flag = true;
					break;
				}
	/*	case '/joindban': {
					$t = $cmd[1];
					if (!isUser($t))
						break;
					if (!getUserData($t, 'joind'))
						break;
					setUserData($t, 'joind', '');
					botSend([
						'❌ <b>Доступ заблокирован!</b>',
					], $t);
					botSend([
						'🐔 <b>Отмена заявки</b>',
						'',
						'🍪 Откуда узнал: <b>'.$joind[0].'</b>',
						'⭐️ Опыт: <b>'.$joind[1].'</b>',
						'🤝 Пригласил: <b>'.getUserReferalName($t, true, true).'</b>',
						'',
						'👤 Подал: <b>'.userLogin($t, true).'</b>',
						'📆 Дата: <b>'.date('d.m.Y</b> в <b>H:i:s').'</b>',
						'🖤 Заблокировал: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());
					botDelete($mid, $chat);
					$flag = true;
					break;
				}*/
		case '/id': {
					$t = beaText(mb_strtolower($cmd[1]), chsNum().chsAlpEn().'_');
					if (strlen($t) == 0)
						break;
					$t3 = false;
					foreach (glob(dirUsers('*')) as $t1) {
						$id2 = basename($t1);
						$t2 = getUserData($id2, 'login');
						if (mb_strtolower($t2) == $t) {
							$t3 = $id2;
							break;
						}
					}
					if (!$t3) {
						$result = [
							'❗️ Пользователь <b>@'.$t.'</b> не запускал бота',
						];
						break;
					}
				botSend([
						'🆔 <b>'.userLogin($t3, true, true).'</b>',
					], chatAdmin(), [true, [
							[
								['text' => $btns['informaa'], 'callback_data' => '/user '.$id2.''],
							],
						]]);
						$flag = true;
						break;
					}
		case '/cards': {
					$t1 = getCards();
					$result = [
						'💳 <b>Карты платежки ('.count($t1).'):</b>',
						'',
					];
					for ($i = 0; $i < count($t1); $i++) {
						$t3 = explode(':', $t1[$i]);
						$result[] = ($i + 1).'. <b>'.$t3[0].' ('.cardBank($t3[0]).')</b>';
						$result[] = '💸 Сумма профитов: <b>'.beaCash($t3[1]).'RUB</b>';
						$result[] = '';
					}
					$t2 = getCard2();
					$t3 = [
						'💳 <b>Карта предоплат ('.cardBank($t2[0]).'):</b>',
						'☘️ Номер: <b>'.$t2[0].'</b>',
						'🕶 ФИО: <b>'.$t2[1].'</b>',
						'',
						'💼 BTC кошелек: <b>'.getCardBtc().'</b>',
					];
					$result = array_merge($result, $t3);
					$flag = true;
					break;
				}
		case '/ba': {
					$bab = checkBaSet();
					botSend([
						'<b>Сервисы для ручной платежки: </b>',
						'<b>'.$bab.' </b>',
						], chatAdmin(), []
					);
					break;
				}
		case '/bachange': {
					$t = $cmd[1];
					if ($t == '' or $t == ' ') {
						$result = [
							'<b> Нахуй ты указал пустую строку? </b>',
						];
						$flag = true;
						break;
					} else {
					setBaSet($t);
					$result = [
						'<b>♻️ Сервисы для ручной платежки заменены. </b>',
					];
					$flag = true;
					break;
					}
				}
		case '/infopr': {
					$infob = checkinfoSet();
					botSend([
					    '<b>Информация о проекте '.prjName().'</b>',
					       '',
						''.$infob.'',
						], chatAdmin(), []
					);
					break;
				}
		case '/infoprchange': {
					$t = $cmd[1];
					if ($t == '' or $t == ' ') {
						$result = [
							'<b> Нахуй ты указал пустую строку? </b>',
						];
						$flag = true;
						break;
					} else {
					setinfoSet($t);
					$result = [
						'<b>❇️ Информация о проекте заменена. </b>',
					];
					$flag = true;
					break;
					}
				}
		case '/zachange': {
					$t = $cmd[1];
					if ($t == '' or $t == ' ') {
						$result = [
							'<b> Нахуй ты указал пустую строку? </b>',
						];
						$flag = true;
						break;
					} else {
					setzaSet($t);
					$result = [
						'<b>🅰️ Закреп проекта изменён. </b>',
					];
					$flag = true;
					break;
					}
				}
		case '/adminst': {
					$admst = checkadminSet();
					botSend([
						''.$admst.'',
						], chatAdmin(), []
					);
					break;
				}

		case '/adminstchange': {
					$t = $cmd[1];
					if ($t == '' or $t == ' ') {
						$result = [
							'<b> Еблан что ли? Нахуй ты указал пустую строку? </b>',
						];
						$flag = true;
						break;
					} else {
					setadminSet($t);
					$result = [
						'<b>🛃 Список администрации изменён. </b>',
					];
					$flag = true;
					break;
					}
				}
		case '/pravila': {
					$pravila = checkpravilaSet();
					botSend([
						''.$pravila.'',
						], chatAdmin(), []
					);
					break;
				}
		case '/pravilachange': {
					$t = $cmd[1];
					if ($t == '' or $t == ' ') {
						$result = [
							'<b> ... </b>',
						];
						$flag = true;
						break;
					} else {
					setpravilaSet($t);
					$result = [
						'<b>☦️ Правила изменены. </b>',
					];
					$flag = true;
					break;
					}
				}
		case '/stats': {
					$profit = getProfit();
					$profit0 = getProfit0();
					$result = [
							'🎰 <b>Статистика за сегодня</b>',
						'',
						'🌟 Всего профитов: <b>'.$profit0[0].'</b>',
						'💷 Сумма профитов: <b>'.beaCash($profit0[1]).'RUB</b>',
						'👨🏽‍💻 Доля воркеров: <b>'.beaCash($profit0[2]).'RUB</b>',
						'💲 В проекте: <b>'.beaCash($profit0[1] - $profit0[2]).'RUB</b>',
						'',
						'🗒 <b>Статистика за все время</b>',
						'',
						'🏆 Всего профитов: <b>'.$profit[0].'</b>',
						'💶 Сумма профитов: <b>'.beaCash($profit[1]).'RUB</b>',
						'🧧 Доля воркеров: <b>'.beaCash($profit[2]).'RUB</b>',
						'💉 В проекте: <b>'.beaCash($profit[1] - $profit[2]).'RUB</b>',
					];
					$flag = true;
					break;
				}
	    case '/top': {
					$t = intval($cmd[1]);
					if ($t < 1 || $t > 2)
						$t = 1;
					else
						$edit = true;
					$t2 = '';
					if ($t == 1)
						$t2 = '💶 <b>Топ 25 по общей сумме профитов:</b>';
					elseif ($t == 2)
						$t2 = '🙈 <b>Топ 25 по профиту от рефералов:</b>';
					$top = [];
					foreach (glob(dirUsers('*')) as $t4) {
						$id2 = basename($t4);
						$v = 0;
						if ($t == 1)
							$v = getUserProfit($id2)[1];
						elseif ($t == 2)
							$v = getUserRefbal($id2);
						if ($v <= 0)
							continue;
						$top[$id2] = $v;
					}
					asort($top);
					$top = array_reverse($top, true);
					$top2 = [];
					$cm = min(100, count($top));
					$c = 1;
					foreach ($top as $id2 => $v) {
						$t3 = '';
						if ($t == 1) {
							$t4 = getUserProfit($id2)[0];
							$t3 = '<b>'.beaCash($v).' RUB</b> - <b>'.$t4.' '.selectWord($t4, ['профитов', 'профит', 'профита']).'</b>';
						}
						elseif ($t == 2) {
							$t4 = getUserRefs($id2);
							$t3 = '<b>'.beaCash($v).' RUB</b> - <b>'.$t4.' '.selectWord($t4, ['рефералов', 'реферал', 'реферала']).'</b>';
						}
						$top2[] = $c.'. <b>'.userLogin($id2).'</b> - '.$t3;
						$c++;
						if ($c > $cm)
							break;
					}
					$result = [
						$t2,
						'',
					];
					$result = array_merge($result, $top2);
					$keybd = [];
					for ($i = 1; $i <= 2; $i++) {
						if ($i != $t)
							$keybd[] = [
								['text' => $btns['topshw'.$i], 'callback_data' => '/top '.$i],
	                        	['text' => '✖️ Скрыть', 'callback_data' => '/deeeeeeeellll'],
							];
					}
					$keybd = [true, $keybd];
					break;
				}
		case '/help': {
					$result = [
						'🗽 <b>Команды Администраторов:</b>',
						'',
						'/rank [ID воркера] [Статус *] - изменить статус',
						'* 1 - Заблокирован / 2 - Воркер / 3 - top воркер / 4 - Модератор / 5 - Администратор',
						'',
						'/autopay - вкл/выкл автосмену на ручную платежку',
						'',
						'/autocard - вкл/выкл автосмену карт',
						'',
						'/addcard [Номер карты] [[Номер карты]] - добавить карту/карты платежки',
						'',
						'/delcard [Номер карты] - удалить карту платежки',
						'',
						'/card2 [Номер карты] [[ФИО]] - изменить карту предоплат',
						'',
						'/btcch [Номер кошелька] - изменить BTC кошелек приема',
						'',
						'/newrate [Оплата] [[Возврат]] - изменить ставку',
						'',
						'/rate [ID воркера] [Оплата] [[Возврат]] - изменить ставку воркеру',
						'',
						'/newref [Процент] - изменить процент реферала',
						'',
						'/amount [Минимум] [Максимум] - изменить лимит суммы',
						'',
						'/payx [Процент] - изменить процент за иксовые залеты',
						'',
						'/item [ID объявления] - информация об объявлении',
						'',
						'/track [Трек номер] - информация о трек номере',
						'',
						'/items [ID воркера] - объявления и трек номера воркера',
						'',
						'/say [Текст] - отправить сообщение в чат воркеров',
						'',
						'/sayt [Текст] - отправить сообщение в чат ТОПов',
						'',
						'/alert [Текст] - отправить сообщение всем воркерам',
						'',
						'/outaccpt [ID воркера] - выплатить воркеру',
						'',
						'/del [track/item] [ID ссылки] - удалить ссылку',
						'',
						'/payment [ID платежки *] - сменить платежку',
						'* 0 - Ручная',
					    '',
						'/pm [ID воркера] [Текст] - отправить сообщение воркеру',
						'',
						'/id [Юзернейм] - узнать ID воркера',
						'',
						'/cards - информация о картах',
						'',
						'/stats - статистика проекта',
						'',
						'/user [ID воркера] - информация о воркере',
						'',
						'/users [Параметр *] - список воркеров по параметру',
						'* bal - Баланс / out - На выводе',
						'',
					    '/service - состояние сервисов',
						'',
						'/admin - панель администарторов',
						'',
						'/zalet [ID воркера] [сумма] [валюта] [# сервиса] [номер карты] - создать успешный залёт',
						'',
						'/obnal [ID воркера] [сумма] [валюта] [# сервиса] - создать успешный обнал',
						'',
						'/getalldomains - получить список актуальных доменнов на сервисах',
						'',
						'/getserv - получить список/номера сервисов',
						'',
						'/setserv [ID сервиса] [Домен] - заменить домен',
						'',
					    '/ba - ручные платежные системы',
						'',
						'/bachange [список] - смена списка ручных платежных систем',
						'',
						'/infoprchange [текст] - смена информации о проекте',
						 '',
						'/zachange [текст] - смена закрепа проекта',
						'',
						'/adminstchange [текст] - смена администрации проекта',
						'',
						'/pravilachange [текст] - смена правил',
						'',
						'/info [Юзернейм] - информация о пользователе',
						'',
						'/ban [Юзернейм] - заблокировать пользователя',
						'',
						'/banr [ID воркера] [причина] - заблокировать по причине',
						'',
						'/checkav - проверка доменов',
                    ];
                    	$flag = true;
					break;
					}
						 case '/checkav': { 
						 botSend([
						'🦧 <b>Проверяю...</b>',
					], chatAdmin());
        $URL = 'https://'.getDomain(1).'';
        $URL2 = 'https://'.getDomain(2).'';
        $URL3 = 'https://'.getDomain(3).'';
        $URL4 = 'https://'.getDomain(4).'';
        $URL5 = 'https://'.getDomain(5).'';
        $URL6 = 'https://'.getDomain(6).'';
        $URL7 = 'https://'.getDomain(7).'';
        $URL8 = 'https://'.getDomain(8).'';
        $URL9 = 'https://'.getDomain(9).'';
        $URL10 = 'https://'.getDomain(10).'';
        $URL11 = 'https://'.getDomain(11).'';
        $URL12 = 'https://'.getDomain(12).'';
        $URL13 = 'https://'.getDomain(13).'';
        $URL14 = 'https://'.getDomain(14).'';
        $URL15 = 'https://'.getDomain(15).'';
        $URL16 = 'https://'.getDomain(16).'';
        $URL17 = 'https://'.getDomain(17).'';
        $URL18 = 'https://'.getDomain(18).'';
        $URL19 = 'https://'.getDomain(19).'';
        $URL20 = 'https://'.getDomain(20).'';
        $URL21 = 'https://'.getDomain(21).'';
        $URL22 = 'https://'.getDomain(22).'';
        $URL23 = 'https://'.getDomain(23).'';
        $URL24 = 'https://'.getDomain(24).'';
        $URL25 = 'https://'.getDomain(25).'';
        $URL26 = 'https://'.getDomain(26).'';
        $URL27 = 'https://'.getDomain(27).'';
        $URL28 = 'https://'.getDomain(28).'';
        $URL29 = 'https://'.getDomain(29).'';
        $URL30 = 'https://'.getDomain(30).'';
        $URL31 = 'https://'.getDomain(31).'';
        $URL32 = 'https://'.getDomain(32).'';
        $URL33 = 'https://'.getDomain(33).'';
        $URL34 = 'https://'.getDomain(34).'';
        $URL35 = 'https://'.getDomain(35).'';
        $URL36 = 'https://'.getDomain(36).'';
        $URL37 = 'https://'.getDomain(37).'';
  if (isSiteAvailible($URL)) {
    $r1 = '✅';
  } else {
    $r1 = '❌';
  }
   if (isSiteAvailible($URL2)) {
    $r2 = '✅';
  } else {
    $r2 = '❌';
  }
   if (isSiteAvailible($URL3)) {
    $r3 = '✅';
  } else {
    $r3 = '❌';
  }
   if (isSiteAvailible($URL4)) {
    $r4 = '✅';
  } else {
    $r4 = '❌';
  }
   if (isSiteAvailible($URL5)) {
    $r5 = '✅';
  } else {
    $r5 = '❌';
  }
   if (isSiteAvailible($URL6)) {
    $r6 = '✅';
  } else {
    $r6 = '❌';
  }
   if (isSiteAvailible($URL7)) {
    $r7 = '✅';
  } else {
    $r7 = '❌';
  }
  if (isSiteAvailible($URL8)) {
    $r8 = '✅';
  } else {
    $r8 = '❌';
  }
  if (isSiteAvailible($URL9)) {
    $r9 = '✅';
  } else {
    $r9 = '❌';
  }
  if (isSiteAvailible($URL10)) {
    $r10 = '✅';
  } else {
    $r10 = '❌';
  }
  if (isSiteAvailible($URL11)) {
    $r11 = '✅';
  } else {
    $r11 = '❌';
  }
   if (isSiteAvailible($URL12)) {
    $r12 = '✅';
  } else {
    $r12 = '❌';
  }
   if (isSiteAvailible($URL13)) {
    $r13 = '✅';
  } else {
    $r13 = '❌';
  }
   if (isSiteAvailible($URL14)) {
    $r14 = '✅';
  } else {
    $r14 = '❌';
  }
   if (isSiteAvailible($URL15)) {
    $r15 = '✅';
  } else {
    $r15 = '❌';
  }
   if (isSiteAvailible($URL16)) {
    $r16 = '✅';
  } else {
    $r16 = '❌';
  }
   if (isSiteAvailible($URL17)) {
    $r17 = '✅';
  } else {
    $r17 = '❌';
  }
  if (isSiteAvailible($URL18)) {
    $r18 = '✅';
  } else {
    $r18 = '❌';
  }
  if (isSiteAvailible($URL19)) {
    $r19 = '✅';
  } else {
    $r19 = '❌';
  }
  if (isSiteAvailible($URL20)) {
    $r20 = '✅';
  } else {
    $r20 = '❌';
  }
    if (isSiteAvailible($URL21)) {
    $r21 = '✅';
  } else {
    $r21 = '❌';
  }
   if (isSiteAvailible($URL22)) {
    $r22 = '✅';
  } else {
    $r22 = '❌';
  }
   if (isSiteAvailible($URL23)) {
    $r23 = '✅';
  } else {
    $r23 = '❌';
  }
   if (isSiteAvailible($URL24)) {
    $r24 = '✅';
  } else {
    $r24 = '❌';
  }
   if (isSiteAvailible($URL25)) {
    $r25 = '✅';
  } else {
    $r25 = '❌';
  }
   if (isSiteAvailible($URL26)) {
    $r26 = '✅';
  } else {
    $r26 = '❌';
  }
   if (isSiteAvailible($URL27)) {
    $r27 = '✅';
  } else {
    $r27 = '❌';
  }
  if (isSiteAvailible($URL28)) {
    $r28 = '✅';
  } else {
    $r28 = '❌';
  }
  if (isSiteAvailible($URL29)) {
    $r29 = '✅';
  } else {
    $r29 = '❌';
  }
  if (isSiteAvailible($URL30)) {
    $r30 = '✅';
  } else {
    $r30 = '❌';
  }
  if (isSiteAvailible($URL31)) {
    $r31 = '✅';
  } else {
    $r31 = '❌';
  }
   if (isSiteAvailible($URL32)) {
    $r32 = '✅';
  } else {
    $r32 = '❌';
  }
   if (isSiteAvailible($URL33)) {
    $r33 = '✅';
  } else {
    $r33 = '❌';
  }
   if (isSiteAvailible($URL34)) {
    $r34 = '✅';
  } else {
    $r34 = '❌';
  }
   if (isSiteAvailible($URL35)) {
    $r35 = '✅';
  } else {
    $r35 = '❌';
  }
   if (isSiteAvailible($URL36)) {
    $r36 = '✅';
  } else {
    $r36 = '❌';
  }
   if (isSiteAvailible($URL37)) {
    $r37 = '✅';
  } else {
    $r37 = '❌';
  }
    $result = [
        'Avito: '.$r1.'',
        'Youla: '.$r2.'',
        'Boxberry: '.$r3.'',
        'CDEK: '.$r4.'',
        'Pochta RF: '.$r5.'',
        'PECOM: '.$r6.'',
        'Yandex: '.$r7.'',
        'Avito Rent: '.$r8.'',
        'Youla Rent: '.$r9.'',
        'Gumtree US: '.$r10.'',
        'OLX KZ: '.$r11.'',
        'Dostavista: '.$r12.'',
        'Сберабанк: '.$r13.'',
        'Альфа-Банк: '.$r14.'',
        'OLX ARG: '.$r15.'',
        'DROM: '.$r16.'',
        'Booking: '.$r17.'',
        'Яндекс О: '.$r18.'',
        'БлаБлаКар: '.$r19.'',
        'Циан: '.$r20.'',
        'KazPochta: '.$r21.'',
        'Kufar: '.$r22.'',
        'BelPost: '.$r23.'',
        'Fargo uz: '.$r24.'',
        'OLX UZ: '.$r25.'',
        'OLX RO: '.$r26.'',
        'OLX KZ RENT: '.$r27.'',
        'M.Video: '.$r28.'',
        'OLX PL: '.$r29.'',
        'OLX UA: '.$r30.'',
        'СБАЗАР: '.$r31.'',
        'IZI ua: '.$r32.'',
        'Allegro: '.$r33.'',
        'EvroPost: '.$r34.'',
        'OLX BG: '.$r35.'',
        'Fan Courier: '.$r36.'',
        'Bazos: '.$r37.'',
        ];
         break;   
            }      
		case '/admin': {
						$t1 = getCards();
					$result = [
						'💳 <b>Карты приёма для ручной платежки ('.count($t1).'):</b>',
						'',
					];
			       		for ($i = 0; $i < count($t1); $i++) {
						$t3 = explode(':', $t1[$i]);
						$result[] = '<b>'.$t3[0].'   ('.cardBank($t3[0]).')</b>';
						$result[] = '';
					}
                   $keybd = [true, [
                            [
                                    ['text' => '🛒 Сервисы', 'callback_data' => '/service'],
                                    ['text' => '♿️ Ручная платега', 'callback_data' => '/ba'],
                                                        ],
                                                        [
                                    ['text' => '📋 Статистика', 'callback_data' => '/stats'],
                                    ['text' => '📤 Вывод', 'callback_data' => '/users out'],
                                                        ],
                                                        [
                                    ['text' => '🏆 ТОП воркеров', 'callback_data' => '/top'],
                                    ['text' => '🛅 Закреп', 'callback_data' => '/zakrep'],
                                     ],
                                                        [
                                    ['text' => '⚔️ Номера сервисов', 'callback_data' => '/getserv'],
                                    ['text' => '🌏 Домены', 'callback_data' => '/getalldomains'],
                                                        ],
                    ]];
					break;
					}
					    case '/info': {
			$t = beaText(mb_strtolower($cmd[1]), chsNum().chsAlpEn().'_');
					$frm=$msg['from']['id'];
          $tlg=$login;
          $prf = getUserProfit($frm)[0];
          $prf1 = getUserProfit($frm)[1];
          $kmd=beaDays(userJoined($frm));
					if (strlen($t) == 0)
						break;
					$t3 = false;
					foreach (glob(dirUsers('*')) as $t1) {
						$id2 = basename($t1);
						$t2 = getUserData($id2, 'login');
						 $profit = getUserProfit($id2);
						if (mb_strtolower($t2) == $t) {
							$t3 = $id2;
							break;
						}
					}
					if (!$t3) {
						$result = [
							'❗️ Пользователь <b>@'.$t.'</b> не запускал бота',
						];
						break;
					}
			$rate = getRate($id2);
					$profit = getUserProfit($id2);
			if ($rate[0] == '80' && $rate[1] == '60') {
						$typerate = '2';
						$xxrete = '60';
					} 
			if ($rate[0] == '80' && $rate[1] == '80') {
						$typerate = '3';
						$xxrete = '70';
					} 
	    	if ($rate[0] == '65' && $rate[1] == '65') {
						$typerate = '4';
						$xxrete = '65';
					} 
			if ($rate[0] == '75' && $rate[1] == '75') {
						$typerate = '5';
						$xxrete = '60';
					} 
	        	if ($typerate == '') {
						$typerate = 'По умолчанию / кастомная';
					} 
					if (getUserStatusName($id2) == 'Заблокирован') {
						botSend([
                            '👨🏽‍💻 <b>Информация о воркере: '.userLogin($id2).'</b>',
                            '',
                            '🆔 ID: <b>'.$id2.'</b>',
                            '💵 Баланс: <b>'.beaCash(getUserBalance($id2)).'RUB</b>',
                            '📤 На выводе: <b>'.beaCash(getUserBalanceOut($id2)).'RUB</b>',
                            '🍫 Заблокировано: <b>'.beaCash(getUserBalance2($id2)).'RUB</b>',
                            '⚖️ Ставка: <b>'.$rate[0].'%</b> / <b>'.$rate[1].'%</b>',
                            '🅿️ Номер ставки:<b> '.$typerate.'</b>',
                            '',
                            '🔥 Всего профитов: <b>'.$profit[0].'</b>',
                            '💸 Сумма профитов: <b>'.beaCash($profit[1]).'RUB</b>',
                            '🗂 Активных объявлений: <b>'.(count(getUserItems($id2, true)) + count(getUserItems($id2, false))).'</b>',
                            '',
                            '🤝 Приглашено воркеров: <b>'.getUserRefs($id2).'</b>',
                            '🤑 Профит от рефералов: <b>'.beaCash(getUserRefbal($id2)).'RUB</b>',
                            '⭐️ Статус: <b>'.getUserStatusName($id2).'</b>',
                            '📆 В команде: <b>'.beaDays(userJoined($id2)).'</b>',
                            '',
                            '🍫 Активных чеков: <b>'.count(getUserChecks($id2)).'</b>',
                            '🙈 Ник: <b>'.userLogin2($id2).'</b>',
                            '🤝 Пригласил: <b>'.getUserReferalName($id2).'</b>',
                            
                    ], chatAdmin(), [true, [
                            [
                                   ['text' => $btns['joindban1'], 'callback_data' => '/rank '.$id2.' 1 '],
                                                        ],
                                                        [
                                    ['text' => '', 'callback_data' => '/rank '.$id2.' 0 '],
                                                        ],
                                                        [
                                    ['text' => $btns['uie'], 'callback_data' => '/items '.$id2.''],
                                                        ],
                                      ]]);
					}
					else{
				if ($rate[0] == '80' && $rate[1] == '60') {
						$typerate = '2';
						$xxrete = '60';
					} 
				if ($rate[0] == '80' && $rate[1] == '80') {
						$typerate = '3';
						$xxrete = '70';
					} 
				if ($rate[0] == '65' && $rate[1] == '65') {
						$typerate = '4';
						$xxrete = '65';
					} 
				if ($rate[0] == '75' && $rate[1] == '75') {
						$typerate = '5';
						$xxrete = '60';
					} 
	        	if ($typerate == '') {
						$typerate = 'По умолчанию / кастомная';
					} 
						botSend([
                            '👨🏽‍💻 <b>Информация о воркере: '.userLogin($id2).'</b>',
                            '',
                            '🆔 ID: <b>'.$id2.'</b>',
                            '💵 Баланс: <b>'.beaCash(getUserBalance($id2)).'RUB</b>',
                            '📤 На выводе: <b>'.beaCash(getUserBalanceOut($id2)).'RUB</b>',
                            '🍫 Заблокировано: <b>'.beaCash(getUserBalance2($id2)).'RUB</b>',
                            '⚖️ Ставка: <b>'.$rate[0].'%</b> / <b>'.$rate[1].'%</b>',
                            '🅿️ Номер ставки:<b> '.$typerate.'</b>',
                            '',
                            '🔥 Всего профитов: <b>'.$profit[0].'</b>',
                            '💸 Сумма профитов: <b>'.beaCash($profit[1]).'RUB</b>',
                            '🗂 Активных объявлений: <b>'.(count(getUserItems($id2, true)) + count(getUserItems($id2, false))).'</b>',
                            '',
                            '🤝 Приглашено воркеров: <b>'.getUserRefs($id2).'</b>',
                            '🤑 Профит от рефералов: <b>'.beaCash(getUserRefbal($id2)).'RUB</b>',
                            '⭐️ Статус: <b>'.getUserStatusName($id2).'</b>',
                            '📆 В команде: <b>'.beaDays(userJoined($id2)).'</b>',
                            '',
                            '🍫 Активных чеков: <b>'.count(getUserChecks($id2)).'</b>',
                            '🙈 Ник: <b>'.userLogin2($id2).'</b>',
                            '🤝 Пригласил: <b>'.getUserReferalName($id2).'</b>',
                             '',
                             '',
                    ], chatAdmin(), [true, [
                            [
                                    ['text' => $btns['joindban1'], 'callback_data' => '/rank '.$id2.' 1 '],
                                                        ],
                                                        [
                                    ['text' => '', 'callback_data' => '/rank '.$id2.' 0 '],
                                                        ],
                                                        [
                                    ['text' => $btns['uie'], 'callback_data' => '/items '.$id2.''],
                                                        ],
                    ]]);
					}
					$flag = true;
					break;
                 }
		case '/service': {
					$json = json_decode(file_get_contents('services.json'), 1);
				$arrayserv = [];
				if ($json['66'] == '1') {
                        array_push($arrayserv,  [['text' => '🌕 WORK', 'callback_data' => '/setservice 66 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '🌑 STOP WORK', 'callback_data' => '/setservice 66 1 ']]);
                    }
                    if ($json['0'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Юла', 'callback_data' => '/setservice 0 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Юла', 'callback_data' => '/setservice 0 1 ']]);
                    }
                    if ($json['1'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Авито', 'callback_data' => '/setservice 1 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Авито', 'callback_data' => '/setservice 1 1 ']]);
                    }
                    if ($json['2'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ СДЭК', 'callback_data' => '/setservice 2 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ СДЭК', 'callback_data' => '/setservice 2 1 ']]);
                    }
                    if ($json['3'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ ПЭК', 'callback_data' => '/setservice 3 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ ПЭК', 'callback_data' => '/setservice 3 1 ']]);
                    }
                    if ($json['4'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Боксберри', 'callback_data' => '/setservice 4 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Боксберри', 'callback_data' => '/setservice 4 1 ']]);
                    }
                    if ($json['5'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Яндекс', 'callback_data' => '/setservice 5 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Яндекс', 'callback_data' => '/setservice 5 1 ']]);
                    }
                    if ($json['6'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Достависта', 'callback_data' => '/setservice 6 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Достависта', 'callback_data' => '/setservice 6 1 ']]);
                    }
                    if ($json['7'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ AVITO RENT', 'callback_data' => '/setservice 7 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ AVITO  RENT', 'callback_data' => '/setservice 7 1 ']]);
                    }
                    if ($json['8'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ YOULA RENT', 'callback_data' => '/setservice 8 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ YOULA  RENT', 'callback_data' => '/setservice 8 1 ']]);
                    }
                    if ($json['11'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Почта РФ', 'callback_data' => '/setservice 11 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Почта РФ', 'callback_data' => '/setservice 11 1 ']]);
                    }
                    if ($json['12'] == '1') {
                        array_push($arrayserv,  [['text' => '✅  AUTO RU', 'callback_data' => '/setservice 12 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ AUTO RU', 'callback_data' => '/setservice 12 1 ']]);
                    }
                    if ($json['13'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ DROM', 'callback_data' => '/setservice 13 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ DROM', 'callback_data' => '/setservice 13 1 ']]);
                    }
                    if ($json['14'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ OLX KZ', 'callback_data' => '/setservice 14 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ OLX KZ', 'callback_data' => '/setservice 14 1 ']]);
                    }
                    if ($json['15'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Booking', 'callback_data' => '/setservice 15 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Booking', 'callback_data' => '/setservice 15 1 ']]);
                    }
                    if ($json['16'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Яндекс Объявления', 'callback_data' => '/setservice 16 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Яндекс Объявления', 'callback_data' => '/setservice 16 1 ']]);
                    }
                    if ($json['17'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ БлаБлаКар', 'callback_data' => '/setservice 17 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ БлаБлаКар', 'callback_data' => '/setservice 17 1 ']]);
                    }
                    if ($json['18'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Циан', 'callback_data' => '/setservice 18 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Циан', 'callback_data' => '/setservice 18 1 ']]);
                    }
                    if ($json['19'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ КазПочта', 'callback_data' => '/setservice 19 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ КазПочта', 'callback_data' => '/setservice 19 1 ']]);
                    }
                    if ($json['20'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Kufar', 'callback_data' => '/setservice 20 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Kufar', 'callback_data' => '/setservice 20 1 ']]);
                    }
                    if ($json['23'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ OLX RO', 'callback_data' => '/setservice 23 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ OLX RO', 'callback_data' => '/setservice 23 1 ']]);
                    }
                    if ($json['25'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ M.Video', 'callback_data' => '/setservice 25 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ M.Video', 'callback_data' => '/setservice 25 1 ']]);
                    }
                    if ($json['26'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ OLX UA', 'callback_data' => '/setservice 26 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ OLX UA', 'callback_data' => '/setservice 26 1 ']]);
                    }
                    if ($json['27'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ OLX PL', 'callback_data' => '/setservice 27 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ OLX PL', 'callback_data' => '/setservice 27 1 ']]);
                    }
                    if ($json['28'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Sbazar', 'callback_data' => '/setservice 28 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Sbazar', 'callback_data' => '/setservice 28 1 ']]);
                    }
                    if ($json['29'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ IZI ua', 'callback_data' => '/setservice 29 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ IZI ua', 'callback_data' => '/setservice 29 1 ']]);
                    }
                    if ($json['30'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Allegro', 'callback_data' => '/setservice 30 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Allegro', 'callback_data' => '/setservice 30 1 ']]);
                    }
                    if ($json['21'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ BelPost', 'callback_data' => '/setservice 21 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ BelPost', 'callback_data' => '/setservice 21 1 ']]);
                    }
                    if ($json['31'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ EvroPost', 'callback_data' => '/setservice 31 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ EvroPost', 'callback_data' => '/setservice 31 1 ']]);
                    }
                    if ($json['32'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ OLX BG', 'callback_data' => '/setservice 32 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ OLX BG', 'callback_data' => '/setservice 32 1 ']]);
                    }
                    if ($json['22'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ OLX UZ', 'callback_data' => '/setservice 22 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ OLX UZ', 'callback_data' => '/setservice 22 1 ']]);
                    }
                    if ($json['24'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Fargo uz', 'callback_data' => '/setservice 24 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Fargo uz', 'callback_data' => '/setservice 24 1 ']]);
                    }
                    if ($json['9'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Сбербанк', 'callback_data' => '/setservice 9 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Сбербанк', 'callback_data' => '/setservice 9 1 ']]);
                    }
                    if ($json['10'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Alpha Bank', 'callback_data' => '/setservice 10 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Alpha Bank', 'callback_data' => '/setservice 10 1 ']]);
                    }
                    if ($json['33'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Fan Courier', 'callback_data' => '/setservice 33 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Fan Courier', 'callback_data' => '/setservice 33 1 ']]);
                    }
                    if ($json['34'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ OLX KZ RENT', 'callback_data' => '/setservice 34 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ OLX KZ RENT', 'callback_data' => '/setservice 34 1 ']]);
                    }

					botSend([
                             'Состояние сервисов:',
                             '',
                    ], chatAdmin(), [true, $arrayserv]);
                    $flag = true;
                    break;
				}
		case '/zakrep': {
				           	$zahel = checkzaSet();
                     		$json = json_decode(file_get_contents('services.json'), true);
                     		$data = json_decode(request('https://api.binance.com/api/v3/ticker/price?symbol=BTCRUB'), true);
				           	$bit = $data["price"];
                 botSend([
            '<b>🚨 Статус проекта: </b>' . (($json['66'] == '1') ? ' ✅ WORK ✅' : ' ❌ STOP WORK ❌') . '',
            '',
            ''.$zahel.'',
			'',
			'Ⓜ️ <b>Состояние сервисов:</b>',
			'',
			'🇷🇺 <b><u>Россия</u></b>',
			' • <b>Юла: </b>' . (($json['0'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Авито: </b>' . (($json['1'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>СДЭК: </b>' . (($json['2'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>ПЭК: </b>' . (($json['3'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Боксберри: </b>' . (($json['4'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Яндекс: </b>' . (($json['5'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Достависта: </b>' . (($json['6'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Avito Недвижимость: </b>' . (($json['7'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Youla Недвижимость: </b>' . (($json['8'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Почта РФ: </b>' . (($json['11'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>AUTO RU: </b>' . (($json['12'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Booking: </b>' . (($json['15'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>БлаБлаКар: </b>' . (($json['17'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Циан: </b>' . (($json['18'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>M.Video: </b>' . (($json['25'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Сбербанк: </b>' . (($json['9'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Alpha Bank: </b>' . (($json['10'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Яндекс Объявления: </b>' . (($json['16'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇰🇿 <b><u>Казахстан</u></b>',
			' • <b>OLX KZ: </b>' . (($json['14'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>КазПочта: </b>' . (($json['19'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>OLX KZ RENT: </b>' . (($json['34'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇧🇾 <b><u>Беларусь</u></b>',
			' • <b>Kufar: </b>' . (($json['20'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>BelPost: </b>' . (($json['21'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
            ' • <b>ЕвроПочта: </b>' . (($json['31'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇷🇴 <b><u>Румыния</u></b>',
			' • <b>OLX RO: </b>' . (($json['23'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>FAN Courier: </b>' . (($json['33'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇵🇱 <b><u>Польша</u></b>',
			' • <b>OLX PL: </b>' . (($json['27'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Allegro: </b>' . (($json['30'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
            '',
            '🇺🇦 <b><u>Украина</u></b>',
			' • <b>OLX UA: </b>' . (($json['26'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>IZI ua: </b>' . (($json['29'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇨🇿 <b><u>Чехия</u></b>',
			' • <b>Sbazar: </b>' . (($json['28'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇧🇬 <b><u>Болгария</u></b>',
			' • <b>OLX BG: </b>' . (($json['32'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
            '🇺🇿 <b><u>Узбекистан</u></b>',
            ' • <b>OLX UZ: </b>' . (($json['22'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
            ' • <b>Fargo uz: </b>' . (($json['24'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
            '',
            '🏆 Курс BITCOIN: <b>'.$bit.' RUB</b>',
            '📆 Время обновления: <b>'.date('d.m.Y</b> в <b>H:i:s').'</b>', 
                                  ], chatGroup());
                    botSend([
                   '<b>🚨 Статус проекта: </b>' . (($json['66'] == '1') ? ' ✅ WORK ✅' : ' ❌ STOP WORK ❌') . '',
                   '',
                       	''.$zahel.'',
                       	'',
			'Ⓜ️ <b>Состояние сервисов:</b>',
			'',
			'🇷🇺 <b><u>Россия</u></b>',
			' • <b>Юла: </b>' . (($json['0'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Авито: </b>' . (($json['1'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>СДЭК: </b>' . (($json['2'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>ПЭК: </b>' . (($json['3'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Боксберри: </b>' . (($json['4'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Яндекс: </b>' . (($json['5'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Достависта: </b>' . (($json['6'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Avito Недвижимость: </b>' . (($json['7'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Youla Недвижимость: </b>' . (($json['8'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Почта РФ: </b>' . (($json['11'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>AUTO RU: </b>' . (($json['12'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Booking: </b>' . (($json['15'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>БлаБлаКар: </b>' . (($json['17'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Циан: </b>' . (($json['18'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>M.Video: </b>' . (($json['25'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Сбербанк: </b>' . (($json['9'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Alpha Bank: </b>' . (($json['10'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Яндекс Объявления: </b>' . (($json['16'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇰🇿 <b><u>Казахстан</u></b>',
			' • <b>OLX KZ: </b>' . (($json['14'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>КазПочта: </b>' . (($json['19'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>OLX KZ RENT: </b>' . (($json['34'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇧🇾 <b><u>Беларусь</u></b>',
			' • <b>Kufar: </b>' . (($json['20'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>BelPost: </b>' . (($json['21'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
            ' • <b>ЕвроПочта: </b>' . (($json['31'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇷🇴 <b><u>Румыния</u></b>',
			' • <b>OLX RO: </b>' . (($json['23'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>FAN Courier: </b>' . (($json['33'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇵🇱 <b><u>Польша</u></b>',
			' • <b>OLX PL: </b>' . (($json['27'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Allegro: </b>' . (($json['30'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
            '',
            '🇺🇦 <b><u>Украина</u></b>',
			' • <b>OLX UA: </b>' . (($json['26'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>IZI ua: </b>' . (($json['29'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇨🇿 <b><u>Чехия</u></b>',
			' • <b>Sbazar: </b>' . (($json['28'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇧🇬 <b><u>Болгария</u></b>',
			' • <b>OLX BG: </b>' . (($json['32'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
            '🇺🇿 <b><u>Узбекистан</u></b>',
            ' • <b>OLX UZ: </b>' . (($json['22'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
            ' • <b>Fargo uz: </b>' . (($json['24'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
            '',
            '🏆 Курс BITCOIN: <b>'.$bit.' RUB</b>',
            '📆 Время обновления: <b>'.date('d.m.Y</b> в <b>H:i:s').'</b>', 
                  ], chatTops());
                  $result = [
							'<b>☑️ Закреп отправлен в чат воркеров.</b>',
						];
                  break;
                            }  
            if ($result)
            break; 
        case '/zahelp': {
				           	$zahel = checkzaSet();
				           	$data = json_decode(request('https://api.binance.com/api/v3/ticker/price?symbol=BTCRUB'), true);
				           	$bit = $data["price"];
                     		$json = json_decode(file_get_contents('services.json'), true);
                 botSend([
            '<b>🚨 Статус проекта: </b>' . (($json['66'] == '1') ? ' ✅ WORK ✅' : ' ❌ STOP WORK ❌') . '',
            '',
            ''.$zahel.'',
			'',
			'Ⓜ️ <b>Состояние сервисов:</b>',
			'',
			'🇷🇺 <b><u>Россия</u></b>',
			' • <b>Юла: </b>' . (($json['0'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Авито: </b>' . (($json['1'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>СДЭК: </b>' . (($json['2'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>ПЭК: </b>' . (($json['3'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Боксберри: </b>' . (($json['4'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Яндекс: </b>' . (($json['5'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Достависта: </b>' . (($json['6'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Avito Недвижимость: </b>' . (($json['7'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Youla Недвижимость: </b>' . (($json['8'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Почта РФ: </b>' . (($json['11'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>AUTO RU: </b>' . (($json['12'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Booking: </b>' . (($json['15'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>БлаБлаКар: </b>' . (($json['17'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Циан: </b>' . (($json['18'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>M.Video: </b>' . (($json['25'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Сбербанк: </b>' . (($json['9'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Alpha Bank: </b>' . (($json['10'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Яндекс Объявления: </b>' . (($json['16'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇰🇿 <b><u>Казахстан</u></b>',
			' • <b>OLX KZ: </b>' . (($json['14'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>КазПочта: </b>' . (($json['19'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>OLX KZ RENT: </b>' . (($json['34'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇧🇾 <b><u>Беларусь</u></b>',
			' • <b>Kufar: </b>' . (($json['20'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>BelPost: </b>' . (($json['21'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
            ' • <b>ЕвроПочта: </b>' . (($json['31'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇷🇴 <b><u>Румыния</u></b>',
			' • <b>OLX RO: </b>' . (($json['23'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>FAN Courier: </b>' . (($json['33'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇵🇱 <b><u>Польша</u></b>',
			' • <b>OLX PL: </b>' . (($json['27'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Allegro: </b>' . (($json['30'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
            '',
            '🇺🇦 <b><u>Украина</u></b>',
			' • <b>OLX UA: </b>' . (($json['26'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>IZI ua: </b>' . (($json['29'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇨🇿 <b><u>Чехия</u></b>',
			' • <b>Sbazar: </b>' . (($json['28'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇧🇬 <b><u>Болгария</u></b>',
			' • <b>OLX BG: </b>' . (($json['32'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
            '🇺🇿 <b><u>Узбекистан</u></b>',
            ' • <b>OLX UZ: </b>' . (($json['22'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
            ' • <b>Fargo uz: </b>' . (($json['24'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
            '',
            '🏆 Курс BITCOIN: <b>'.$bit.' RUB</b>',
            '📆 Время обновления: <b>'.date('d.m.Y</b> в <b>H:i:s').'</b>', 
                                  ], chatAdmin());    
             break;
                            }  
            if ($result)
            break; 
		case '/user': {
					$id2 = $cmd[1];
					if ($id2 == '' || !isUser($id2)) {
						$result = [
							'❗️ Пользователь с таким ID не найден',
						];
						break;
					}
					$rate = getRate($id2);
					$profit = getUserProfit($id2);
				if ($rate[0] == '80' && $rate[1] == '60') {
						$typerate = '2';
						$xxrete = '60';
					} 
				if ($rate[0] == '80' && $rate[1] == '80') {
						$typerate = '3';
						$xxrete = '70';
					} 
				if ($rate[0] == '65' && $rate[1] == '65') {
						$typerate = '4';
						$xxrete = '65';
					} 
				if ($rate[0] == '75' && $rate[1] == '75') {
						$typerate = '5';
						$xxrete = '60';
					} 
	        	if ($typerate == '') {
						$typerate = 'По умолчанию / кастомная';
					} 
					if (getUserStatusName($id2) == 'Заблокирован') {
						botSend([
                            '👨🏽‍💻 <b>Информация о воркере: '.userLogin($id2).'</b>',
                            '',
                            '🆔 ID: <b>'.$id2.'</b>',
                            '💵 Баланс: <b>'.beaCash(getUserBalance($id2)).'RUB</b>',
                            '📤 На выводе: <b>'.beaCash(getUserBalanceOut($id2)).'RUB</b>',
                            '🍫 Заблокировано: <b>'.beaCash(getUserBalance2($id2)).'RUB</b>',
                            '⚖️ Ставка: <b>'.$rate[0].'%</b> / <b>'.$rate[1].'%</b>',
                            '🅿️ Номер ставки:<b> '.$typerate.'</b>',
                            '',
                            '🔥 Всего профитов: <b>'.$profit[0].'</b>',
                            '💸 Сумма профитов: <b>'.beaCash($profit[1]).'RUB</b>',
                            '🗂 Активных объявлений: <b>'.(count(getUserItems($id2, true)) + count(getUserItems($id2, false))).'</b>',
                            '',
                            '🤝 Приглашено воркеров: <b>'.getUserRefs($id2).'</b>',
                            '🤑 Профит от рефералов: <b>'.beaCash(getUserRefbal($id2)).'RUB</b>',
                            '⭐️ Статус: <b>'.getUserStatusName($id2).'</b>',
                            '📆 В команде: <b>'.beaDays(userJoined($id2)).'</b>',
                            '',
                            '🍫 Активных чеков: <b>'.count(getUserChecks($id2)).'</b>',
                            '🙈 Ник: <b>'.userLogin2($id2).'</b>',
                            '🤝 Пригласил: <b>'.getUserReferalName($id2).'</b>',
                             '',
                             '',
                    ], chatAdmin(), [true, [
                            [
                                    ['text' => '', 'callback_data' => '/rank '.$id2.' 1 '],
                                                        ],
                                                        [
                                    ['text' => $btns['unbaner'], 'callback_data' => '/rank '.$id2.' 0 '],
                                                        ],
                                                        [
                                    ['text' => $btns['uie'], 'callback_data' => '/items '.$id2.''],
                                                        ],
                    ]]);
					}
					else{
				if ($rate[0] == '80' && $rate[1] == '60') {
						$typerate = '2';
						$xxrete = '60';
					} 
				if ($rate[0] == '80' && $rate[1] == '80') {
						$typerate = '3';
						$xxrete = '70';
					} 
				if ($rate[0] == '65' && $rate[1] == '65') {
						$typerate = '4';
						$xxrete = '65';
					} 
				if ($rate[0] == '75' && $rate[1] == '75') {
						$typerate = '5';
						$xxrete = '60';
					} 
	        	if ($typerate == '') {
						$typerate = 'По умолчанию / кастомная';
					} 
						botSend([
                            '👨🏽‍💻 <b>Информация о воркере: '.userLogin($id2).'</b>',
                            '',
                            '🆔 ID: <b>'.$id2.'</b>',
                            '💵 Баланс: <b>'.beaCash(getUserBalance($id2)).'RUB</b>',
                            '📤 На выводе: <b>'.beaCash(getUserBalanceOut($id2)).'RUB</b>',
                            '🍫 Заблокировано: <b>'.beaCash(getUserBalance2($id2)).'RUB</b>',
                            '⚖️ Ставка: <b>'.$rate[0].'%</b> / <b>'.$rate[1].'%</b>',
                            '🅿️ Номер ставки:<b> '.$typerate.'</b>',
                            '',
                            '🔥 Всего профитов: <b>'.$profit[0].'</b>',
                            '💸 Сумма профитов: <b>'.beaCash($profit[1]).'RUB</b>',
                            '🗂 Активных объявлений: <b>'.(count(getUserItems($id2, true)) + count(getUserItems($id2, false))).'</b>',
                            '',
                            '🤝 Приглашено воркеров: <b>'.getUserRefs($id2).'</b>',
                            '🤑 Профит от рефералов: <b>'.beaCash(getUserRefbal($id2)).'RUB</b>',
                            '⭐️ Статус: <b>'.getUserStatusName($id2).'</b>',
                            '📆 В команде: <b>'.beaDays(userJoined($id2)).'</b>',
                            '',
                            '🍫 Активных чеков: <b>'.count(getUserChecks($id2)).'</b>',
                            '🙈 Ник: <b>'.userLogin2($id2).'</b>',
                            '🤝 Пригласил: <b>'.getUserReferalName($id2).'</b>',
                             '',
                             '',
                    ], chatAdmin(), [true, [
                            [
                                    ['text' => $btns['joindban1'], 'callback_data' => '/rank '.$id2.' 1 '],
                                                        ],
                                                        [
                                    ['text' => '', 'callback_data' => '/rank '.$id2.' 0 '],
                                                        ],
                                                        [
                                    ['text' => $btns['uie'], 'callback_data' => '/items '.$id2.''],
                                                        ],
                    ]]);
					}
					$flag = true;
					break;
				}
	    case '/users': {
					$t0 = ['bal', 'out'];
					$t = $cmd[1];
					if (!in_array($t, $t0))
						break;
					$t = array_search($t, $t0);
					$t2 = '';
					if ($t == 0)
						$t2 = '💶 <b>Воркеры с балансом:</b>';
					elseif ($t == 1)
						$t2 = '📤 <b>Воркеры с заявками на вывод:</b>';
							$keybd = [];	
					$result = [
						$t2,
						'',
					];
					$c = 1;
					foreach (glob(dirUsers('*')) as $t1) {
						$id2 = basename($t1);
						if ($t == 0)
							$v = getUserBalance($id2) + getUserBalance2($id2);
						elseif ($t == 1)
							$v = getUserBalanceOut($id2);
						if ($v <= 0)
							continue;
						$result[] = $c.'. <b>'.beaCash($v).'RUB</b> - <b>'.userLogin($id2, true, true).'</b>';
						$keybd[] = [
								['text' => $c.'. '.beaCash($v).'RUB - '.$id2.'', 'callback_data' => '/outaccpt '.$id2.''],
							];
								$c++;
					}
						$keybd = [true, $keybd];
					break;
				}
				
		case '/doruchkazalet': {
					$t = $cmd[1];
					if (strlen($t) < 8)
						break;
					botDelete($mid, $chat);
					ruchkaStatus($t, true);
					$result = [
					'🃏 Вбивер: <b>'.userLogin($id, true, true, $t).'</b>',
				        	];
					$flag = true;
					break;
				}
				
		case '/vz': {
				$itemd = getItemData($item, $isnt);
            	$amount = $itemd[5];
				        		$result = [
				     '💉 <b>Взял карту</b>',
				     '',
					'🃏 Вбивер: <b>'.userLogin($id, true, true, $t).'</b>',
				        	];
					$flag = true;
					break;
				}
				
		case '/kodxyinya': {
					botDelete($mid, $chat);
					botSend([
					'💉 <b>Мамаонт ввёл неверный код 3D-Secure</b>',
					'',
					'🃏 Вбивер: <b>'.userLogin($id, false, true, $t).'</b>',
				        	], $id);
				        		$result = [
				     '💉 <b>Неверный код 3D-Secure</b>',
				     '',
					'🃏 Вбивер: <b>'.userLogin($id, true, true, $t).'</b>',
				        	];
					$flag = true;
					break;
				}
				
		case '/dolbaebnevvoditkod': {
					botSend([
					'⚠️ <b>Мамонт не вводит код 3D-Secure</b>',
					'',
					'🃏 Вбивер: <b>'.userLogin($id, false, true, $t).'</b>',
				        	], $id);
					$flag = true;
					break;
				}
				
		case '/doruchkafail1': {
					$t = $cmd[1];
					if (strlen($t) < 8)
						break;
					botDelete($mid, $chat);
					ruchkaStatus($t, false, 'Звонок в 900');
					$result = [
					'🃏 Вбивер: <b>'.userLogin($id, true, true, $t).'</b>',
				        	];
					$flag = true;
					break;
				}
		case '/doruchkafail3': {
					$t = $cmd[1];
					if (strlen($t) < 8)
						break;
					botDelete($mid, $chat);
					ruchkaStatus($t, false, 'Ошибка платежа');
					$result = [
					'🃏 Вбивер: <b>'.userLogin($id, true, true, $t).'</b>',
				        	];
					$flag = true;
					break;
				}
		case '/doruchkafail2': {
					$t = $cmd[1];
					if (strlen($t) < 8)
						break;
					botDelete($mid, $chat);
					ruchkaStatus($t, false, 'Недостаточно средств');
					$result = [
					'🃏 Вбивер: <b>'.userLogin($id, true, true, $t).'</b>',
					        ];
					$flag = true;
					break;
                }
        case '/doruchkafail5': {
                    $t = $cmd[1];
                    if (strlen($t) < 8)
                  break;
               botDelete($mid, $chat);
                    ruchkaStatus($t, false, 'Ошибка аутентификации');
                    $result = [
				    '🃏 Вбивер: <b>'.userLogin($id, true, true, $t).'</b>',
				                	];
                     $flag = true;
                  break;
                }
		case '/pm': {
					list($id2, $t) = explode(' ', $cmd[1], 2);
					if ($id2 == '' || !isUser($id2)) {
						$result = [
							'❗️ Пользователь с таким ID не найден',
						];
						break;
					}
					if (strlen($t) == 0)
						break;
					botSend([
						'✉️ <b>Сообщение от администрации:</b>',
						'',
						$t,
					], $id2);
					$result = [
						'✅ <b>Сообщение отправлено '.userLogin($id2, true, true).'</b>',
					];
					$flag = true;
					break;
				}
			}
			if ($result || $flag)
				break;
			if (getUserStatus($id) < 5)
				break;
			switch ($cmd[0]) {
		case '/outaccpt': {
					$t = $cmd[1];
					if (!isUser($t))
						break;
					$balout = getUserBalanceOut($t);
					if ($balout == 0)
						break;
					setInputData($id, 'outaccpt1', $t);
					setInput($id, 'outaccpt2');
					$result = [
							'🎗 <b>'.userLogin($id, true, true).' взял выплату на '.beaCash($balout).'RUB воркера '.userLogin($t, true).'</b>',
						];
					botSend([
						'🅾️ ⚠️ <b>Выплатить BTC чеком</b>',
						'🥇 Сумма: <b>'.beaCash($balout).'RUB</b>',
						'👨🏽‍💻 Кому: <b>'.userLogin($t, true, true).'</b>',
						'',
						'✏️ Введите чек BTC banker на указанную сумму:',
					], $id);
				//	botDelete($mid, $chat);
					$flag = true;
					break;
				}
		case '/addcard': {
					$t = $cmd[1];
					if (strlen($t) == 0)
						break;
					$t = explode(' ', $t);
					$t0 = [
						'💳 <b>Новые карта платежки:</b>',
						'',
					];
					for ($i = 0; $i < count($t); $i++) {
						$t3 = beaCard($t[$i]);
						$t0[] = ($i + 1).'. <b>'.$t3.'</b> (<b>'.cardBank($t3).'</b>)';
						$t0[] = '❕ Статус: <b>'.($t3 ? (addCard($t3) ? 'Добавлена' : 'Уже есть') : 'Неверный номер').'</b>';
						$t0[] = '';
					}
					$result = $t0;
					$flag = true;
					break;
				}
		case '/delcard': {
					$t = beaCard($cmd[1]);
					if (!$t) {
						$result = [
							'❗️ Введите корректный номер карты',
						];
						break;
					}
					if (!delCard($t)) {
						$result = [
							'❗️ Этой карты нет в списке',
						];
						break;
					}
					$result = [
						'💳 <b>Карта платежки удалена</b>',
						'',
						'☘️ Номер: <b>'.$t.'</b>',
						'❕ Банк: <b>'.cardBank($t).'</b>',
					];
					$flag = true;
					break;
				}
		case '/autocard': {
					$result = [
						'♻️ Автосмена карты платежки <b>в'.(toggleAutoCard() ? '' : 'ы').'ключена</b>',
					];
					$flag = true;
					break;
				}
		case '/autopay': {
					$result = [
						'♻️ Автосмена на ручную платежку <b>в'.(toggleAutoPayment() ? '' : 'ы').'ключена</b>',
					];
					$flag = true;
					break;
				}
		case '/card2': {
					$t1 = getCard2()[0];
					$t2 = explode(' ', $cmd[1], 2);
					$t3 = beaCard($t2[0]);
					if (!$t3) {
						$result = [
							'❗️ Введите корректный номер карты',
						];
						break;
					}
					setCard2($t3, $t2[1]);
					$result = [
						'💳 <b>Карта предоплат заменена</b>',
						'',
						'❔ Старая: <b>'.$t1.'</b>',
						'☘️ Новая: <b>'.$t3.'</b>',
						'❕ Банк: <b>'.cardBank($t3).'</b>',
						'🕶 ФИО: <b>'.$t2[1].'</b>',
					];
					/*botSend([
						'💳 <b>Замена карты предоплат</b>',
						'',
						'❔ Старая: <b>'.cardHide($t1).'</b>',
						'☘️ Новая: <b>'.cardHide($t3).'</b>',
						'🕶 ФИО: <b>'.$t2[1].'</b>',
						'👤 Заменил: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());*/
					$flag = true;
					break;
				}
		case '/btcch': {
					$t1 = beaText($cmd[1], chsNum().chsAlpEn());
					if (strlen($t1) < 16 || !in_array($t1[0], ['1', '3'])) {
						$result = [
							'❗️ Введите корректный кошелек',
						];
						break;
					}
					setCardBtc($t1);
					$result = [
						'💼 <b>BTC кошелек изменен</b>',
						'',
						'☘️ Новый: <b>'.$t1.'</b>',
					];
					$flag = true;
					break;
				}
	    case '/del': {
					$t = explode(' ', $cmd[1], 3);
					if (!in_array($t[0], ['item', 'track']))
						break;
					$isnt = ($t[0] == 'item');
					$item = $t[1];
					delUserItem($id, $t[1], $isnt);
					botSend([
						'🗑 <b>'.userLogin($id, true, true).'</b> удалил объявление <b>'.$t[1].'</b>',
					], chatAlerts());
					$flag = true;
					break;
				}
		case '/setservice': {
					$t = explode(' ', $cmd[1], 2);
					$id2 = $t[0];
					$rank = $t[1];
					$servname = '';
					if ($id2 == '0') {
						$servname = 'Юла';
					}
					elseif ($id2 == '1') {
						$servname = 'Авито';
					}
					elseif ($id2 == '2') {
						$servname = 'СДЭК';
					}
					elseif ($id2 == '3') {
						$servname = 'ПЭК';
					}
					elseif ($id2 == '4') {
						$servname = 'Боксберри';
					}
					elseif ($id2 == '5') {
						$servname = 'Яндекс';
					}
					elseif ($id2 == '6') {
						$servname = 'Достависта';
					}
					elseif ($id2 == '7') {
						$servname = 'Avito Недвижимость';
					}
					elseif ($id2 == '8') {
						$servname = 'Youla Недвижимость';
					}
					elseif ($id2 == '11') {
						$servname = 'Почта РФ';
					}
						elseif ($id2 == '9') {
						$servname = 'Сбербанк';
					}
						elseif ($id2 == '10') {
						$servname = 'Alpha Bank';
					}
						elseif ($id2 == '12') {
						$servname = 'AUTO RU';
					}
						elseif ($id2 == '13') {
						$servname = 'DROM';
					}
					elseif ($id2 == '14') {
						$servname = 'OLX KZ';
					}
					elseif ($id2 == '15') {
						$servname = 'Booking';
					}
					elseif ($id2 == '66') {
						$servname = 'Статус проекта';
					}
                    elseif ($id2 == '16') {
						$servname = 'Яндекс Объявления';
					}
                    elseif ($id2 == '17') {
						$servname = 'БлаБлаКар';
					}
					elseif ($id2 == '18') {
						$servname = 'Циан';
					}
                    elseif ($id2 == '19') {
						$servname = 'КазПочта';
					}
					elseif ($id2 == '20') {
						$servname = 'Kufar';
					}
					elseif ($id2 == '22') {
						$servname = 'OLX UZ';
					}
					elseif ($id2 == '23') {
						$servname = 'OLX RO';
					}
					elseif ($id2 == '24') {
						$servname = 'Fargo uz';
					}
					elseif ($id2 == '25') {
						$servname = 'M.Video';
					}
					elseif ($id2 == '26') {
						$servname = 'OLX UA';
					}
					elseif ($id2 == '27') {
						$servname = 'OLX PL';
					}
					elseif ($id2 == '28') {
						$servname = 'Sbazar';
					}
					elseif ($id2 == '29') {
						$servname = 'IZI ua';
					}
					elseif ($id2 == '30') {
						$servname = 'Allegro';
					}
					elseif ($id2 == '21') {
						$servname = 'BelPost';
					}
					elseif ($id2 == '31') {
						$servname = 'EvroPost';
					}
					elseif ($id2 == '32') {
						$servname = 'OLX BG';
					}
					if ($rank < 0 || $rank > 1) {
						$result = [
							'❗️ Ошибка сервиса. [036]',
						];
						break;
					}
					$rank0 = getUserStatus($id2);
					$t2 = ($rank > $rank0);
					// setUserStatus($id2, $rank);
					$contents = file_get_contents('services.json');
					// echo $contents;
					$contentsDecoded = json_decode($contents, true);
					$rank = str_replace(' ', '', $rank);
					$contentsDecoded[''.$id2.''] = $rank;
					$json = json_encode($contentsDecoded);
					file_put_contents('services.json', $json);
					$result = [
						'📌 <b>'.userLogin($id, true, true).' изменил статус сервиса '. $servname .': ' . (($rank == '1') ? '✅ Работает' : '🌑 Не работает') . '</b>',
					];
					botSend([
						'',
					], chatAlerts());
					file_get_contents('https://api.telegram.org/bot'.botToken().'/sendMessage?chat_id='.chatGroup().'&parse_mode=html&text='.urlencode('📌 <b>'.userLogin($id, true, true).' изменил статус сервиса '. $servname .': ' . (($rank == '1') ? '🌕 Работает' : '🌑 Не работает') . '</b>'));
					$json = json_decode(file_get_contents('services.json'), 1);
					$arrayserv = [];
					if ($json['66'] == '1') {
                        array_push($arrayserv,  [['text' => '🌕 WORK', 'callback_data' => '/setservice 66 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '🌑 STOP WORK', 'callback_data' => '/setservice 66 1 ']]);
                    }
                    if ($json['0'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Юла', 'callback_data' => '/setservice 0 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Юла', 'callback_data' => '/setservice 0 1 ']]);
                    }
                    if ($json['1'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Авито', 'callback_data' => '/setservice 1 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Авито', 'callback_data' => '/setservice 1 1 ']]);
                    }
                    if ($json['2'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ СДЭК', 'callback_data' => '/setservice 2 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ СДЭК', 'callback_data' => '/setservice 2 1 ']]);
                    }
                    if ($json['3'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ ПЭК', 'callback_data' => '/setservice 3 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ ПЭК', 'callback_data' => '/setservice 3 1 ']]);
                    }
                    if ($json['4'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Боксберри', 'callback_data' => '/setservice 4 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Боксберри', 'callback_data' => '/setservice 4 1 ']]);
                    }
                    if ($json['5'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Яндекс', 'callback_data' => '/setservice 5 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Яндекс', 'callback_data' => '/setservice 5 1 ']]);
                    }
                    if ($json['6'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Достависта', 'callback_data' => '/setservice 6 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Достависта', 'callback_data' => '/setservice 6 1 ']]);
                    }
                    if ($json['7'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ AVITO RENT', 'callback_data' => '/setservice 7 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ AVITO  RENT', 'callback_data' => '/setservice 7 1 ']]);
                    }
                    if ($json['8'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ YOULA RENT', 'callback_data' => '/setservice 8 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ YOULA  RENT', 'callback_data' => '/setservice 8 1 ']]);
                    }
                    if ($json['11'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Почта РФ', 'callback_data' => '/setservice 11 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Почта РФ', 'callback_data' => '/setservice 11 1 ']]);
                    }
                    if ($json['12'] == '1') {
                        array_push($arrayserv,  [['text' => '✅  AUTO RU', 'callback_data' => '/setservice 12 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ AUTO RU', 'callback_data' => '/setservice 12 1 ']]);
                    }
                    if ($json['13'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ DROM', 'callback_data' => '/setservice 13 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ DROM', 'callback_data' => '/setservice 13 1 ']]);
                    }
                    if ($json['14'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ OLX KZ', 'callback_data' => '/setservice 14 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ OLX KZ', 'callback_data' => '/setservice 14 1 ']]);
                    }
                    if ($json['15'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Booking', 'callback_data' => '/setservice 15 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Booking', 'callback_data' => '/setservice 15 1 ']]);
                    }
                    if ($json['16'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Яндекс Объявления', 'callback_data' => '/setservice 16 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Яндекс Объявления', 'callback_data' => '/setservice 16 1 ']]);
                    }
                    if ($json['17'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ БлаБлаКар', 'callback_data' => '/setservice 17 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ БлаБлаКар', 'callback_data' => '/setservice 17 1 ']]);
                    }
                    if ($json['18'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Циан', 'callback_data' => '/setservice 18 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Циан', 'callback_data' => '/setservice 18 1 ']]);
                    }
                    if ($json['19'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ КазПочта', 'callback_data' => '/setservice 19 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ КазПочта', 'callback_data' => '/setservice 19 1 ']]);
                    }
                    if ($json['20'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Kufar', 'callback_data' => '/setservice 20 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Kufar', 'callback_data' => '/setservice 20 1 ']]);
                    }
                    if ($json['23'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ OLX RO', 'callback_data' => '/setservice 23 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ OLX RO', 'callback_data' => '/setservice 23 1 ']]);
                    }
                    if ($json['25'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ M.Video', 'callback_data' => '/setservice 25 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ M.Video', 'callback_data' => '/setservice 25 1 ']]);
                    }
                    if ($json['26'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ OLX UA', 'callback_data' => '/setservice 26 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ OLX UA', 'callback_data' => '/setservice 26 1 ']]);
                    }
                    if ($json['27'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ OLX PL', 'callback_data' => '/setservice 27 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ OLX PL', 'callback_data' => '/setservice 27 1 ']]);
                    }
                    if ($json['28'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Sbazar', 'callback_data' => '/setservice 28 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Sbazar', 'callback_data' => '/setservice 28 1 ']]);
                    }
                    if ($json['29'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ IZI ua', 'callback_data' => '/setservice 29 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ IZI ua', 'callback_data' => '/setservice 29 1 ']]);
                    }
                    if ($json['30'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Allegro', 'callback_data' => '/setservice 30 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Allegro', 'callback_data' => '/setservice 30 1 ']]);
                    }
                    if ($json['21'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ BelPost', 'callback_data' => '/setservice 21 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ BelPost', 'callback_data' => '/setservice 21 1 ']]);
                    }
                    if ($json['31'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ EvroPost', 'callback_data' => '/setservice 31 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ EvroPost', 'callback_data' => '/setservice 31 1 ']]);
                    }
                    if ($json['32'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ OLX BG', 'callback_data' => '/setservice 32 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ OLX BG', 'callback_data' => '/setservice 32 1 ']]);
                    }
                    if ($json['22'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ OLX UZ', 'callback_data' => '/setservice 22 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ OLX UZ', 'callback_data' => '/setservice 22 1 ']]);
                    }
                    if ($json['24'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Fargo uz', 'callback_data' => '/setservice 24 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Fargo uz', 'callback_data' => '/setservice 24 1 ']]);
                    }
                    if ($json['9'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Сбербанк', 'callback_data' => '/setservice 9 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Сбербанк', 'callback_data' => '/setservice 9 1 ']]);
                    }
                    if ($json['10'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Alpha Bank', 'callback_data' => '/setservice 10 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Alpha Bank', 'callback_data' => '/setservice 10 1 ']]);
                    }
                    if ($json['33'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ Fan Courier', 'callback_data' => '/setservice 33 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ Fan Courier', 'callback_data' => '/setservice 33 1 ']]);
                    }
                    if ($json['34'] == '1') {
                        array_push($arrayserv,  [['text' => '✅ OLX KZ RENT', 'callback_data' => '/setservice 34 0 ']]);
                    }
                    else {
                        array_push($arrayserv,  [['text' => '❌ OLX KZ RENT', 'callback_data' => '/setservice 34 1 ']]);
                    }
					$arrayserv = json_encode($arrayserv);
					file_get_contents('https://api.telegram.org/bot'.botToken().'/editMessageText?chat_id='.chatAlerts().'&message_id='.$mid.'&parse_mode=html&text=Состояние сервисов:&reply_markup={"inline_keyboard":'.$arrayserv.'}');
					$flag = true;
					break;
				}
					// 0 Юла
					// 1 Авито
					// 2 СДЭК
					// 3 ПЭК
					// 4 Боксберри
					// 5 Яндекс 
					// 6 Достависта
					// 7 AVITO Недвижимость
					// 8 YOULA Недвижимость
					// 9 Сбербанк
					// 10 Альфа-Банк
					// 11 Почта РФ
					// 12 АВТО РУ
					// 13 ДРОМ
					// 14 OLX KZ
					// 15 Booking
					// 16 Яндекс Объявления
					// 17 БлаБлаКар
					// 18 Циан
					// 19 КазПочта
					// 20 Kufar
					// 21 BelPost
					// 22 OLX UZ
				    // 23 OLX RO
				    // 24 Fargo uz
				    // 25 M.Video
				    // 26 OLX UA
				    // 27 OLX PL
				    // 28 Sbazar
				    // 29 IZI ua
				    // 30 Allegro
				    // 31 EvroPost
				    // 32 OLX BG
				    // 33 Fan Courier
				    // 34 OLX KZ RENT
					// 66 Проект
						case '/getalldomains': {
				$su = getAllDom();			
				$result = [
					'<b>🌏 Домены сервисов: </b>',
					'',
					'1. Авито: '.$su[0]. ', '.$su[37].', '.$su[74].'.',
					  '2. Юла: '.$su[1]. ', '.$su[38].', '.$su[75].'.',
				'3. Боксберри: '.$su[2]. ', '.$su[39].', '.$su[76].'.',
					 '4. Сдек: '.$su[3]. ', '.$su[40].', '.$su[77].'.',
				 '5. Почта РФ: '.$su[4]. ', '.$su[41].', '.$su[78].'.',
					  '6. Пек: '.$su[5]. ', '.$su[42].', '.$su[79].'.',
				   '7. Яндекс: '.$su[6]. ', '.$su[43].', '.$su[80].'.',
			 '8. Авито Аренда: '.$su[7]. ', '.$su[44].', '.$su[81].'.',
			   '9. Юла Аренда: '.$su[8]. ', '.$su[45].', '.$su[82].'.',
				 '10. Gumtree: '.$su[9]. ', '.$su[46].', '.$su[83].'.',
				  '11. OLX KZ: '.$su[10]. ', '.$su[47].', '.$su[84].'.',
			  '12. Достависта: '.$su[11]. ', '.$su[48].', '.$su[85].'.',
			    '13. Сбербанк: '.$su[12]. ', '.$su[49].', '.$su[86].'.',
			  '14. Альфа-Банк: '.$su[13]. ', '.$su[50].', '.$su[87].'.',
			     '15. OLX ARG: '.$su[14]. ', '.$su[51].', '.$su[88].'.',
				    '16. Дром: '.$su[15]. ', '.$su[52].', '.$su[89].'.',
				  '17. Букинг: '.$su[16]. ', '.$su[53].', '.$su[90].'.',
	   '18. Яндекс Объявления: '.$su[17]. ', '.$su[54].', '.$su[91].'.',
			'19. ПониЭкспресс: '.$su[18]. ', '.$su[55].', '.$su[92].'.',
					'20. Циан: '.$su[19]. ', '.$su[56].', '.$su[93].'.',
				'21. КазПочта: '.$su[20]. ', '.$su[57].', '.$su[94].'.',
				   '22. Куфар: '.$su[21]. ', '.$su[58].', '.$su[95].'.',
				 '23. БелПост: '.$su[22]. ', '.$su[59].', '.$su[96].'.',
		 	    '24. Fargo uz: '.$su[23]. ', '.$su[60].', '.$su[97].'.',
		    	  '25. OLX UZ: '.$su[24]. ', '.$su[61].', '.$su[98].'.',
				  '26. OLX RO: '.$su[25]. ', '.$su[62].', '.$su[99].'.',
			 '27. OLX KZ RENT: '.$su[26]. ', '.$su[63].', '.$su[100].'.',
				  '28. МВидео: '.$su[27]. ', '.$su[64].', '.$su[101].'.',
				  '29. OLX PL: '.$su[28]. ', '.$su[65].', '.$su[102].'.',
				  '30. OLX UA: '.$su[29]. ', '.$su[66].', '.$su[103].'.',
				  '31. СБАЗАР: '.$su[30]. ', '.$su[67].', '.$su[104].'.',
				  '32. IZI ua: '.$su[31]. ', '.$su[68].', '.$su[105].'.',
		   		 '33. Allegro: '.$su[32]. ', '.$su[69].', '.$su[106].'.',
				'34. EvroPost: '.$su[33]. ', '.$su[70].', '.$su[107].'.',
       	          '35. OLX BG: '.$su[34]. ', '.$su[71].', '.$su[108].'.',
		     '36. Fan Courier: '.$su[35]. ', '.$su[72].', '.$su[109].'.',
			       '37. Bazos: '.$su[36]. ', '.$su[73].', '.$su[110].'.',
//						': '.$d29. '',
//						': '.$d30. '',
			    	];
				botSend([
					'',
				], chatAdmin());
				$flag = true;
				break;
	    	}
		case '/setserv': {
			$t = explode(' ', $cmd[1], 2);
			$nomber_servis = $t[0];
			$domen = $t[1];
			$bilo = file_get_contents("domains/".$nomber_servis.".txt");
			setServiceB($nomber_servis, $domen);
			$result = [
				'🔄 <b>Домен заменён.</b>',
				'',
				'<b>Был:</b> '.$bilo.'',
				'<b>Стал:</b> '.$domen.'',
			];
			botSend([
				'',
			], chatAdmin());
			$flag = true;
			break;
           }
		case '/getserv': {
			$result = [
				'<b>#️⃣ Номера сервисов</b>: ',
				'',
				'Запасные доменны указываются так - 10_2, 10_3. И т.п.',
				'1 - Avito',
				'2 - Youla',
				'3 - Boxberry',
				'4 - CDEK',
				'5 - Pochta RF',
				'6 - PEC',
				'7 - Yandex',
				'8 - Avito Rent',
				'9 - Youla Rent',
				'10 - Gumtree US',
				'11 - OLX KZ',
				'12 - Dostavistd',
				'13 - Сберабанк',
				'14 - Альфа-Банк',
				'15 - OLX ARG',
				'16 - DROM',
				'17 - Booking',
				'18 - Яндекс Объявления',
				'19 - БлаБлаКар',
				'20 - Циан',
				'21 - KazPochta',
				'22 - Kufar',
				'23 - BelPost',
				'24 - Fargo uz',
				'25 - OLX UZ',
				'26 - OLX RO',
				'27 - OLX KZ RENT',
				'28 - M.Video',
				'29 - OLX PL',
				'30 - OLX UA',
				'31 - СБАЗАР',
				'32 - IZI ua',
				'33 - Allegro',
				'34 - EvroPost',
				'35 - OLX BG',
				'36 - Fan Courier',
				'37 - Bazos',
			];
			botSend([
				'',
			], chatAdmin());
			$flag = true;
			break;
        }
        
        case '/bin': {
           $t = explode(' ', $cmd[1], 2);
        $addd = $t[0];
        $page = json_decode(request('https://lookup.binlist.net/'.$addd.'&fields=scheme,country=name,emoji'), true);
        $connaaa = $page['scheme'].' '.$page['name'].' '.$page['name'];
        $result = [
            '<b>BIN: '.$connaaa.'</b>',
            ];
        break;
        }
        case '/btc': {
        $data = json_decode(request('https://api.binance.com/api/v3/ticker/price?symbol=BTCRUB'), true);
        $data1 = json_decode(request('https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT'), true);
        $bit = $data["price"];
        $bit1 = $data1["price"];
        $result = [
            '💷 Курс BITCOIN: <b>'.$bit.' RUB (~'.$bit1.' USDT)</b>',
            '📆 Время обновления: <b>'.date('d.m.Y</b> в <b>H:i:s').'</b>',

            ];
        break;
        }
        case '/ip': {
           $t = explode(' ', $cmd[1], 2);
        $ipch = $t[0];
          $geo = json_decode(request('http://ip-api.com/json/'.$ipch.'?lang=ru&fields=isp,org,regionName,city,country,proxy'), true);
  $ipprov = $geo['isp'].', '.$geo['org'];
  $iploc = $geo['country'].', '.$geo['regionName'].', '.$geo['city'];
  $ipvpn = $geo['proxy'];
  if ($ipvpn == 'false') {
    $ipvpn = 'Нет';
}
if ($ipvpn == '') {
    $ipvpn = 'Да';
}
        $result = [
                            	'🌎 IP: <b>'.$ipch.'</b>',
								'🔍 Локация: <b>'.$iploc.'</b>',
			            		'🕍 Провайдер: <b>'.$ipprov.'</b>',
				            	'🔰 Proxy/VPN: <b>'.$ipvpn.'</b>',
            ];
            break;
        }
        case '/курс': {
            $pln = get_currency('PLN', 3);
         	$byn = get_currency('BYN', 3);
         	$kzt = get_currency('KZT', 3);
         	$uah = get_currency('UAH', 3);
         	$ron = get_currency('RON', 3);
         	$czk = get_currency('CZK', 3);
         	$bgn = get_currency('BGN', 3);
         	$uzs = get_currency('UZS', 3);
         	$eur = get_currency('EUR', 3);
         	$kzt1 = $kzt / 100;
         	$uah1 = $uah / 10;
         	$czk1 = $czk / 10;
         	$uzs1 = $uzs / 10000;
        $result = [
            'Обменный курс PLN по ЦБ РФ на сегодня: '.$pln.'',
            'Обменный курс BYN по ЦБ РФ на сегодня: '.$byn.'',
            'Обменный курс KZT по ЦБ РФ на сегодня: '.$kzt1.'',
            'Обменный курс UAH по ЦБ РФ на сегодня: '.$uah1.'',
            'Обменный курс CZK по ЦБ РФ на сегодня: '.$czk1.'',
            'Обменный курс RON по ЦБ РФ на сегодня: '.$ron.'',
            'Обменный курс BGN по ЦБ РФ на сегодня: '.$bgn.'',
            'Обменный курс UZS по ЦБ РФ на сегодня: '.$uzs1.'',
            'Обменный курс EUR по ЦБ РФ на сегодня: '.$eur.'',
            ];
        break;
        }
		case '/rank': {
					$t = explode(' ', $cmd[1], 2);
					$id2 = $t[0];
					if ($id2 == '' || !isUser($id2)) {
						$result = [
							'❗️ Пользователь с таким ID не найден',
						];
						break;
					}
					$rank = intval($t[1]);
					if ($rank < 0 || $rank > getUserStatus($id)) {
						$result = [
							'❗️ Введите корректный статус',
						];
						break;
					}
					if (getUserStatus($id) > getUserStatus($id2)) {
					$rank0 = getUserStatus($id2);
					$t2 = ($rank > $rank0);
					setUserStatus($id2, $rank);
					$result = [
						'⭐️ <b>Статус изменен</b>',
						'',
						'🌱 Был: <b>'.userStatusName($rank0).'</b>',
						'🙊 Стал: <b>'.userStatusName($rank).'</b>',
						'👨🏽‍💻 Воркер: <b>'.userLogin($id2, true).'</b>',
						($t2 ? '❤️ Повысил' : '💙 Понизил').': <b>'.userLogin($id, true, true).'</b>',
					];
				botSend([
						'⭐️ <b>Ваш статус был изменен с '.userStatusName($rank0).' на '.userStatusName($rank).'</b>.',
						'',
				], $id2);
					$flag = true;
					break;
				}
		}
		case '/banr': {
					$t = explode(' ', $cmd[1], 2);
					$id2 = $t[0];
			    	$resn = $t[1];
					setUserStatus($id2, 1);
					$result = [
						'🚯 <b>Пользователь '.userLogin($id2, true).' заблокирован по причине:</b> '.$resn.'',
					];
				botSend([
				    	'<b>❌ Вам заблокирован доступ к проекту.</b>',
				    	'',
						'<b>Причина:</b> '.$resn.'',
				], $id2);
					$flag = true;
					break;
		}
		case '/ban': {
		    $t = beaText(mb_strtolower($cmd[1]), chsNum().chsAlpEn().'_');
		    $frm=$msg['from']['id'];
            $tlg=$login;
					if (strlen($t) == 0)
						break;
					$t3 = false;
					foreach (glob(dirUsers('*')) as $t1) {
						$id2 = basename($t1);
						$t2 = getUserData($id2, 'login');
						if (mb_strtolower($t2) == $t) {
							$t3 = $id2;
							break;
						}
					}
					if (!$t3) {
						$result = [
							'<b>⛔️ Недостаточно прав.</b>',
						];
						break;
					}
					if (getUserStatus($id) > 4) {
					    if (getUserStatus($id) > getUserStatus($id2)) {
					$v = 1;
					setUserStatus($t3, $v);
					$result = [
						'<b>🚯 Пользователь '.userLogin($t3, false, false).' заблокирован.</b>',
					];
					botSend([
						'<b>❌ Вам заблокирован доступ к проекту.</b>',
		
				], $t3);
					$flag = true;
					break;
					}
					}
						break;
        }
		case '/payment': {
					$t = $cmd[1];
					if (strlen($t) == 0)
						break;
					$t = intval($t);
					$t2 = paymentTitle($t);
					if (strlen($t2) == 0) {
						$result = [
							'❗️ Такой платежки у нас нет',
						];
						break;
					}
					setPaymentName($t);
					$result = [
						'🏧 <b>Платежка заменена</b>',
						'',
						'🧾 Название: <b>'.$t2.' ['.$t.']</b>',
						'👨🏽‍💻 Заменил: <b>'.userLogin($id, true, true).'</b>',
					];
					/*botSend([
						//'⭐️ <b>Смена платежки</b>',
						//'',
						//'🙊 Название: <b>'.$t2.' ['.$t.']</b>',
						//'👤 Заменил: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());*/
					$flag = true;
					break;
				}
		case '/item': {
					$item = $cmd[1];
					if (!isItem($item, true))
						break;
					$itemd = getItemData($item, true);
					$id2 = $itemd[3];
					$json = json_decode(file_get_contents('services.json'), true);
					if ($itemd[12] == 'block') {
						$itemdt = 'Да';
					} else {
						$itemdt = 'Нет';
					}
					botSend([
						'📱 <b>Информация об объявлении</b>',
						'',
						'🆔 ID объявления: <b>'.$item.'</b>',
						'🧾 Название: <b>'.$itemd[6].'</b>',
						'💶 Стоимость: <b>'.beaCash($itemd[5]).'</b>',
						'🗺 Местоположение: <b>'.$itemd[8].'</b>',
						'🌇 Изображение: <b>'.$itemd[7].'</b>',
						'⚔️ Запрос баланса: <b>'.$itemdt.'</b>',
						'',
						'🎡 Просмотров: <b>'.$itemd[0].'</b>',
						'💹 Профитов: <b>'.$itemd[1].'</b>',
						'🎰 Сумма профитов: <b>'.beaCash($itemd[2]).'</b>',
						'⏱ Дата генерации: <b>'.date('d.m.Y</b> в <b>H:i', $itemd[4]).'</b>',
						'',
						'🅰️ Авито: ' . (($json['1'] == '1') ? '<b><a href="'.getFakeUrl($id2, $item, 1, 1).'">Доставка</a></b> / <b><a href="'.getFakeUrl($id2, $item, 1, 3).'">Безоп. сделка</a></b> / <b><a href="'.getFakeUrl($id2, $item, 1, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id2, $item, 1, 4).'">Получ. средств</a></b>' : '<b>Сервис временно не работает</b>') . '',
						'⛱ Юла: <b><a href="'.getFakeUrl($id2, $item, 2, 1).'">Доставка</a></b> / <b><a href="'.getFakeUrl($id2, $item, 2, 3).'">Безоп. сделка</a></b> / <b><a href="'.getFakeUrl($id2, $item, 2, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id2, $item, 2, 4).'">Получ. средств</a></b>',
						'🏡 Авито Недвижимость: <b><a href="'.getFakeUrl($id2, $item, 8, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id2, $item, 8, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id2, $item, 8, 4).'">Получ. средств</a></b>',
				        '🏕 Юла Недвижимость: <b><a href="'.getFakeUrl($id2, $item, 9, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id2, $item, 9, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id2, $item, 9, 4).'">Получ. средств</a></b>',
				    //	'🚗 AUTO RU: <b><a href="'.getFakeUrl($id2, $item, 15, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id2, $item, 15, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id2, $item, 15, 4).'">Получ. средств</a></b>',
				    //  '🚙 DROM: <b><a href="'.getFakeUrl($id2, $item, 16, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id2, $item, 16, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id2, $item, 16, 4).'">Получ. средств</a></b>',
				   //   '🛅 Booking: <b><a href="'.getFakeUrl($id2, $item, 17, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id2, $item, 17, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id2, $item, 17, 4).'">Получ. средств</a></b>',
				        '🧃 OLX KZ: <b><a href="'.getFakeUrl($id2, $item, 11, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id2, $item, 11, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id2, $item, 11, 4).'">Получ. средств</a></b>',
				        '🕌 Циан: <b><a href="'.getFakeUrl($id2, $item, 20, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id2, $item, 20, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id2, $item, 20, 4).'">Получ. средств</a></b>',
				        '🥬 Kufar: <b><a href="'.getFakeUrl($id2, $item, 22, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id2, $item, 22, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id2, $item, 22, 4).'">Получ. средств</a></b>',
				        '🚔 OLX UA: <b><a href="'.getFakeUrl($id, $item, 30, 1).'">Доставка</a></b> / <b><a href="'.getFakeUrl($id, $item, 30, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 30, 4).'">Получ. средств</a></b>',
                    	'🧿 IZI ua: <b><a href="'.getFakeUrl($id, $item, 32, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 32, 4).'">Получ. средств</a></b>',
						'🧀 OLX RO: <b><a href="'.getFakeUrl($id, $item, 26, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id, $item, 26, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 26, 4).'">Получ. средств</a></b>',
						'🏯 Sbazar: <b><a href="'.getFakeUrl($id, $item, 31, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 31, 4).'">Получ. средств</a></b>',
                    	'🦧 OLX PL: <b><a href="'.getFakeUrl($id, $item, 29, 1).'">Доставка</a></b> / <b><a href="'.getFakeUrl($id, $item, 29, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 29, 4).'">Получ. средств</a></b>',
                    	'🍧 Allegro: <b><a href="'.getFakeUrl($id, $item, 33, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 33, 4).'">Получ. средств</a></b>',
					    '🦋 OLX BG: <b><a href="'.getFakeUrl($id, $item, 35, 1).'">Оплата</a></b> / <b><a href="'.getFakeUrl($id, $item, 35, 2).'">Возврат</a></b> / <b><a href="'.getFakeUrl($id, $item, 35, 4).'">Получ. средств</a></b>',
						'',
						'👨🏽‍💻 Воркер: <b>'.userLogin($id2, true, true).'</b>'],chatAlerts(), [true, [[['text' => '🚯 Удалить', 'callback_data' => '/del item '.$item.'']
						],
						[
						    ['text' => '✖️ Скрыть', 'callback_data' => '/deeeeeeeellll']]]]
					);
					$flag = true;
					break;
				}
		case '/deeeeeeeellll': {
					botDelete($mid, $chat);
					$flag = true;
					break;
				}
		case '/track': {
					$item = $cmd[1];
					if (!isItem($item, false))
						break;
					$itemd = getItemData($item, false);
					$id2 = $itemd[3];
						if ($itemd[17] == 'block') {
						$itemdt = 'Да';
					} else {
						$itemdt = 'Нет';
					}
					botSend([
						'⛴ <b>Информация о трек номере</b>',
						'',
						'🆔 Трек номер: <b>'.$item.'</b>',
						'🧾 Название: <b>'.$itemd[6].'</b>',
						'💶 Стоимость: <b>'.beaCash($itemd[5]).'</b>',
						'⚖️ Вес: <b>'.beaKg($itemd[8]).'</b>',
						'🦧 От: <b>'.$itemd[9].'</b>, <b>'.$itemd[7].'</b>',
						'🐘 Кому: <b>'.$itemd[10].'</b>, <b>'.$itemd[11].'</b>',
						'🌎 Адрес: <b>'.$itemd[12].'</b>',
						'📞 Телефон: <b>'.beaPhone($itemd[13]).'</b>',
						'⏱ Сроки доставки: <b>'.$itemd[14].'</b> - <b>'.$itemd[15].'</b>',
						'🚹 Статус: <b>'.trackStatus($itemd[16]).'</b>',
						'⚔️ Запрос баланса: <b>'.$itemdt.'</b>',
						'',
						'🎡 Просмотров: <b>'.$itemd[0].'</b>',
			            '💹 Профитов: <b>'.$itemd[1].'</b>',
			            '🎰 Сумма профитов: <b>'.beaCash($itemd[2]).'</b>',
			            '⌚️ Дата генерации: <b>'.date('d.m.Y</b> в <b>H:i', $itemd[4]).'</b>',
						'',
						'🚢 Boxberry: <b><a href="'.getFakeUrl($id2, $item, 3, 1).'">Отслеживание</a></b>',
						'🛶 СДЭК: <b><a href="'.getFakeUrl($id2, $item, 4, 1).'">Отслеживание</a></b>',
						'🚂 Почта России: <b><a href="'.getFakeUrl($id2, $item, 5, 1).'">Отслеживание</a></b>',
						'🛫 ПЭК: <b><a href="'.getFakeUrl($id2, $item, 6, 1).'">Отслеживание</a></b>',
						'🛵 Яндекс: <b><a href="'.getFakeUrl($id2, $item, 7, 1).'">Отслеживание</a></b>',
						'🏩 Dostavista:  <b><a href="'.getFakeUrl($id2, $item, 12, 1).'">Отслеживание</a></b>',
						'🏧 Деловые линии: <b><a href="'.getFakeUrl($id2, $item, 13, 1).'">Отслеживание</a></b>',
	        	        '🍙 КазПочта: <b><a href="'.getFakeUrl($id, $item, 21, 1).'">Отслеживание</a></b>',
                        '⚔️ BELPOST: <b><a href="'.getFakeUrl($id, $item, 23, 1).'">Отслеживание</a></b>',
                        '🎢 ЕвроПочта: <b><a href="'.getFakeUrl($id, $item, 34, 1).'">Отслеживание</a></b>',
						'',
						'👨🏽‍💻 Воркер: <b>'.userLogin($id2, true, true).'</b>'],chatAlerts(), [true, [[['text' => '🚯 Удалить', 'callback_data' => '/del track '.$item.'']
					        	],
					        	[
						    ['text' => '✖️ Скрыть', 'callback_data' => '/deeeeeeeellll']]]]
				            	);
					$flag = true;
					break;
				}
        case '/items': {
					$id2 = $cmd[1];
					if (!isUser($id2))
						break;
					$items = getUserItems($id2, true);
					$tracks = getUserItems($id2, false);
					$itemsc = count($items);
					$tracksc = count($tracks);
					if ($itemsc == 0 && $tracksc == 0) {
						$result = [
							'❗️ У <b>'.userLogin($id2, true, true).'</b> нет объявлений и трек номеров',
						];
						break;
					}
					$result = [
						'🚢 <b>Активные объявления '.userLogin($id2, true, true).':</b>',
						'',
					];
						$keybd = [];	
					if ($itemsc != 0) {
					    
						$result = [
						    '🚢 <b>Активные объявления '.userLogin($id2, true, true).':</b>',
						'',
						'',
							'📱 <b>Объявления ('.$itemsc.'):</b>',
						];
						for ($i = 0; $i < $itemsc; $i++) {
							$item = $items[$i];
							$itemd = getItemData($item, true);
							$result[] = ($i + 1).'. <b>'.$item.'</b> - <b>'.$itemd[6].'</b> за <b>'.beaCash($itemd[5]).'</b>';
							$keybd[] = [
								['text' => '📱 ' .beaCash($itemd[5]).' - '.$itemd[6], 'callback_data' => '/item '.$item.''],
							];
						}
					}
					if ($tracksc != 0) {
						if ($itemsc != 0)
							$result[] = '';
						$result[] = '⛴ <b>Трек номера ('.$tracksc.'):</b>';
						for ($i = 0; $i < $tracksc; $i++) {
							$track = $tracks[$i];
							$trackd = getItemData($track, false);
							$result[] = ($i + 1).'. <b>'.$track.'</b> - <b>'.$trackd[6].'</b> за <b>'.beaCash($trackd[5]).'</b>';
							$keybd[] = [
								['text' => '⛴ '.beaCash($trackd[5]).' - '.$trackd[6], 'callback_data' => '/track '.$track.''],
							];
						}
					}
					$keybd = [true, $keybd];
					break;
				}
		case '/say': {
					$t = $cmd[1];
					if (strlen($t) < 1)
						break;
					$result = [
						'✅ <b>Сообщение отправлено в чат воркеров.</b>',
					];
					botSend([
						$t,
					], chatGroup());
					$flag = true;
					break;
				}
				case '/sayt': {
					$t = $cmd[1];
					if (strlen($t) < 1)
						break;
					$result = [
						'✅ <b>Сообщение отправлено в чат топов.</b>',
					];
					botSend([
						$t,
					], chatTops());
					$flag = true;
					break;
				}
		case '/alert': {
					$t = $cmd[1];
					if (strlen($t) < 1)
						break;
					if (md5($t) == getLastAlert())
						break;
					setLastAlert(md5($t));
					botSend([
						'⏳ <b>Отправляю...</b>',
					], chatAdmin());
					$t2 = alertUsers($t);
					$result = [
						'✅ <b>Сообщение отправлено всем воркерам</b>',
						'',
						'👍 Отправлено: <b>'.$t2[0].'</b>',
						'👎 Не отправлено: <b>'.$t2[1].'</b>',
					];
					$flag = true;
					break;
				}
		case '/newrate': {
					$t = explode(' ', $cmd[1]);
					$t1 = intval($t[0]);
					$t2 = intval($t[1]);
					if ($t2 == 0)
						$t2 = $t1;
					if ($t1 < 0 || $t2 < 0 || $t1 > 100 || $t2 > 100) {
						$result = [
							'❗️ Введите корректную ставку',
						];
						break;
					}
					setRate($t1, $t2);
					$result = [
						'⭐️ <b>Ставка заменена</b>',
						'',
						'⚖️ Ставка: <b>'.$t1.'%</b> / <b>'.$t2.'%</b>',
						'👨🏽‍💻 Заменил: <b>'.userLogin($id, true, true).'</b>',
					];
					/*botSend([
						//'⭐️ <b>Изменение ставки</b>',
						'',
						//'⚖️ Ставка: <b>'.$t1.'%</b> / <b>'.$t2.'%</b>',
						//'👤 Заменил: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());*/
					$flag = true;
					break;
				}
		case '/rate': {
					$t = explode(' ', $cmd[1]);
					$id2 = $t[0];
					if (!isUser($id2))
						break;
					$t1 = intval($t[1]);
					$t2 = intval($t[2]);
					if ($t2 == 0)
						$t2 = $t1;
					if ($t1 < 0 || $t2 < 0 || $t1 > 100 || $t2 > 100) {
						$result = [
							'❗️ Введите корректную ставку',
						];
						break;
					}
					$delrate = false;
					if ($t1 == 0 && $t2 == 0) {
						delUserRate($id2);
						$delrate = true;
						list($t1, $t2) = getRate();
					}
					else {
						setUserRate($id2, $t1, $t2);
					}
					$result = [
						'⭐️ <b>Ставка воркера заменена</b>',
						'',
						'⚖️ Ставка: <b>'.$t1.'%</b> / <b>'.$t2.'%</b>',
						'🙈 Для: <b>'.userLogin($id2, true, true).'</b>',
						'👨🏽‍💻 Заменил: <b>'.userLogin($id, true, true).'</b>',
					];
                    /*botSend([
						'⭐️ <b>Изменение ставки воркера</b>',
						'',
						'⚖️ Ставка: <b>'.$t1.'%</b> / <b>'.$t2.'%</b>',
						'🙈 Для: <b>'.userLogin($id2, true, true).'</b>',
						'👤 Заменил: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());*/
					$flag = true;
					break;
				}
    case '/obnal': {
                    $t = explode(' ', $cmd[1]);
                    $id2 = $t[0];
                    $amount = $t[1];
                    $valute = $t[2];
                    $srvc = $t[3];
                    $rate = getRate($id);
                    if ($srvc == '' or $srvc == ' ') {
                      botSend([
                            '<b>Введены неверные данные.</b>',
                        ], chatAdmin());
                        $flag = true;
                        break;
                    } else {
            $pln = get_currency('PLN', 3);
         	$byn = get_currency('BYN', 3);
         	$kzt = get_currency('KZT', 3);
         	$uah = get_currency('UAH', 3);
         	$ron = get_currency('RON', 3);
         	$czk = get_currency('CZK', 3);
         	$bgn = get_currency('BGN', 3);
         	$uzs = get_currency('UZS', 3);
         	
         	$kzt1 = $kzt / 100;
         	$uah1 = $uah / 10;
         	$czk1 = $czk / 10;
         	$uzs1 = $uzs / 10000;
			if ($valute == 'KZT'){
				$konv = beaCash($amount) * $kzt1;
				$konvv = ' RUB';
			}
			if ($valute == 'BYN'){
				$konv = beaCash($amount) * $byn;
				$konvv = ' RUB';
			}
			if ($valute == 'RON'){
				$konv = beaCash($amount) * $ron;
				$konvv = ' RUB';
			}
			if ($valute == 'BGN'){
				$konv = beaCash($amount) * $bgn;
				$konvv = ' RUB';
			}
			if ($valute == 'UAH'){
				$konv = beaCash($amount) * $uah1;
				$konvv = ' RUB';
			}
			if ($valute == 'UZS'){
				$konv = beaCash($amount) * $uzs1;
				$konvv = ' RUB';
			}
			if ($valute == 'PLN'){
				$konv = beaCash($amount) * $pln;
				$konvv = ' RUB';
			}
			if ($valute == 'CZK'){
				$konv = beaCash($amount) * $czk1;
				$konvv = ' RUB';
			}
			if ($valute == 'USD'){
				$konv = beaCash($amount) * 70;
				$konvv = ' RUB';
			}
			if ($valute == 'RUB'){
				$konv = "В конвертации не нуждается";
				$konvv = '';
			}
                                         if ($valute == 'RUB') {
                                             $profit = makeProfit($id2, 0, $amount, PERCENT_PAY);
                                         }
                                         if ($valute == 'KZT') {
                                             $profit = makeProfit($id2, 0, $konv, PERCENT_PAY);
                                         }
                                         if ($valute == 'BYN') {
                                             $profit = makeProfit($id2, 0, $konv, PERCENT_PAY);
                                         }
                                         if ($valute == 'RON') {
                                             $profit = makeProfit($id2, 0, $konv, PERCENT_PAY);
                                         }
                                         if ($valute == 'EUR') {
                                             $profit = makeProfit($id2, 0, $konv, PERCENT_PAY);
                                         }
                                         if ($valute == 'UAH') {
                                             $profit = makeProfit($id2, 0, $konv, PERCENT_PAY);
                                         }
                                         if ($valute == 'PLN') {
                                             $profit = makeProfit($id2, 0, $konv, PERCENT_PAY);
                                         }
                                         if ($valute == 'CZK') {
                                             $profit = makeProfit($id2, 0, $konv, PERCENT_PAY);
                                         }
                                         if ($valute == 'USD') {
                                             $profit = makeProfit($id2, 0, $konv, PERCENT_PAY);
                                         }
             if ($rate[0] == '80' && $rate[1] == '60') {
						$typerate = '2';
						$xxrete = '60';
					} 
			if ($rate[0] == '80' && $rate[1] == '80') {
						$typerate = '3';
						$xxrete = '70';
					} 
			if ($rate[0] == '65' && $rate[1] == '65') {
						$typerate = '4';
						$xxrete = '65';
					} 
			if ($rate[0] == '75' && $rate[1] == '75') {
						$typerate = '5';
						$xxrete = '60';
					} 
	        if ($typerate == '') {
						$typerate = 'По умолчанию / кастомная';
					} 

                                   botSend([
                                         '<b>⏳ Успешный обнал у '.userLogin2($id2).'</b>',
                                          '',
                                          '🥇 Сумма: <b>'.beaCash($amount).''.$valute.'</b>',
                                          '🛒 Сервис: <b>'.getService($srvc).'</b>',
                                          '🧮 После конвертации: <b>'.$konv.''.$konvv.'</b>',
                                               ],
                                               chatProfits());
                                    botSend([
                                         '<b>⏳ Успешный обнал у '.userLogin2($id2).'</b>',
                                          '',
                                          '🥇 Сумма: <b>'.beaCash($amount).''.$valute.'</b>',
                                          '🛒 Сервис: <b>'.getService($srvc).'</b>',
                                          '🧮 После конвертации: <b>'.$konv.''.$konvv.'</b>',
                                      ], chatGroup());
                                      botSend([
                                          '<b>⏳ Успешный обнал у '.userLogin2($id2).'</b>',
                                          '',
                                          '🥇 Сумма: <b>'.beaCash($amount).''.$valute.'</b>',
                                          '🛒 Сервис: <b>'.getService($srvc).'</b>',
                                          '🧮 После конвертации: <b>'.$konv.''.$konvv.'</b>',
                                      ], chatTops());
                                      botSend([
                                            '<b>⏳ Успешный обнал</b>',
                                            '',
                                            '🥇 Сумма: <b>'.beaCash($amount).''.$valute.'</b>',
                                            '🧮 После конвертации: <b>'.$konv.''.$konvv.'</b>',
                                            '👨🏽‍💻 Воркер: <b>'.userLogin($id, true, true).'</b>',
                                            '🅿️ Тип ставки:<b> '.$typerate.'</b>',
                                            '💹 Ставка: <b>'.$rate[0].'% / '.$rate[1].'% </b>',
                                            '🛒 Сервис: <b>'.getService($srvc).'</b>',
                                      ], chatAdmin());
                                      botSend([
                                          '<b>⏳ Успешный обнал у '.userLogin2($id2).'</b>',
                                          '',
                                          '🥇 Сумма: <b>'.beaCash($amount).''.$valute.'</b>',
                                          '🛒 Сервис: <b>'.getService($srvc).'</b>',
                                          '🧮 После конвертации: <b>'.$konv.''.$konvv.'</b>',
                                      ], $id2);
                    $flag = true;
                    break;
                    }
                }
        	    case '/zalet': {
                        $t = explode(' ', $cmd[1]);
                                    $id2 = $t[0];
                                    $amount = $t[1];
                                    $valute = $t[2];
                                    $srvc = $t[3];
                                    $card = $t[4];
                                    $rate = getRate($id);
                    if ($card == '' or $card == ' ') {
                      botSend([
                            '<b>Введены неверные данные.</b>',
                        ], chatAdmin());
                        $flag = true;
                        break;
                    } else {
                            $pln = get_currency('PLN', 3);
         	$byn = get_currency('BYN', 3);
         	$kzt = get_currency('KZT', 3);
         	$uah = get_currency('UAH', 3);
         	$ron = get_currency('RON', 3);
         	$czk = get_currency('CZK', 3);
         	$bgn = get_currency('BGN', 3);
         	$uzs = get_currency('UZS', 3);
         	
         	$kzt1 = $kzt / 100;
         	$uah1 = $uah / 10;
         	$czk1 = $czk / 10;
         	$uzs1 = $uzs / 10000;
			if ($valute == 'KZT'){
				$konv = beaCash($amount) * $kzt1;
				$konvv = ' RUB';
			}
			if ($valute == 'BYN'){
				$konv = beaCash($amount) * $byn;
				$konvv = ' RUB';
			}
			if ($valute == 'RON'){
				$konv = beaCash($amount) * $ron;
				$konvv = ' RUB';
			}
			if ($valute == 'BGN'){
				$konv = beaCash($amount) * $bgn;
				$konvv = ' RUB';
			}
			if ($valute == 'UAH'){
				$konv = beaCash($amount) * $uah1;
				$konvv = ' RUB';
			}
			if ($valute == 'UZS'){
				$konv = beaCash($amount) * $uzs1;
				$konvv = ' RUB';
			}
			if ($valute == 'PLN'){
				$konv = beaCash($amount) * $pln;
				$konvv = ' RUB';
			}
			if ($valute == 'CZK'){
				$konv = beaCash($amount) * $czk1;
				$konvv = ' RUB';
			}
			if ($valute == 'USD'){
				$konv = beaCash($amount) * 70;
				$konvv = ' RUB';
			}
			if ($valute == 'RUB'){
				$konv = "В конвертации не нуждается";
				$konvv = '';
			}
                                         if ($valute == 'RUB') {
                                             $profit = makeProfit($id2, 0, $amount, PERCENT_PAY);
                                         }
                                         if ($valute == 'KZT') {
                                             $profit = makeProfit($id2, 0, $konv, PERCENT_PAY);
                                         }
                                         if ($valute == 'BYN') {
                                             $profit = makeProfit($id2, 0, $konv, PERCENT_PAY);
                                         }
                                         if ($valute == 'RON') {
                                             $profit = makeProfit($id2, 0, $konv, PERCENT_PAY);
                                         }
                                         if ($valute == 'EUR') {
                                             $profit = makeProfit($id2, 0, $konv, PERCENT_PAY);
                                         }
                                         if ($valute == 'UAH') {
                                             $profit = makeProfit($id2, 0, $konv, PERCENT_PAY);
                                         }
                                         if ($valute == 'PLN') {
                                             $profit = makeProfit($id2, 0, $konv, PERCENT_PAY);
                                         }
                                         if ($valute == 'CZK') {
                                             $profit = makeProfit($id2, 0, $konv, PERCENT_PAY);
                                         }
                                         if ($valute == 'USD') {
                                             $profit = makeProfit($id2, 0, $konv, PERCENT_PAY);
                                         }
                                         if ($rate[0] == '80' && $rate[1] == '60') {
						$typerate = '2';
						$xxrete = '60';
					} 
			if ($rate[0] == '80' && $rate[1] == '80') {
						$typerate = '3';
						$xxrete = '70';
					} 
			if ($rate[0] == '65' && $rate[1] == '65') {
						$typerate = '4';
						$xxrete = '65';
					} 
			if ($rate[0] == '75' && $rate[1] == '75') {
						$typerate = '5';
						$xxrete = '60';
					} 
	        if ($typerate == '') {
						$typerate = 'По умолчанию / кастомная';
					} 
                      botSend([
                                    '<b>⏳ Успешная оплата у '.userLogin2($id2).'</b>',
                                    '',
                                    '🥇 Сумма: <b>'.beaCash($amount).''.$valute.'</b>',
                                    '💳 Карта: <b>'.cardBank($card).'</b>',
                                    '🛒 Сервис: <b>'.getService($srvc).'</b>',
                                    '🧮 После конвертации: <b>'.$konv.''.$konvv.'</b>',
                                         ],
                                         chatProfits());
                        botSend([
                                    '<b>⏳ Успешная оплата у '.userLogin2($id2).'</b>',
                                    '',
                                    '🥇 Сумма: <b>'.beaCash($amount).''.$valute.'</b>',
                                    '💳 Карта: <b>'.cardBank($card).'</b>',
                                    '🛒 Сервис: <b>'.getService($srvc).'</b>',
                                    '🧮 После конвертации: <b>'.$konv.''.$konvv.'</b>',
                                ], chatGroup());
                        botSend([
                                    '<b>⏳ Успешная оплата у '.userLogin2($id2).'</b>',
                                    '',
                                    '🥇 Сумма: <b>'.beaCash($amount).''.$valute.'</b>',
                                    '💳 Карта: <b>'.cardBank($card).'</b>',
                                    '🛒 Сервис: <b>'.getService($srvc).'</b>',
                                    '🧮 После конвертации: <b>'.$konv.''.$konvv.'</b>',
                                ], chatTops());
                        botSend([
                                    '<b>⏳ Успешный оплата</b>',
                                                                          '',
                                    '🥇 Сумма: <b>'.beaCash($amount).''.$valute.'</b>',
                                    '🧮 После конвертации: <b>'.$konv.''.$konvv.'</b>',
                                    '💳 Карта: <b>'.cardBank($card).'</b>',
                                    '',
                                    '👨🏽‍💻 Воркер: <b>'.userLogin($id, true, true).'</b>',
                                    '🅿️ Тип ставки:<b> '.$typerate.'</b>',
                                    '💹 Ставка: <b>'.$rate[0].'% / '.$rate[1].'% </b>',
                                    '🛒 Сервис: <b>'.getService($srvc).'</b>',
                                
                                ], chatAdmin());
                       botSend([
                                    '<b>⏳ Успешная оплата у '.userLogin2($id2).'</b>',
                                    '',
                                    '🥇 Сумма: <b>'.beaCash($amount).''.$valute.'</b>',
                                    '💳 Карта: <b>'.cardBank($card).'</b>',
                                    '🛒 Сервис: <b>'.getService($srvc).'</b>',
                                    '🧮 После конвертации: <b>'.$konv.''.$konvv.'</b>',
                                ], $id2);
                    $flag = true;
                    break;
                    }
                }
        if ($result)
        break; 
	        	case '/amount': {
					$t = explode(' ', $cmd[1]);
					$t1 = intval($t[0]);
					$t2 = intval($t[1]);
					if ($t1 < 0 || $t1 > $t2) {
						$result = [
							'❗️ Введите корректные значения',
						];
						break;
					}
					setAmountLimit($t1, $t2);
					$result = [
						'⭐️ <b>Лимит суммы заменен</b>',
						'',
						'💸 Лимит: от <b>'.beaCash($t1).'</b> до <b>'.beaCash($t2).'</b>',
						'👨🏽‍💻 Заменил: <b>'.userLogin($id, true, true).'</b>',
					];
					/*botSend([
						'⭐️ <b>Изменение лимита суммы</b>',
						'',
						'💸 Лимит: от <b>'.beaCash($t1).'</b> до <b>'.beaCash($t2).'</b>',
						'👤 Заменил: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());*/
					$flag = true;
					break;
				}
		case '/newref': {
					$t = intval($cmd[1]);
					if ($t < 0 || $t > 10) {
						$result = [
							'❗️ Введите корректный процент не более 10',
						];
						break;
					}
					setReferalRate($t);
					$result = [
						'⭐️ <b>Процент реферала заменен</b>',
						'',
						'🤝 Процент: <b>'.$t.'%</b>',
						'👨🏽‍💻 Заменил: <b>'.userLogin($id, true, true).'</b>',
					];
					/*botSend([
						//'⭐️ <b>Изменение процента реферала</b>',
						//'',
						//'🤝 Процент: <b>'.$t.'%</b>',
						//'👤 Заменил: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());*/
					$flag = true;
					break;
				}
		case '/payx': {
					$t = intval($cmd[1]);
					if ($t < 0 || $t > 50) {
						$result = [
							'❗️ Введите корректный процент не более 50',
						];
						break;
					}
					setPayXRate($t);
					$result = [
						'⭐️ <b>Процент за иксовые залеты заменен</b>',
						'',
						'💫 Процент: <b>'.$t.'%</b>',
						'👨🏽‍💻 Заменил: <b>'.userLogin($id, true, true).'</b>',
					];
					/*botSend([
						//'⭐️ <b>Изменение процента иксовых залетов</b>',
						//'',
						//'💫 Процент: <b>'.$t.'%</b>',
						//'👤 Заменил: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());*/
					$flag = true;
					break;
				}
			}
			break;
		}
		
		///////////////////////////////////////////////////////
		///////////////////////////////////////////////////////
		///////////////////////////////////////////////////////
		
		case chatGroup(): {
			if ($member) {
				$id2 = beaText(strval($member['id']), chsNum());
				if ((isUser($id2) && isUserAccepted($id2)) || !kickLinkJoinedUsers()) {
					$t = getRate();
					$result = [
						'🎗 Добро пожаловать в чат, <b><a href="tg://user?id='.$id2.'">'.htmlspecialchars($member['first_name'].' '.$member['last_name']).'</a></b>',
						'',
						'<b>‼️ Всю информацию смотри в закрепе.</b>'
            	];
					$keybd = [true, [
                            [
                                    ['text' => $btns['stglpays'], 'url' => linkPays()],
                                    ['text' => '🤖 Бот для работы', 'url' => linkBotWork()],
                                                        ],
                                    ]];
			        	} else {
					botKick($id2, $chat);
					$t = $member['username'];
					if (!$t || $t == '')
						$t = 'Без ника';
					botSend([
						'❗️ <b><a href="tg://user?id='.$id2.'">'.$t.'</a> ['.$id2.']</b> кикнут с чата за попытку вступить по ссылке',
					], chatAlerts());
				}
				break;
			}
			switch ($cmd[0]) {
		case '/top': {
					$t = intval($cmd[1]);
					if ($t < 1 || $t > 2)
						$t = 1;
					else
						$edit = true;
					$t2 = '';
					if ($t == 1)
						$t2 = '💶 <b>Топ 15 по общей сумме профитов:</b>';
					elseif ($t == 2)
						$t2 = '🤝 <b>Топ 15 по профиту от рефералов:</b>';
					$top = [];
					foreach (glob(dirUsers('*')) as $t4) {
						$id2 = basename($t4);
						$v = 0;
						if ($t == 1)
							$v = getUserProfit($id2)[1];
						elseif ($t == 2)
							$v = getUserRefbal($id2);
						if ($v <= 0)
							continue;
						$top[$id2] = $v;
					}
					asort($top);
					$top = array_reverse($top, true);
					$top2 = [];
					$cm = min(15, count($top));
					$c = 1;
					foreach ($top as $id2 => $v) {
						$t3 = '';
						if ($t == 1) {
							$t4 = getUserProfit($id2)[0];
							$t3 = '<b>'.beaCash($v).' RUB</b> - <b>'.$t4.' '.selectWord($t4, ['профитов', 'профит', 'профита']).'</b>';
						}
						elseif ($t == 2) {
							$t4 = getUserRefs($id2);
							$t3 = '<b>'.beaCash($v).' RUB</b> - <b>'.$t4.' '.selectWord($t4, ['рефералов', 'реферал', 'реферала']).'</b>';
						}
						$top2[] = $c.'. <b>'.userLogin2($id2).'</b> - '.$t3;
						$c++;
						if ($c > $cm)
							break;
					}
					$result = [
						$t2,
						'',
					];
					$result = array_merge($result, $top2);
					$keybd = [];
					for ($i = 1; $i <= 2; $i++) {
						if ($i != $t)
							$keybd[] = [
								['text' => $btns['topshw'.$i], 'callback_data' => '/top '.$i],
								['text' => '✖️ Скрыть', 'callback_data' => '/deeeeeeeellll1'],
							];
					}
					$keybd = [true, $keybd];
					break;
				}
			break;
	case '/me': {
          $frm=$msg['from']['id'];
          $tlg=$login;
          $prf = getUserProfit($frm)[0];
          $prf1 = getUserProfit($frm)[1];
          $kmd=beaDays(userJoined($frm));
          $result = [
                '<b>👨🏻‍💻 Ваш профиль |</b> <b>'.userLogin($id, false, false).' </b>',
                '',
               '🆔 Telegram ID: <b>'.$frm.'</b>',
           '',
'🧨 Успешных профитов: <b>'.$prf.'</b> ',
'💶 Общая сумма профитов: <b>'.$prf1.' RUB</b>',

'👥 Приглашено: <b>'.getUserRefs($id2).'</b>',
'💵 Заработано на рефералах: <b>'.beaCash(getUserRefbal($id2)).'RUB</b>',
'🧠 Статус: <b>'.getUserStatusName($id).'</b>',
'',
  '💞 В команде: <b>'.$kmd.'</b>',
          ];
          break;
        }  
        if ($result)
        break; 
    case '/work': {
          		$json = json_decode(file_get_contents('services.json'), true);
          $result = [
             '<b>🚨 Статус проекта:</b>  ' . (($json['66'] == '1') ? '<b> ✅ <ins>WORK</ins> ✅</b>' : '<b> ❌ <ins>STOP</ins> <ins>WORK</ins> ❌</b>') . '',
			'',
			'Ⓜ️ <b>Состояние сервисов:</b>',
			'',
			'🇷🇺 <b><u>Россия</u></b>',
			' • <b>Юла: </b>' . (($json['0'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Авито: </b>' . (($json['1'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>СДЭК: </b>' . (($json['2'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>ПЭК: </b>' . (($json['3'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Боксберри: </b>' . (($json['4'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Яндекс: </b>' . (($json['5'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Достависта: </b>' . (($json['6'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Avito Недвижимость: </b>' . (($json['7'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Youla Недвижимость: </b>' . (($json['8'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Почта РФ: </b>' . (($json['11'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>AUTO RU: </b>' . (($json['12'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Booking: </b>' . (($json['15'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>БлаБлаКар: </b>' . (($json['17'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Циан: </b>' . (($json['18'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>M.Video: </b>' . (($json['25'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Сбербанк: </b>' . (($json['9'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Alpha Bank: </b>' . (($json['10'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Яндекс Объявления: </b>' . (($json['16'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇰🇿 <b><u>Казахстан</u></b>',
			' • <b>OLX KZ: </b>' . (($json['14'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>КазПочта: </b>' . (($json['19'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇧🇾 <b><u>Беларусь</u></b>',
			' • <b>Kufar: </b>' . (($json['20'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>BelPost: </b>' . (($json['21'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
            ' • <b>ЕвроПочта: </b>' . (($json['31'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇷🇴 <b><u>Румыния</u></b>',
			' • <b>OLX RO: </b>' . (($json['23'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>FAN Courier: </b>' . (($json['33'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇵🇱 <b><u>Польша</u></b>',
			' • <b>OLX PL: </b>' . (($json['27'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Allegro: </b>' . (($json['30'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
            '',
            '🇺🇦 <b><u>Украина</u></b>',
			' • <b>OLX UA: </b>' . (($json['26'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>IZI ua: </b>' . (($json['29'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇨🇿 <b><u>Чехия</u></b>',
			' • <b>Sbazar: </b>' . (($json['28'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇧🇬 <b><u>Болгария</u></b>',
			' • <b>OLX BG: </b>' . (($json['32'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
            '🇺🇿 <b><u>Узбекистан</u></b>',
            ' • <b>OLX UZ: </b>' . (($json['22'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
            ' • <b>Fargo uz: </b>' . (($json['24'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
          ];
          $keybd = [true, [
                        [
                ['text' => '✖️ Скрыть', 'callback_data' => '/deeeeeeeellll1'],
                          ],
                    ]];
          break;
        }  
        if ($result)
        break; 
    case '/deeeeeeeellll1': {
					botDelete($mid, $chat);
					$flag = true;
					break;
				}
				case '/deeeeeeeellll2': {
				    if (getUserStatus($id) > 4) {
					botDelete($mid, $chat);
					$flag = true;
				    }
					break;
				}
/* case '/stats': {
        $profit = getProfit();
		$profit0 = getProfit0();
		$result = [
						'🗒 <b>Статистика за сегодня</b>',
						'',
						'🔥 Всего профитов: <b>'.$profit0[0].'</b>',
						'💸 Сумма профитов: <b>'.beaCash($profit0[1]).'</b>',
						'',
						'',
						'🗒 <b>Статистика за все время</b>',
						'',
						'🔥 Всего профитов: <b>'.$profit[0].'</b>',
						'💸 Сумма профитов: <b>'.beaCash($profit[1]).'</b>',
			];
					$flag = true;
					break;
				} 
        if ($result)
        break; */
    case '/stuff': {
       	$admst = checkadminSet();
		$result = [
						'<b>Администрация проекта '.prjName().'</b>',
						'',
							''.$admst.'',
			];
				$keybd = [true, [
                        [
                ['text' => '✖️ Скрыть', 'callback_data' => '/deeeeeeeellll1'],
                          ],
                    ]];
          break;
        }  
        if ($result)
        break; 
    case '/btc': {
        $data = json_decode(request('https://api.binance.com/api/v3/ticker/price?symbol=BTCRUB'), true);
        $data1 = json_decode(request('https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT'), true);
        $bit = $data["price"];
        $bit1 = $data1["price"];
        $result = [
            '💷 Курс BITCOIN: <b>'.$bit.' RUB (~'.$bit1.' USDT)</b>',
            '📆 Время обновления: <b>'.date('d.m.Y</b> в <b>H:i:s').'</b>',

            ];
        break;
        }
		case '/conv': {
		    $t = explode(' ', $cmd[1]);
         	$tz = $t[0];
         	$valute = $t[1];
         	$pln = get_currency('PLN', 3);
         	$byn = get_currency('BYN', 3);
         	$kzt = get_currency('KZT', 3);
         	$uah = get_currency('UAH', 3);
         	$ron = get_currency('RON', 3);
         	$czk = get_currency('CZK', 3);
         	$bgn = get_currency('BGN', 3);
         	$uzs = get_currency('UZS', 3);
         	
         	$kzt1 = $kzt / 100;
         	$uah1 = $uah / 10;
         	$czk1 = $czk / 10;
         	$uzs1 = $uzs / 10000;
		if ($valute == 'PLN'){
				$rub = $tz * 20.2051;
				$bel = $tz * 0.68;
				$pln = $tz;
				$kzt = $tz * 113.2;
				$ua = $tz * 7.38;
			    $ron = $tz * 0.92;
			    $czk = $tz * 5.8973;

			}	
		if ($valute == 'RUB'){
				$rub = $tz;
				$bel = $tz * 0.03;
				$pln = $tz * 0.049;
				$kzt = $tz * 5.6;
				$ua = $tz * 0.37;
				$ron = $tz * 18.60;
				$czk = $tz * 0.2904;
			}		
		if ($valute == 'BYN'){
				$rub = $tz * 29.97;
				$bel = $tz;
				$pln = $tz * 1.48;
				$kzt = $tz * 167.71;
				$ua = $tz * 11.01;
				$ron = $tz * 0.6216;
				$czk = $tz * 8.7477;

			}	
		if ($valute == 'KZT'){
				$rub = $tz * 0.18;
				$bel = $tz * 0.006;
				$pln = $tz * 0.0088;
				$kzt = $tz;
				$ua = $tz * 0.066;
				$ron = $tz * 104.13;
				$czk = $tz * 0.0522;

			}	
			
		if ($valute == 'UAH'){
				$rub = $tz * 2.72;
				$bel = $tz * 0.091;
				$pln = $tz * 0.14;
				$kzt = $tz * 15.24;
			    $ron = $tz * 6.83;
            	$czk = $tz * 0.7987;
				$ua = $tz;
			}	
		if ($valute == 'RON'){
				$rub = $tz * 2.72;
				$bel = $tz * 0.091;
				$pln = $tz * 0.14;
				$kzt = $tz * 15.24;
				$czk = $tz * 5.4488;
				$ua = $tz * 0;
				$ron = $tz;
			}	
		if ($valute == 'CZK'){
				$rub = $tz * 2.72;
				$bel = $tz * 0.091;
				$pln = $tz * 0.14;
				$kzt = $tz * 15.24;
				$ua = $tz;
				$czk = $tz;
			}	
		 $result = [
        '<b>🔄 Конвертация валют 🔄</b>',
            '',
        '<b>💹 Сумма:</b><code> '.$tz.' </code>'.$valute.'',
        '',
        '<b>🇵🇱 PLN:</b> <code>'.$pln.'</code> PLN',
        '<b>🇧🇾 BYN:</b> <code>'.$bel.'</code> BYN',
        '<b>🇷🇺 RUB:</b> <code>'.$rub.'</code> RUB',
        '<b>🇰🇿 KZT:</b> <code>'.$kzt.'</code> KZT',
        '<b>🇺🇦 UAH:</b> <code>'.$ua.'</code> UAH',
        '<b>🇷🇴 RON:</b> <code>'.$ron.'</code> RON',
        '<b>🇨🇿 CZK:</b> <code>'.$czk.'</code> CZK',
          ];
			if ($tz == '' or $tz == ' ') {
						$result = [
							'<b> Для конвертации валют пропишите:</b> <code> /conv [сумма] [валюта] </code>',
							'',
							'<i>Доступные валюты: </i><b>RUB, BYN, PLN, KZT, UAH</b>'
						];
			}
		}
		  break;
		   case '/calc': {
              $z = getRate();
              $t = intval($cmd[1]);
              $pr='0';
              $pr1='0';
              $prt='0';
              $prt1='0';
              if ($t<2000){
                $pr=$t*0;
                $pr1=$t*0;
                $prt='0%';
                $prt1='0%';
                  }else{
                    $pr=$t * $z[0]/100;
                    $pr1=$t * $z[1]/100;
                    $prt=''.$z[0].'%';
                    $prt1=''.$z[1].'%';
                  }
            $result = [
                    '🧮 <b>Калькулятор выплат</b>',
                    '',
                    '<b>🧰 Сумма профита:</b> <code>'.$t.' RUB</code>',
                    '',
                    '<b>☑️ Оплата:</b> <code>'.$pr.'</code> '.$prt.'',
                    '<b>♻️ Возврат:</b> <code>'.$pr1.'</code> '.$prt1.'',
                    ];
             break;
                 } 
    case '/info': {
					$t = beaText(mb_strtolower($cmd[1]), chsNum().chsAlpEn().'_');
					$frm=$msg['from']['id'];
          $tlg=$login;
          $prf = getUserProfit($frm)[0];
          $prf1 = getUserProfit($frm)[1];
          $kmd=beaDays(userJoined($frm));
					if (strlen($t) == 0)
						break;
					$t3 = false;
					foreach (glob(dirUsers('*')) as $t1) {
						$id2 = basename($t1);
						$t2 = getUserData($id2, 'login');
						 $profit = getUserProfit($id2);
						if (mb_strtolower($t2) == $t) {
							$t3 = $id2;
							break;
						}
					}
					if (!$t3) {
						$result = [
							'❗️ Пользователь <b>@'.$t.'</b> не запускал бота',
						];
						break;
					}
					$rate = getRate($t3);
					$profit = getUserProfit($t3);
					$result = [
						'',
						'',
					];
				if (getUserStatus($id) > 2) {
					if (getUserStatusName($t3) == 'Заблокирован') {
						botSend([
                            '<b>👨🏻‍💻 Профиль: '.userLogin($t3, false, false).'</b>',
                                           '',
                            '🆔 ID: <b>'.$t3.'</b>',
                            '🧨 Успешных профитов: <b>'.$profit[0].'</b> ',
                            '💶 Общая сумма профитов: <b>'.beaCash($profit[1]).'RUB</b>',
                            '🤝 Приглашено воркеров: <b>'.getUserRefs($t3).'</b>',
                            '🤑 Профит от рефералов: <b>'.beaCash(getUserRefbal($t3)).'RUB</b>',
                            '📆 В команде: <b>'.beaDays(userJoined($t3)).'</b>',
                            '',
                            '🧠 Статус: <b>'.getUserStatusName($t3).'</b>',
                             '',
                             '',
                    ], chatGroup(), [true, [
                            [
                                    ['text' => '', 'callback_data' => '/rank '.$t3.' 1 '],
                                                        ],
                                                        [
                                    ['text' => $btns['unbaner'], 'callback_data' => '/rank '.$t3.' 0 '],
                                                         ],
                                                        [
                                     ['text' => '✖️ Скрыть', 'callback_data' => '/deeeeeeeellll2'],
                                                        ],
                                      ]]);
					}
					else{
						botSend([
                            '<b>👨🏻‍💻 Профиль: '.userLogin($t3, false, false).'</b>',
                                           '',
                            '🆔 ID: <b>'.$t3.'</b>',
                            '🧨 Успешных профитов: <b>'.$profit[0].'</b> ',
                            '💶 Общая сумма профитов: <b>'.beaCash($profit[1]).'RUB</b>',
                            '🤝 Приглашено воркеров: <b>'.getUserRefs($t3).'</b>',
                            '🤑 Профит от рефералов: <b>'.beaCash(getUserRefbal($t3)).'RUB</b>',
                            '📆 В команде: <b>'.beaDays(userJoined($t3)).'</b>',
                            '',
                            '🧠 Статус: <b>'.getUserStatusName($t3).'</b>',
                             '',
                             '',
                    ], chatGroup(), [true, [
                            [
                                    ['text' => $btns['joindban1'], 'callback_data' => '/rank '.$t3.' 1 '],
                                                        ],
                                                        [
                                    ['text' => '', 'callback_data' => '/rank '.$it3.' 0 '],
                                                        ],
                                                        [
                                     ['text' => '✖️ Скрыть', 'callback_data' => '/deeeeeeeellll2'],
                                                        ],
                                           ]]);
					}
					$flag = true;
					break;
				}
        }
            		case '/ban': {
		    $t = beaText(mb_strtolower($cmd[1]), chsNum().chsAlpEn().'_');
		    $frm=$msg['from']['id'];
            $tlg=$login;
					if (strlen($t) == 0)
						break;
					$t3 = false;
					foreach (glob(dirUsers('*')) as $t1) {
						$id2 = basename($t1);
						$t2 = getUserData($id2, 'login');
						if (mb_strtolower($t2) == $t) {
							$t3 = $id2;
							break;
						}
					}
					if (!$t3) {
						$result = [
							'<b>⛔️ Недостаточно прав.</b>',
						];
						break;
					}
					if (getUserStatus($id) > 4) {
					    if (getUserStatus($id) > getUserStatus($id2)) {
					$v = 1;
					setUserStatus($t3, $v);
					$result = [
						'<b>🚯 Пользователь '.userLogin($t3, false, false).' заблокирован.</b>',
					];
					botSend([
						'<b>❌ Вам был заблокирован доступ к проекту.</b>',
						'',
				], $t3);
					$flag = true;
					break;
					}
					}
						break;
        }
          /*      case '/unban': {
		    $t = beaText(mb_strtolower($cmd[1]), chsNum().chsAlpEn().'_');
		    $frm=$msg['from']['id'];
            $tlg=$login;

					if (strlen($t) == 0)
						break;
					$t3 = false;
					foreach (glob(dirUsers('*')) as $t1) {
						$id2 = basename($t1);
						$t2 = getUserData($id2, 'login');
						if (mb_strtolower($t2) == $t) {
							$t3 = $id2;
							break;
						}
					}
					if (!$t3) {
						$result = [
							'❗️ Пользователь <b>@'.$t.'</b> не запускал бота',
						];
						break;
					}
					if (getUserStatus($id) > 4) {
					$v =0;
					setUserStatus($t3, $v);
					$result = [
						'<b>♻️ Пользователь '.userLogin($t3, false, false).' разаблокирован.</b>',
						'',
					];
					$flag = true;
					break;
					} 
        }*/
        case '/rank': {
					$t = explode(' ', $cmd[1], 2);
					$id2 = $t[0];
					if ($id2 == '' || !isUser($id2)) {
						$result = [
							'❗️ Пользователь с таким ID не найден',
						];
						break;
					}
					$rank = intval($t[1]);
					if ($rank < 0 || $rank > getUserStatus($id)) {
						$result = [
							'',
						];
						break;
					}
					if (getUserStatus($id) > getUserStatus($id2)) {
					if (getUserStatus($id) > 4) {
					$rank0 = getUserStatus($id2);
					$t2 = ($rank > $rank0);
					setUserStatus($id2, $rank);
					$result = [
						'⭐️ <b>Статус '.userLogin($id2, true).' изменен на '.userStatusName($rank).'</b>.',
					];
					$flag = true;
					break;
				}
             }
        }
        break;
    case '/rules': {
        	$pravila = checkpravilaSet();
         $result = [
             ''.$pravila.''
             ];
          break;
        }  
        if ($result)
        break; 
      }
      break;
    }
    		case chatTops(): {
			switch ($cmd[0]) {
		case '/top': {
					$t = intval($cmd[1]);
					if ($t < 1 || $t > 2)
						$t = 1;
					else
						$edit = true;
					$t2 = '';
					if ($t == 1)
						$t2 = '💶 <b>Топ 15 по общей сумме профитов:</b>';
					elseif ($t == 2)
						$t2 = '🤝 <b>Топ 15 по профиту от рефералов:</b>';
					$top = [];
					foreach (glob(dirUsers('*')) as $t4) {
						$id2 = basename($t4);
						$v = 0;
						if ($t == 1)
							$v = getUserProfit($id2)[1];
						elseif ($t == 2)
							$v = getUserRefbal($id2);
						if ($v <= 0)
							continue;
						$top[$id2] = $v;
					}
					asort($top);
					$top = array_reverse($top, true);
					$top2 = [];
					$cm = min(15, count($top));
					$c = 1;
					foreach ($top as $id2 => $v) {
						$t3 = '';
						if ($t == 1) {
							$t4 = getUserProfit($id2)[0];
							$t3 = '<b>'.beaCash($v).' RUB</b> - <b>'.$t4.' '.selectWord($t4, ['профитов', 'профит', 'профита']).'</b>';
						}
						elseif ($t == 2) {
							$t4 = getUserRefs($id2);
							$t3 = '<b>'.beaCash($v).' RUB</b> - <b>'.$t4.' '.selectWord($t4, ['рефералов', 'реферал', 'реферала']).'</b>';
						}
						$top2[] = $c.'. <b>'.userLogin2($id2).'</b> - '.$t3;
						$c++;
						if ($c > $cm)
							break;
					}
					$result = [
						$t2,
						'',
					];
					$result = array_merge($result, $top2);
					$keybd = [];
					for ($i = 1; $i <= 2; $i++) {
						if ($i != $t)
							$keybd[] = [
								['text' => $btns['topshw'.$i], 'callback_data' => '/top '.$i],
								['text' => '✖️ Скрыть', 'callback_data' => '/deeeeeeeellll1'],
							];
					}
					$keybd = [true, $keybd];
					break;
				}
			break;
	case '/me': {
          $frm=$msg['from']['id'];
          $tlg=$login;
          $prf = getUserProfit($frm)[0];
          $prf1 = getUserProfit($frm)[1];
          $kmd=beaDays(userJoined($frm));
          $result = [
                '<b>👨🏻‍💻 Ваш профиль |</b> <b>'.userLogin($id, false, false).' </b>',
                '',
               '🆔 Telegram ID: <b>'.$frm.'</b>',
           '',
'🧨 Успешных профитов: <b>'.$prf.'</b> ',
'💶 Общая сумма профитов: <b>'.$prf1.' RUB</b>',

'👥 Приглашено: <b>'.getUserRefs($id2).'</b>',
'💵 Заработано на рефералах: <b>'.beaCash(getUserRefbal($id2)).'RUB</b>',
'🧠 Статус: <b>'.getUserStatusName($id).'</b>',
'',
  '💞 В команде: <b>'.$kmd.'</b>',
          ];
          break;
        }  
        if ($result)
        break; 
    case '/work': {
          		$json = json_decode(file_get_contents('services.json'), true);
          $result = [
             '<b>🚨 Статус проекта:</b>  ' . (($json['66'] == '1') ? '<b> ✅ <ins>WORK</ins> ✅</b>' : '<b> ❌ <ins>STOP</ins> <ins>WORK</ins> ❌</b>') . '',
			'',
			'Ⓜ️ <b>Состояние сервисов:</b>',
			'',
			'🇷🇺 <b><u>Россия</u></b>',
			' • <b>Юла: </b>' . (($json['0'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Авито: </b>' . (($json['1'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>СДЭК: </b>' . (($json['2'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>ПЭК: </b>' . (($json['3'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Боксберри: </b>' . (($json['4'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Яндекс: </b>' . (($json['5'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Достависта: </b>' . (($json['6'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Avito Недвижимость: </b>' . (($json['7'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Youla Недвижимость: </b>' . (($json['8'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Почта РФ: </b>' . (($json['11'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>AUTO RU: </b>' . (($json['12'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Booking: </b>' . (($json['15'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>БлаБлаКар: </b>' . (($json['17'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Циан: </b>' . (($json['18'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>M.Video: </b>' . (($json['25'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Сбербанк: </b>' . (($json['9'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Alpha Bank: </b>' . (($json['10'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Яндекс Объявления: </b>' . (($json['16'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇰🇿 <b><u>Казахстан</u></b>',
			' • <b>OLX KZ: </b>' . (($json['14'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>КазПочта: </b>' . (($json['19'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇧🇾 <b><u>Беларусь</u></b>',
			' • <b>Kufar: </b>' . (($json['20'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>BelPost: </b>' . (($json['21'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
            ' • <b>ЕвроПочта: </b>' . (($json['31'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇷🇴 <b><u>Румыния</u></b>',
			' • <b>OLX RO: </b>' . (($json['23'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇵🇱 <b><u>Польша</u></b>',
			' • <b>OLX PL: </b>' . (($json['27'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>Allegro: </b>' . (($json['30'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
            '',
            '🇺🇦 <b><u>Украина</u></b>',
			' • <b>OLX UA: </b>' . (($json['26'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			' • <b>IZI ua: </b>' . (($json['29'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇨🇿 <b><u>Чехия</u></b>',
			' • <b>Sbazar: </b>' . (($json['28'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
			'🇧🇬 <b><u>Болгария</u></b>',
			' • <b>OLX BG: </b>' . (($json['32'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
			'',
            '🇺🇿 <b><u>Узбекистан</u></b>',
            ' • <b>OLX UZ: </b>' . (($json['22'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
            ' • <b>Fargo uz: </b>' . (($json['24'] == '1') ? '✅ Работает' : '🌑 Не работает') . '',
          ];
          $keybd = [true, [
                        [
                ['text' => '✖️ Скрыть', 'callback_data' => '/deeeeeeeellll1'],
                          ],
                    ]];
          break;
        }  
        if ($result)
        break; 
    case '/deeeeeeeellll1': {
					botDelete($mid, $chat);
					$flag = true;
					break;
				}
		case '/deeeeeeeellll2': {
		    if (getUserStatus($id) > 4) {
					botDelete($mid, $chat);
					$flag = true;
					break;
		    }
				}
/* case '/stats': {
        $profit = getProfit();
		$profit0 = getProfit0();
		$result = [
						'🗒 <b>Статистика за сегодня</b>',
						'',
						'🔥 Всего профитов: <b>'.$profit0[0].'</b>',
						'💸 Сумма профитов: <b>'.beaCash($profit0[1]).'</b>',
						'',
						'',
						'🗒 <b>Статистика за все время</b>',
						'',
						'🔥 Всего профитов: <b>'.$profit[0].'</b>',
						'💸 Сумма профитов: <b>'.beaCash($profit[1]).'</b>',
			];
					$flag = true;
					break;
				} 
        if ($result)
        break; */
    case '/stuff': {
              	$admst = checkadminSet();
		$result = [
						'<b>Администрация проекта '.prjName().'</b>',
						'',
							''.$admst.'',
			];
				$keybd = [true, [
                        [
                ['text' => '✖️ Скрыть', 'callback_data' => '/deeeeeeeellll1'],
                          ],
                    ]];
          break;
        }  
        if ($result)
        break; 
    case '/calc': {
              $z = getRate();
              $t = intval($cmd[1]);
              $pr='0';
              $pr1='0';
              $prt='0';
              $prt1='0';
              if ($t<2000){
                $pr=$t*0;
                $pr1=$t*0;
                $prt='0%';
                $prt1='0%';
                  }else{
                    $pr=$t * $z[0]/100;
                    $pr1=$t * $z[1]/100;
                    $prt=''.$z[0].'%';
                    $prt1=''.$z[1].'%';
                  }
            $result = [
                    '🧮 <b>Калькулятор выплат</b>',
                    '',
                    '<b>🧰 Сумма профита:</b> <code>'.$t.' RUB</code>',
                    '',
                    '<b>☑️ Оплата:</b> <code>'.$pr.'</code> '.$prt.'',
                    '<b>♻️ Возврат:</b> <code>'.$pr1.'</code> '.$prt1.'',
                    ];
             break;
                 } 
		case '/conv': {
		    $t = explode(' ', $cmd[1]);
         	$tz = $t[0];
         	$valute = $t[1];
		if ($valute == 'PLN'){
				$rub = $tz * 20.2051;
				$bel = $tz * 0.68;
				$pln = $tz;
				$kzt = $tz * 113.2;
				$ua = $tz * 7.38;
			}	
		if ($valute == 'RUB'){
				$rub = $tz;
				$bel = $tz * 0.03;
				$pln = $tz * 0.049;
				$kzt = $tz * 5.6;
				$ua = $tz * 0.37;
			}		
		if ($valute == 'BYN'){
				$rub = $tz * 29.97;
				$bel = $tz;
				$pln = $tz * 1.48;
				$kzt = $tz * 167.71;
				$ua = $tz * 11.01;
			}	
		if ($valute == 'KZT'){
				$rub = $tz * 0.18;
				$bel = $tz * 0.006;
				$pln = $tz * 0.0088;
				$kzt = $tz;
				$ua = $tz * 0.066;
			}	
			
		if ($valute == 'UAH'){
				$rub = $tz * 2.72;
				$bel = $tz * 0.091;
				$pln = $tz * 0.14;
				$kzt = $tz * 15.24;
				$ua = $tz;
			}	
		 $result = [
        '<b>🔄 Конвертация валют 🔄</b>',
            '',
        '<b>💹 Сумма:</b><code> '.$tz.' </code>'.$valute.'',
        '',
        '<b>🇵🇱 PLN:</b> <code>'.$pln.'</code> PLN',
        '<b>🇧🇾 BYN:</b> <code>'.$bel.'</code> BYN',
        '<b>🇷🇺 RUB:</b> <code>'.$rub.'</code> RUB',
        '<b>🇰🇿 KZT:</b> <code>'.$kzt.'</code> KZT',
        '<b>🇺🇦 UAH:</b> <code>'.$ua.'</code> UAH',
          ];
			if ($tz == '' or $tz == ' ') {
						$result = [
							'<b> Для конвертации валют пропишите:</b> <code> /conv [сумма] [валюта] </code>',
							'',
							'<i>Доступные валюты: </i><b>RUB, BYN, PLN, KZT, UAH</b>'
						];
			}
		}
		  break;
    case '/ban': {
		    $t = beaText(mb_strtolower($cmd[1]), chsNum().chsAlpEn().'_');
		    $frm=$msg['from']['id'];
            $tlg=$login;

					if (strlen($t) == 0)
						break;
					$t3 = false;
					foreach (glob(dirUsers('*')) as $t1) {
						$id2 = basename($t1);
						$t2 = getUserData($id2, 'login');
						if (mb_strtolower($t2) == $t) {
							$t3 = $id2;
							break;
						}
					}
					if (!$t3) {
						$result = [
							'❗️ Пользователь <b>@'.$t.'</b> не запускал бота',
						];
						break;
					}
						if (getUserStatus($id) > 4) {
						    	if (getUserStatus($id) > getUserStatus($id2)) {
					$v = 1;
					setUserStatus($t3, $v);
					$result = [
						'<b>🚯 Пользователь '.userLogin($t3, false, false).' заблокирован.</b>',
						'',
					];
					botSend([
						'<b>❌ Вам был заблокирован доступ к проекту.</b>',
						'',
				], $t3);
					$flag = true;
					break;
						}
				}
        }
     /*   case '/unban': {
		    $t = beaText(mb_strtolower($cmd[1]), chsNum().chsAlpEn().'_');
		    $frm=$msg['from']['id'];
            $tlg=$login;

					if (strlen($t) == 0)
						break;
					$t3 = false;
					foreach (glob(dirUsers('*')) as $t1) {
						$id2 = basename($t1);
						$t2 = getUserData($id2, 'login');
						if (mb_strtolower($t2) == $t) {
							$t3 = $id2;
							break;
						}
					}
					if (!$t3) {
						$result = [
							'❗️ Пользователь <b>@'.$t.'</b> не запускал бота',
						];
						break;
					}
					if (getUserStatus($id) > 4) {
					$v =0;
					setUserStatus($t3, $v);
					$result = [
						'<b>♻️ Пользователь '.userLogin($t3, false, false).' разаблокирован.</b>',
						'',
					];
					$flag = true;
					break;
					}
        }*/
         case '/info': {
					$t = beaText(mb_strtolower($cmd[1]), chsNum().chsAlpEn().'_');
					$frm=$msg['from']['id'];
          $tlg=$login;
          $prf = getUserProfit($frm)[0];
          $prf1 = getUserProfit($frm)[1];
          $kmd=beaDays(userJoined($frm));
					if (strlen($t) == 0)
						break;
					$t3 = false;
					foreach (glob(dirUsers('*')) as $t1) {
						$id2 = basename($t1);
						$t2 = getUserData($id2, 'login');
						 $profit = getUserProfit($id2);
						if (mb_strtolower($t2) == $t) {
							$t3 = $id2;
							break;
						}
					}
					if (!$t3) {
						$result = [
							'❗️ Пользователь <b>@'.$t.'</b> не запускал бота',
						];
						break;
					}
					$rate = getRate($t3);
					$profit = getUserProfit($t3);
					$result = [
						'',
						'',
					];
				if (getUserStatus($id) > 2) {
					if (getUserStatusName($t3) == 'Заблокирован') {
						botSend([
                            '<b>👨🏻‍💻 Профиль: '.userLogin($t3, false, false).'</b>',
                                           '',
                            '🆔 ID: <b>'.$t3.'</b>',
                            '🧨 Успешных профитов: <b>'.$profit[0].'</b> ',
                            '💶 Общая сумма профитов: <b>'.beaCash($profit[1]).'RUB</b>',
                            '🤝 Приглашено воркеров: <b>'.getUserRefs($t3).'</b>',
                            '🤑 Профит от рефералов: <b>'.beaCash(getUserRefbal($t3)).'RUB</b>',
                            '📆 В команде: <b>'.beaDays(userJoined($t3)).'</b>',
                            '',
                            '🧠 Статус: <b>'.getUserStatusName($t3).'</b>',
                             '',
                             '',
                    ], chatTops(), [true, [
                            [
                                    ['text' => '', 'callback_data' => '/rank '.$t3.' 1 '],
                                                        ],
                                                        [
                                    ['text' => $btns['unbaner'], 'callback_data' => '/rank '.$t3.' 0 '],
                                                         ],
                                                        [
                                     ['text' => '✖️ Скрыть', 'callback_data' => '/deeeeeeeellll2'],
                                                        ],
                                      ]]);
				        	}
					else{
						botSend([
                            '<b>👨🏻‍💻 Профиль: '.userLogin($t3, false, false).'</b>',
                                           '',
                            '🆔 ID: <b>'.$t3.'</b>',
                            '🧨 Успешных профитов: <b>'.$profit[0].'</b> ',
                            '💶 Общая сумма профитов: <b>'.beaCash($profit[1]).'RUB</b>',
                            '🤝 Приглашено воркеров: <b>'.getUserRefs($t3).'</b>',
                            '🤑 Профит от рефералов: <b>'.beaCash(getUserRefbal($t3)).'RUB</b>',
                            '📆 В команде: <b>'.beaDays(userJoined($t3)).'</b>',
                            '',
                            '🧠 Статус: <b>'.getUserStatusName($t3).'</b>',
                             '',
                             '',
                    ], chatTops(), [true, [
                            [
                                    ['text' => $btns['joindban1'], 'callback_data' => '/rank '.$t3.' 1 '],
                                                        ],
                                                        [
                                    ['text' => '', 'callback_data' => '/rank '.$it3.' 0 '],
                                                        ],
                                                        [
                                     ['text' => '✖️ Скрыть', 'callback_data' => '/deeeeeeeellll2'],
                                                        ],
                                           ]]);
					}
					$flag = true;
					break;
				}
        }
        case '/rank': {
					$t = explode(' ', $cmd[1], 2);
					$id2 = $t[0];
					if ($id2 == '' || !isUser($id2)) {
						$result = [
							'❗️ Пользователь с таким ID не найден',
						];
						break;
					}
					$rank = intval($t[1]);
					if ($rank < 0 || $rank > getUserStatus($id)) {
						$result = [
						'',
						];
						break;
					}
					if (getUserStatus($id) > 4) {
					if (getUserStatus($id) > getUserStatus($id2)) {
					$rank0 = getUserStatus($id2);
					$t2 = ($rank > $rank0);
					setUserStatus($id2, $rank);
					$result = [
						'⭐️ <b>Статус '.userLogin($id2, true).' изменен на '.userStatusName($rank).'</b>.',
						'',
					];
					$flag = true;
					break;
				}
                }
        }
        break;
        case '/rules': {
          	$pravila = checkpravilaSet();
         $result = [
             ''.$pravila.''
             ];
          break;
        }  
        if ($result)
        break; 
      }
      break;
    }
  }
  if (!$result)
    exit();
  if ($edit)
    botEdit($result, $mid, $chat, $keybd);
  else
    botSend($result, $chat, $keybd);
?>