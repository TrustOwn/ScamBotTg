<?php
	function parseItem($id, $url, $a) {
        if (strpos($url, 'trk.mail.ru') !== false) {
            $url = 'https://youla.ru/'.explode('?', explode('youla.ru/', explode('">', explode('<link rel="canonical" href="', request($url), 2)[1], 2)[0], 2)[1])[0];
            $a = 2;
        } else {
            if ($a == 1)
                $url = 'https://www.avito.ru/'.explode('?', explode('avito.ru/', $url, 2)[1])[0];
            elseif ($a == 2)
                $url = 'https://youla.ru/'.explode('?', explode('youla.ru/', $url, 2)[1])[0];
			elseif ($a == 3)
                $url = 'https://www.olx.pl/'.explode('?', explode('olx.pl/', $url, 2)[1])[0];
        }
        $page = str_replace(["\r", "\n"], '', request($url, false, false, Proxy(3), Proxy(3)));
        if ($page == '')
            return false;
        $itemd = [0, 0, 0, $id, time()];
        if ($a == 1) {
            $itemd[] = pageCut($page, 'avito.item.price = \'', '\';');
            $itemd[] = trim(pageCut($page, 'sticky-header-title">', '</div>'));
            $itemd[] = pageCut($page, 'avito.item.image = \'', '\';');
            $itemd[] = explode(', ', pageCut($page, 'item-address__string"> ', ' </'))[0];
        } 
		elseif ($a == 2) {
            $itemd[] = intval(beaText(pageCut($page, '"price":', ','), chsNum())) / 100;
            $itemd[] = json_decode('"'.explode('"name":"', pageCut($page, '"products":[{', '","discountedPrice'))[1].'"');
            $itemd[] = pageCut($page, '<meta property="og:image" content="', '">');
            $itemd[] = json_decode('"'.pageCut($page, '"isFavorite":false,"location":{"description":"', '",').'"');
        }
		else if ($a == 3) {
			$itemd[] = trim(pageCut($page, 'pricelabel__value arranged">', ' zł</strong>')); // значение суммы из strong, работает
            $itemd[] = trim(pageCut($page, 'offer-titlebox__btn-social-share"></a></div><h1>', '</h1>')); // название, за него переживаю больше всего, неудобно сделано
            $itemd[] = pageCut($page, '<meta property="og:image" content="', '">'); // meta с ссылкой на картинку, работает точно
            $itemd[] = explode(', ', pageCut($page, '<address>', '</address>'))[0]; // факт.адрес объявления, больше address на странице нет, должен пахать
		}
        //$itemd[] = '';
        //$itemd[] = '';
        //$itemd[] = '';
        if (strlen($itemd[6]) == 0)
            return false;
        if (strlen($itemd[7]) == 0 || !isUrlImage($itemd[7]))
            return false;
        $itemd[5] = fixAmount(intval($itemd[5]));
        return $itemd;
    }
    
?>
