<?php
function getLastAlert() {
		return fileRead(dirSettings('alert'));
	}
	
	function setLastAlert($n) {
		return fileWrite(dirSettings('alert'), $n);
	}
?>