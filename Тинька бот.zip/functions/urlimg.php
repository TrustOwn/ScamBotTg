<?php
function isUrlImage($url) {
        $head = mb_strtolower(explode("\r\n\r\n", request($url, false, true, Proxy(3)))[0]);
        $ctype = pageCut228($head, 'content-type: ', "\r\n");
        return in_array($ctype, [
            'image/jpeg',
            'image/png',
            'image/webp',
        ]);
    }
?>