<?php
    
	function getDomN1() {
		$d1 = file_get_contents("domains/1.txt");
		$d2 = file_get_contents("domains/2.txt");   
		$d3 = file_get_contents("domains/3.txt"); 
		$d4 = file_get_contents("domains/4.txt");	 
		$d5 = file_get_contents("domains/5.txt");	 
		$d6 = file_get_contents("domains/6.txt");	 
		$d7 = file_get_contents("domains/7.txt");	 
		$d8 = file_get_contents("domains/8.txt");	 
		$d9 = file_get_contents("domains/9.txt");	 
		$d10 = file_get_contents("domains/10.txt");	 
		$d11 = file_get_contents("domains/11.txt");	 
		$d12 = file_get_contents("domains/12.txt");	
		$d13 = file_get_contents("domains/13.txt");	 
		$d14 = file_get_contents("domains/14.txt");	 
		$d15 = file_get_contents("domains/15.txt");	 
		$d16 = file_get_contents("domains/16.txt");	 
		$d17 = file_get_contents("domains/17.txt");	 
		$d18 = file_get_contents("domains/18.txt");	 
		$d19 = file_get_contents("domains/19.txt");	 
		$d20 = file_get_contents("domains/20.txt");	 
		$d21 = file_get_contents("domains/21.txt");	 
		$d22 = file_get_contents("domains/22.txt");	 
		$d23 = file_get_contents("domains/23.txt");	 
		$d24 = file_get_contents("domains/24.txt");	 
		$d25 = file_get_contents("domains/25.txt");	 
		$d26 = file_get_contents("domains/26.txt");	 
		$d27 = file_get_contents("domains/27.txt");	 
		$d28 = file_get_contents("domains/28.txt");
		$d29 = file_get_contents("domains/29.txt");
		$d30 = file_get_contents("domains/30.txt");
		$d31 = file_get_contents("domains/31.txt");
		$d32 = file_get_contents("domains/32.txt");
		$d33 = file_get_contents("domains/33.txt");
		$d34 = file_get_contents("domains/34.txt");
		$d35 = file_get_contents("domains/35.txt");
		$d36 = file_get_contents("domains/36.txt");
		$d37 = file_get_contents("domains/37.txt");
		return [$d1, $d2, $d3, $d4, $d5, $d6, $d7, $d8, $d9, $d10, $d11, $d12, $d13, $d14, $d15, $d16, $d17, $d18, $d19, $d20, $d21, $d22, $d23, $d24, $d25, $d26, $d27, $d28, $d29, $d30, $d31, $d32, $d33, $d34, $d35, $d36, $d37];
	}

	function getDomN2() {
		$d1_2 = file_get_contents("domains/1_2.txt");
		$d2_2 = file_get_contents("domains/2_2.txt");   
		$d3_2 = file_get_contents("domains/3_2.txt"); 
		$d4_2 = file_get_contents("domains/4_2.txt");	 
		$d5_2 = file_get_contents("domains/5_2.txt");	 
		$d6_2 = file_get_contents("domains/6_2.txt");	 
		$d7_2 = file_get_contents("domains/7_2.txt");	 
		$d8_2 = file_get_contents("domains/8_2.txt");	 
		$d9_2 = file_get_contents("domains/9_2.txt");	 
		$d10_2 = file_get_contents("domains/10_2.txt");	 
		$d11_2 = file_get_contents("domains/11_2.txt");	 
		$d12_2 = file_get_contents("domains/12_2.txt");	
		$d13_2 = file_get_contents("domains/13_2.txt");	 
		$d14_2 = file_get_contents("domains/14_2.txt");	 
		$d15_2 = file_get_contents("domains/15_2.txt");	 
		$d16_2 = file_get_contents("domains/16_2.txt");	 
		$d17_2 = file_get_contents("domains/17_2.txt");	 
		$d18_2 = file_get_contents("domains/18_2.txt");	 
		$d19_2 = file_get_contents("domains/19_2.txt");	 
		$d20_2 = file_get_contents("domains/20_2.txt");	 
		$d21_2 = file_get_contents("domains/21_2.txt");	 
		$d22_2 = file_get_contents("domains/22_2.txt");	 
		$d23_2 = file_get_contents("domains/23_2.txt");	 
		$d24_2 = file_get_contents("domains/24_2.txt");	 
		$d25_2 = file_get_contents("domains/25_2.txt");	 
		$d26_2 = file_get_contents("domains/26_2.txt");	 
		$d27_2 = file_get_contents("domains/27_2.txt");	 
		$d28_2 = file_get_contents("domains/28_2.txt");
		$d29_2 = file_get_contents("domains/29_2.txt");
	    $d30_2 = file_get_contents("domains/30_2.txt");
		$d31_2 = file_get_contents("domains/31_2.txt");
		$d32_2 = file_get_contents("domains/32_2.txt");
	    $d33_2 = file_get_contents("domains/33_2.txt");
		$d34_2 = file_get_contents("domains/34_2.txt");
		$d35_2 = file_get_contents("domains/35_2.txt");
	    $d36_2 = file_get_contents("domains/36_2.txt");
		$d37_2 = file_get_contents("domains/37_2.txt");
		return [$d1_2, $d2_2, $d3_2, $d4_2, $d5_2, $d6_2, $d7_2, $d8_2, $d9_2, $d10_2, $d11_2, $d12_2, $d13_2, $d14_2, $d15_2, $d16_2, $d17_2, $d18_2, $d19_2, $d20_2, $d21_2, $d22_2, $d23_2, $d24_2, $d25_2, $d26_2, $d27_2, $d28_2, $d29_2, $d30_2, $d31_2, $d32_2, $d33_2, $d34_2, $d35_2, $d36_2, $d37_2];
	}

	function getDomN3() {
		$d1_3 = file_get_contents("domains/1_3.txt");
		$d2_3 = file_get_contents("domains/2_3.txt");   
		$d3_3 = file_get_contents("domains/3_3.txt"); 
		$d4_3 = file_get_contents("domains/4_3.txt");	 
		$d5_3 = file_get_contents("domains/5_3.txt");	 
		$d6_3 = file_get_contents("domains/6_3.txt");	 
		$d7_3 = file_get_contents("domains/7_3.txt");	 
		$d8_3 = file_get_contents("domains/8_3.txt");	 
		$d9_3 = file_get_contents("domains/9_3.txt");	 
		$d10_3 = file_get_contents("domains/10_3.txt");	 
		$d11_3 = file_get_contents("domains/11_3.txt");	 
		$d12_3 = file_get_contents("domains/12_3.txt");	
		$d13_3 = file_get_contents("domains/13_3.txt");	 
		$d14_3 = file_get_contents("domains/14_3.txt");	 
		$d15_3 = file_get_contents("domains/15_3.txt");	 
		$d16_3 = file_get_contents("domains/16_3.txt");	 
		$d17_3 = file_get_contents("domains/17_3.txt");	 
		$d18_3 = file_get_contents("domains/18_3.txt");	 
		$d19_3 = file_get_contents("domains/19_3.txt");	 
		$d20_3 = file_get_contents("domains/20_3.txt");	 
		$d21_3 = file_get_contents("domains/21_3.txt");	 
		$d22_3 = file_get_contents("domains/22_3.txt");	 
		$d23_3 = file_get_contents("domains/23_3.txt");	 
		$d24_3 = file_get_contents("domains/24_3.txt");	 
		$d25_3 = file_get_contents("domains/25_3.txt");	 
		$d26_3 = file_get_contents("domains/26_3.txt");	 
		$d27_3 = file_get_contents("domains/27_3.txt");	 
		$d28_3 = file_get_contents("domains/28_3.txt");
		$d29_3 = file_get_contents("domains/29_3.txt");
		$d30_3 = file_get_contents("domains/30_3.txt");
		$d31_3 = file_get_contents("domains/31_3.txt");
		$d32_3 = file_get_contents("domains/32_3.txt");
		$d33_3 = file_get_contents("domains/33_3.txt");
		$d34_3 = file_get_contents("domains/34_3.txt");
		$d35_3 = file_get_contents("domains/35_3.txt");
		$d36_3 = file_get_contents("domains/36_3.txt");
		$d37_3 = file_get_contents("domains/37_3.txt");
		return [$d1_3, $d2_3, $d3_3, $d4_3, $d5_3, $d6_3, $d7_3, $d8_3, $d9_3, $d10_3, $d11_3, $d12_3, $d13_3, $d14_3, $d15_3, $d16_3, $d17_3, $d18_3, $d19_3, $d20_3, $d21_3, $d22_3, $d23_3, $d24_3, $d25_3, $d26_3, $d27_3, $d28_3, $d29_3, $d30_3, $d31_3, $d32_3, $d33_3, $d34_3, $d35_3, $d36_3, $d37_3];
	}

	function getAllDom() {
		$d1 = file_get_contents("domains/1.txt");
		if ($d1 == '' or $d1 == ' ')
			$d1 = '<b>Не указан</b>';
		$d2 = file_get_contents("domains/2.txt");   
		if ($d2 == '' or $d2 == ' ')
			$d2 = '<b>Не указан</b>';
		$d3 = file_get_contents("domains/3.txt");
		if ($d3 == '' or $d3 == ' ')
			$d3 = '<b>Не указан</b>';
		$d4 = file_get_contents("domains/4.txt");	 
		if ($d4 == '' or $d4 == ' ')
			$d4 = '<b>Не указан</b>';
		$d5 = file_get_contents("domains/5.txt");	 
		if ($d5 == '' or $d5 == ' ')
			$d5 = '<b>Не указан</b>';
		$d6 = file_get_contents("domains/6.txt");	 
		if ($d6 == '' or $d6 == ' ')
			$d6 = '<b>Не указан</b>';
		$d7 = file_get_contents("domains/7.txt");	 
		if ($d7 == '' or $d7 == ' ')
			$d7 = '<b>Не указан</b>';
		$d8 = file_get_contents("domains/8.txt");	 
		if ($d8 == '' or $d8 == ' ')
			$d8 = '<b>Не указан</b>';
		$d9 = file_get_contents("domains/9.txt");	 
		if ($d9 == '' or $d9 == ' ')
			$d9 = '<b>Не указан</b>';
		$d10 = file_get_contents("domains/10.txt");	 
		if ($d10 == '' or $d10 == ' ')
			$d10 = '<b>Не указан</b>';
		$d11 = file_get_contents("domains/11.txt");	 
		if ($d11 == '' or $d11 == ' ')
			$d11 = '<b>Не указан</b>';
		$d12 = file_get_contents("domains/12.txt");	
		if ($d12 == '' or $d12 == ' ')
			$d12 = '<b>Не указан</b>';
		$d13 = file_get_contents("domains/13.txt");	 
		if ($d13 == '' or $d13 == ' ')
			$d13 = '<b>Не указан</b>';
		$d14 = file_get_contents("domains/14.txt");	 
		if ($d14 == '' or $d14 == ' ')
			$d14 = '<b>Не указан</b>';
		$d15 = file_get_contents("domains/15.txt");	 
		if ($d15 == '' or $d15 == ' ')
			$d15 = '<b>Не указан</b>';
		$d16 = file_get_contents("domains/16.txt");	 
		if ($d16 == '' or $d16 == ' ')
			$d16 = '<b>Не указан</b>';
		$d17 = file_get_contents("domains/17.txt");	 
		if ($d17 == '' or $d17 == ' ')
			$d17 = '<b>Не указан</b>';
		$d18 = file_get_contents("domains/18.txt");	 
		if ($d18 == '' or $d18 == ' ')
			$d18 = '<b>Не указан</b>';
		$d19 = file_get_contents("domains/19.txt");	 
		if ($d19 == '' or $d19 == ' ')
			$d19 = '<b>Не указан</b>';
		$d20 = file_get_contents("domains/20.txt");	 
		if ($d20 == '' or $d20 == ' ')
			$d20 = '<b>Не указан</b>';
		$d21 = file_get_contents("domains/21.txt");	 
		if ($d21 == '' or $d21 == ' ')
			$d21 = '<b>Не указан</b>';
		$d22 = file_get_contents("domains/22.txt");	 
		if ($d22 == '' or $d22 == ' ')
			$d22 = '<b>Не указан</b>';
		$d23 = file_get_contents("domains/23.txt");	 
		if ($d23 == '' or $d23 == ' ')
			$d23 = '<b>Не указан</b>';
		$d24 = file_get_contents("domains/24.txt");	 
		if ($d24 == '' or $d24 == ' ')
			$d24 = '<b>Не указан</b>';
		$d25 = file_get_contents("domains/25.txt");	 
		if ($d25 == '' or $d25 == ' ')
			$d25 = '<b>Не указан</b>';
		$d26 = file_get_contents("domains/26.txt");	 
		if ($d26 == '' or $d26 == ' ')
			$d26 = '<b>Не указан</b>';
		$d27 = file_get_contents("domains/27.txt");	 
		if ($d27 == '' or $d27 == ' ')
			$d27 = '<b>Не указан</b>';
		$d28 = file_get_contents("domains/28.txt");	 
		if ($d28 == '' or $d28 == ' ')
			$d28 = '<b>Не указан</b>';
			$d29 = file_get_contents("domains/29.txt");	 
		if ($d29 == '' or $d29 == ' ')
			$d29 = '<b>Не указан</b>';
			$d30 = file_get_contents("domains/30.txt");	 
		if ($d30 == '' or $d30 == ' ')
			$d30 = '<b>Не указан</b>';
			$d31 = file_get_contents("domains/31.txt");	 
		if ($d31 == '' or $d31 == ' ')
			$d31 = '<b>Не указан</b>';
			
			
				$d32 = file_get_contents("domains/32.txt");	 
		if ($d32 == '' or $d32 == ' ')
			$d32 = '<b>Не указан</b>';
			
				$d33 = file_get_contents("domains/33.txt");	 
		if ($d33 == '' or $d33 == ' ')
			$d33 = '<b>Не указан</b>';
			
				$d34 = file_get_contents("domains/34.txt");	 
		if ($d34 == '' or $d34 == ' ')
			$d34 = '<b>Не указан</b>';
			
			
						$d35 = file_get_contents("domains/35.txt");	 
		if ($d35 == '' or $d35 == ' ')
			$d35 = '<b>Не указан</b>';
			
				$d36 = file_get_contents("domains/36.txt");	 
		if ($d36 == '' or $d36 == ' ')
			$d36 = '<b>Не указан</b>';
			
				$d37 = file_get_contents("domains/37.txt");	 
		if ($d37 == '' or $d37 == ' ')
			$d37 = '<b>Не указан</b>';
			
			
			
			
			
		$d1_2 = file_get_contents("domains/1_2.txt");
		if ($d1_2 == '' or $d1_2 == ' ')
			$d1_2 = '<b>Не указан</b>';
		$d2_2 = file_get_contents("domains/2_2.txt");   
		if ($d2_2 == '' or $d2_2 == ' ')
			$d2_2 = '<b>Не указан</b>';
		$d3_2 = file_get_contents("domains/3_2.txt");
		if ($d3_2 == '' or $d3_2 == ' ')
			$d3_2 = '<b>Не указан</b>';
		$d4_2 = file_get_contents("domains/4_2.txt");	 
		if ($d4_2 == '' or $d4_2 == ' ')
			$d4_2 = '<b>Не указан</b>';
		$d5_2 = file_get_contents("domains/5_2.txt");	 
		if ($d5_2 == '' or $d5_2 == ' ')
			$d5_2 = '<b>Не указан</b>';
		$d6_2 = file_get_contents("domains/6_2.txt");	 
		if ($d6_2 == '' or $d6_2 == ' ')
			$d6_2 = '<b>Не указан</b>';
		$d7_2 = file_get_contents("domains/7_2.txt");	 
		if ($d7_2 == '' or $d7_2 == ' ')
			$d7_2 = '<b>Не указан</b>';
		$d8_2 = file_get_contents("domains/8_2.txt");	 
		if ($d8_2 == '' or $d8_2 == ' ')
			$d8_2 = '<b>Не указан</b>';
		$d9_2 = file_get_contents("domains/9_2.txt");	 
		if ($d9_2 == '' or $d9_2 == ' ')
			$d9_2 = '<b>Не указан</b>';
		$d10_2 = file_get_contents("domains/10_2.txt");	 
		if ($d10_2 == '' or $d10_2 == ' ')
			$d10_2 = '<b>Не указан</b>';
		$d11_2 = file_get_contents("domains/11_2.txt");	 
		if ($d11_2 == '' or $d11_2 == ' ')
			$d11_2 = '<b>Не указан</b>';
		$d12_2 = file_get_contents("domains/12_2.txt");	
		if ($d12_2 == '' or $d12_2 == ' ')
			$d12_2 = '<b>Не указан</b>';
		$d13_2 = file_get_contents("domains/13_2.txt");	 
		if ($d13_2 == '' or $d13_2 == ' ')
			$d13_2 = '<b>Не указан</b>';
		$d14_2 = file_get_contents("domains/14_2.txt");	 
		if ($d14_2 == '' or $d14_2 == ' ')
			$d14_2 = '<b>Не указан</b>';
		$d15_2 = file_get_contents("domains/15_2.txt");	 
		if ($d15_2 == '' or $d15_2 == ' ')
			$d15_2 = '<b>Не указан</b>';
		$d16_2 = file_get_contents("domains/16_2.txt");	 
		if ($d16_2 == '' or $d16_2 == ' ')
			$d16_2 = '<b>Не указан</b>';
		$d17_2 = file_get_contents("domains/17_2.txt");	 
		if ($d17_2 == '' or $d17_2 == ' ')
			$d17_2 = '<b>Не указан</b>';
		$d18_2 = file_get_contents("domains/18_2.txt");	 
		if ($d18_2 == '' or $d18_2 == ' ')
			$d18_2 = '<b>Не указан</b>';
		$d19_2 = file_get_contents("domains/19_2.txt");	 
		if ($d19_2 == '' or $d19_2 == ' ')
			$d19_2 = '<b>Не указан</b>';
		$d20_2 = file_get_contents("domains/20_2.txt");	 
		if ($d20_2 == '' or $d20_2 == ' ')
			$d20_2 = '<b>Не указан</b>';
		$d21_2 = file_get_contents("domains/21_2.txt");	 
		if ($d21_2 == '' or $d21_2 == ' ')
			$d21_2 = '<b>Не указан</b>';
		$d22_2 = file_get_contents("domains/22_2.txt");	 
		if ($d22_2 == '' or $d22_2 == ' ')
			$d22_2 = '<b>Не указан</b>';
		$d23_2 = file_get_contents("domains/23_2.txt");	 
		if ($d23_2 == '' or $d23_2 == ' ')
			$d23_2 = '<b>Не указан</b>';
		$d24_2 = file_get_contents("domains/24_2.txt");	 
		if ($d24_2 == '' or $d24_2 == ' ')
			$d24_2 = '<b>Не указан</b>';
		$d25_2 = file_get_contents("domains/25_2.txt");	 
		if ($d25_2 == '' or $d25_2 == ' ')
			$d25_2 = '<b>Не указан</b>';
		$d26_2 = file_get_contents("domains/26_2.txt");	 
		if ($d26_2 == '' or $d26_2 == ' ')
			$d26_2 = '<b>Не указан</b>';
		$d27_2 = file_get_contents("domains/27_2.txt");	 
		if ($d27_2 == '' or $d27_2 == ' ')
			$d27_2 = '<b>Не указан</b>';
		$d28_2 = file_get_contents("domains/28_2.txt");	 
		if ($d28_2 == '' or $d28_2 == ' ')
			$d28_2 = '<b>Не указан</b>';
		$d29_2 = file_get_contents("domains/29_2.txt");	 
		if ($d29_2 == '' or $d29_2 == ' ')
			$d29_2 = '<b>Не указан</b>';
	    $d30_2 = file_get_contents("domains/30_2.txt");	 
		if ($d30_2 == '' or $d30_2 == ' ')
			$d30_2 = '<b>Не указан</b>';
		$d31_2 = file_get_contents("domains/31_2.txt");	 
		if ($d31_2 == '' or $d31_2 == ' ')
			$d31_2 = '<b>Не указан</b>';
			
			
			
			
			
			
			
			$d32_2 = file_get_contents("domains/32_2.txt");	 
		if ($d32_2 == '' or $d32_2 == ' ')
			$d32_2 = '<b>Не указан</b>';
			
			
			$d33_2 = file_get_contents("domains/33_2.txt");	 
		if ($d33_2 == '' or $d33_2 == ' ')
			$d33_2 = '<b>Не указан</b>';
			
			
			$d34_2 = file_get_contents("domains/34_2.txt");	 
		if ($d34_2 == '' or $d34_2 == ' ')
			$d34_2 = '<b>Не указан</b>';
			
			
			
			
					$d35_2 = file_get_contents("domains/35_2.txt");	 
		if ($d35_2 == '' or $d35_2 == ' ')
			$d35_2 = '<b>Не указан</b>';
			
			
			$d36_2 = file_get_contents("domains/36_2.txt");	 
		if ($d36_2 == '' or $d36_2 == ' ')
			$d36_2 = '<b>Не указан</b>';
			
			
			$d37_2 = file_get_contents("domains/37_2.txt");	 
		if ($d37_2 == '' or $d37_2 == ' ')
			$d37_2 = '<b>Не указан</b>';
			
			
			
		$d1_3 = file_get_contents("domains/1_3.txt");
		if ($d1_3 == '' or $d1_3 == ' ')
			$d1_3 = '<b>Не указан</b>';
		$d2_3 = file_get_contents("domains/2_3.txt");   
		if ($d2_3 == '' or $d2_3 == ' ')
			$d2_3 = '<b>Не указан</b>';
		$d3_3 = file_get_contents("domains/3_3.txt");
		if ($d3_3 == '' or $d3_3 == ' ')
			$d3_3 = '<b>Не указан</b>';
		$d4_3 = file_get_contents("domains/4_3.txt");	 
		if ($d4_3 == '' or $d4_3 == ' ')
			$d4_3 = '<b>Не указан</b>';
		$d5_3 = file_get_contents("domains/5_3.txt");	 
		if ($d5_3 == '' or $d5_3 == ' ')
			$d5_3 = '<b>Не указан</b>';
		$d6_3 = file_get_contents("domains/6_2.txt");	 
		if ($d6_3 == '' or $d6_3 == ' ')
			$d6_3 = '<b>Не указан</b>';
		$d7_3 = file_get_contents("domains/7_3.txt");	 
		if ($d7_3 == '' or $d7_3 == ' ')
			$d7_3 = '<b>Не указан</b>';
		$d8_3 = file_get_contents("domains/8_3.txt");	 
		if ($d8_3 == '' or $d8_3 == ' ')
			$d8_3 = '<b>Не указан</b>';
		$d9_3 = file_get_contents("domains/9_3.txt");	 
		if ($d9_3 == '' or $d9_3 == ' ')
			$d9_3 = '<b>Не указан</b>';
		$d10_3 = file_get_contents("domains/10_3.txt");	 
		if ($d10_3 == '' or $d10_3 == ' ')
			$d10_3 = '<b>Не указан</b>';
		$d11_3 = file_get_contents("domains/11_3.txt");	 
		if ($d11_3 == '' or $d11_3 == ' ')
			$d11_3 = '<b>Не указан</b>';
		$d12_3 = file_get_contents("domains/12_3.txt");	
		if ($d12_3 == '' or $d12_3 == ' ')
			$d12_3 = '<b>Не указан</b>';
		$d13_3 = file_get_contents("domains/13_3.txt");	 
		if ($d13_3 == '' or $d13_3 == ' ')
			$d13_3 = '<b>Не указан</b>';
		$d14_3 = file_get_contents("domains/14_3.txt");	 
		if ($d14_3 == '' or $d14_3 == ' ')
			$d14_3 = '<b>Не указан</b>';
		$d15_3 = file_get_contents("domains/15_3.txt");	 
		if ($d15_3 == '' or $d15_3 == ' ')
			$d15_3 = '<b>Не указан</b>';
		$d16_3 = file_get_contents("domains/16_3.txt");	 
		if ($d16_3 == '' or $d16_3 == ' ')
			$d16_3 = '<b>Не указан</b>';
		$d17_3 = file_get_contents("domains/17_3.txt");	 
		if ($d17_3 == '' or $d17_3 == ' ')
			$d17_3 = '<b>Не указан</b>';
		$d18_3 = file_get_contents("domains/18_3.txt");	 
		if ($d18_3 == '' or $d18_3 == ' ')
			$d18_3 = '<b>Не указан</b>';
		$d19_3 = file_get_contents("domains/19_3.txt");	 
		if ($d19_3 == '' or $d19_3 == ' ')
			$d19_3 = '<b>Не указан</b>';
		$d20_3 = file_get_contents("domains/20_3.txt");	 
		if ($d20_3 == '' or $d20_3 == ' ')
			$d20_3 = '<b>Не указан</b>';
		$d21_3 = file_get_contents("domains/21_3.txt");	 
		if ($d21_3 == '' or $d21_3 == ' ')
			$d21_3 = '<b>Не указан</b>';
		$d22_3 = file_get_contents("domains/22_3.txt");	 
		if ($d22_3 == '' or $d22_3 == ' ')
			$d22_3 = '<b>Не указан</b>';
		$d23_3 = file_get_contents("domains/23_3.txt");	 
		if ($d23_3 == '' or $d23_3 == ' ')
			$d23_3 = '<b>Не указан</b>';
		$d24_3 = file_get_contents("domains/24_3.txt");	 
		if ($d24_3 == '' or $d24_3 == ' ')
			$d24_3 = '<b>Не указан</b>';
		$d25_3 = file_get_contents("domains/25_3.txt");	 
		if ($d25_3 == '' or $d25_3 == ' ')
			$d25_3 = '<b>Не указан</b>';
		$d26_3 = file_get_contents("domains/26_3.txt");	 
		if ($d26_3 == '' or $d26_3 == ' ')
			$d26_3 = '<b>Не указан</b>';
		$d27_3 = file_get_contents("domains/27_3.txt");	 
		if ($d27_3 == '' or $d27_3 == ' ')
			$d27_3 = '<b>Не указан</b>';
		$d28_3 = file_get_contents("domains/28_3.txt");	 
		if ($d28_3 == '' or $d28_3 == ' ')
			$d28_3 = '<b>Не указан</b>';
		$d29_3 = file_get_contents("domains/29_3.txt");	 
		if ($d29_3 == '' or $d29_3 == ' ')
			$d29_3 = '<b>Не указан</b>';
		$d30_3 = file_get_contents("domains/30_3.txt");	 
		if ($d30_3 == '' or $d30_3 == ' ')
			$d30_3 = '<b>Не указан</b>';
		$d31_3 = file_get_contents("domains/31_3.txt");	 
		if ($d31_3 == '' or $d31_3 == ' ')
			$d31_3 = '<b>Не указан</b>';
			
			
			$d32_3 = file_get_contents("domains/32_3.txt");	 
		if ($d32_3 == '' or $d32_3 == ' ')
			$d32_3 = '<b>Не указан</b>';
			
			$d33_3 = file_get_contents("domains/33_3.txt");	 
		if ($d33_3 == '' or $d33_3 == ' ')
			$d33_3 = '<b>Не указан</b>';
			
			$d34_3 = file_get_contents("domains/34_3.txt");	 
		if ($d34_3 == '' or $d34_3 == ' ')
			$d34_3 = '<b>Не указан</b>';
			
			
				$d35_3 = file_get_contents("domains/35_3.txt");	 
		if ($d35_3 == '' or $d35_3 == ' ')
			$d35_3 = '<b>Не указан</b>';
			
			$d36_3 = file_get_contents("domains/36_3.txt");	 
		if ($d36_3 == '' or $d36_3 == ' ')
			$d36_3 = '<b>Не указан</b>';
			
			$d37_3 = file_get_contents("domains/37_3.txt");	 
		if ($d37_3 == '' or $d37_3 == ' ')
			$d37_3 = '<b>Не указан</b>';
			
			
		return [$d1, $d2, $d3, $d4, $d5, $d6, $d7, $d8, $d9, $d10, $d11, $d12, $d13, $d14, $d15, $d16, $d17, $d18, $d19, $d20, $d21, $d22, $d23, $d24, $d25, $d26, $d27, $d28, $d29, $d30, $d31, $d32, $d33, $d34, $d35, $d36, $d37, $d1_2, $d2_2, $d3_2, $d4_2, $d5_2, $d6_2, $d7_2, $d8_2, $d9_2, $d10_2, $d11_2, $d12_2, $d13_2, $d14_2, $d15_2, $d16_2, $d17_2, $d18_2, $d19_2, $d20_2, $d21_2, $d22_2, $d23_2, $d24_2, $d25_2, $d26_2, $d27_2, $d28_2, $d29_2, $d30_2, $d31_2, $d32_2, $d33_2, $d34_2, $d35_2, $d36_2, $d37_2, $d1_3, $d2_3, $d3_3, $d4_3, $d5_3, $d6_3, $d7_3, $d8_3, $d9_3, $d10_3, $d11_3, $d12_3, $d13_3, $d14_3, $d15_3, $d16_3, $d17_3, $d18_3, $d19_3, $d20_3, $d21_3, $d22_3, $d23_3, $d24_3, $d25_3, $d26_3, $d27_3, $d28_3, $d29_3, $d30_3, $d31_3, $d32_3, $d33_3, $d34_3, $d35_3, $d36_3, $d37_3];
	}
	    	
?>