<?php
	function request1($url, $post = false, $rh = false, $proxy = []) {
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        if ($rh)
            curl_setopt($curl, CURLOPT_HEADER, true);
        if ($post) {
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($post));
        }
        if(isset($proxy[0])) {
                curl_setopt($curl, CURLOPT_PROXY, $proxy[0]);
            if(isset($proxy[1])) {
                curl_setopt($curl, CURLOPT_PROXYUSERPWD, $proxy[1]);
                curl_setopt($curl, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
            }
        }
        $result = curl_exec($curl);
        curl_close($curl);
        return $result;
    }
    $keyc = botToken();
    $bnkm = botLogin();
?>