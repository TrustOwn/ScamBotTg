<?php 

$json = json_decode(file_get_contents('services.json'), 1);

				$arrayserv = [];
				
				if ($json['66'] == '1') {
					array_push($arrayserv,  [['text' => '🌕 WORK', 'callback_data' => '/setservice 66 0 ']]);
				}
				else {
					array_push($arrayserv,  [['text' => '🌑 STOP WORK', 'callback_data' => '/setservice 66 1 ']]);
				}
				if ($json['0'] == '1') {
					array_push($arrayserv,  [['text' => '✅ Юла', 'callback_data' => '/setservice 0 0 ']]);
				}
				else {
					array_push($arrayserv,  [['text' => '❌ Юла', 'callback_data' => '/setservice 0 1 ']]);
				}


				if ($json['1'] == '1') {
					array_push($arrayserv,  [['text' => '✅ Авито', 'callback_data' => '/setservice 1 0 ']]);
				}
				else {
					array_push($arrayserv,  [['text' => '❌ Авито', 'callback_data' => '/setservice 1 1 ']]);
				}


				if ($json['2'] == '1') {
					array_push($arrayserv,  [['text' => '✅ СДЭК', 'callback_data' => '/setservice 2 0 ']]);
				}
				else {
					array_push($arrayserv,  [['text' => '❌ СДЭК', 'callback_data' => '/setservice 2 1 ']]);
				}

				if ($json['3'] == '1') {
					array_push($arrayserv,  [['text' => '✅ ПЭК', 'callback_data' => '/setservice 3 0 ']]);
				}
				else {
					array_push($arrayserv,  [['text' => '❌ ПЭК', 'callback_data' => '/setservice 3 1 ']]);
				}

				if ($json['4'] == '1') {
					array_push($arrayserv,  [['text' => '✅ Боксберри', 'callback_data' => '/setservice 4 0 ']]);
				}
				else {
					array_push($arrayserv,  [['text' => '❌ Боксберри', 'callback_data' => '/setservice 4 1 ']]);
				}

				if ($json['5'] == '1') {
					array_push($arrayserv,  [['text' => '✅ Яндекс', 'callback_data' => '/setservice 5 0 ']]);
				}
				else {
					array_push($arrayserv,  [['text' => '❌ Яндекс', 'callback_data' => '/setservice 5 1 ']]);
				}

				if ($json['6'] == '1') {
					array_push($arrayserv,  [['text' => '✅ Достависта', 'callback_data' => '/setservice 6 0 ']]);
				}
				else {
					array_push($arrayserv,  [['text' => '❌ Достависта', 'callback_data' => '/setservice 6 1 ']]);
				}

				if ($json['7'] == '1') {
					array_push($arrayserv,  [['text' => '✅ AVITO RENT', 'callback_data' => '/setservice 7 0 ']]);
				}
				else {
					array_push($arrayserv,  [['text' => '❌ AVITO RENT', 'callback_data' => '/setservice 7 1 ']]);
				}
				if ($json['8'] == '1') {
					array_push($arrayserv,  [['text' => '✅ YOULA RENT', 'callback_data' => '/setservice 8 0 ']]);
				}
				else {
					array_push($arrayserv,  [['text' => '❌ YOULA RENT', 'callback_data' => '/setservice 8 1 ']]);
				}
					if ($json['11'] == '1') {
					array_push($arrayserv,  [['text' => '✅ Почта РФ', 'callback_data' => '/setservice 11 0 ']]);
				}
				else {
					array_push($arrayserv,  [['text' => '❌ Почта РФ', 'callback_data' => '/setservice 11 1 ']]);
				}
				if ($json['9'] == '1') {
					array_push($arrayserv,  [['text' => '✅ Деловые линии', 'callback_data' => '/setservice 9 0 ']]);
				}
				else {
					array_push($arrayserv,  [['text' => '❌ Деловые линии', 'callback_data' => '/setservice 9 1 ']]);
				}
					if ($json['10'] == '1') {
					array_push($arrayserv,  [['text' => '✅  ТК Энергия', 'callback_data' => '/setservice 10 0 ']]);
				}
				else {
					array_push($arrayserv,  [['text' => '❌  ТК Энергия', 'callback_data' => '/setservice 10 1 ']]);
				}
					if ($json['12'] == '1') {
					array_push($arrayserv,  [['text' => '✅  AUTO RU', 'callback_data' => '/setservice 12 0 ']]);
				}
				else {
					array_push($arrayserv,  [['text' => '❌  AUTO RU', 'callback_data' => '/setservice 12 1 ']]);
				}
					if ($json['13'] == '1') {
					array_push($arrayserv,  [['text' => '✅  DROM', 'callback_data' => '/setservice 13 0 ']]);
				}
				else {
					array_push($arrayserv,  [['text' => '❌  DROM', 'callback_data' => '/setservice 13 1 ']]);
				}
				if ($json['14'] == '1') {
					array_push($arrayserv,  [['text' => '✅  OLX KZ', 'callback_data' => '/setservice 14 0 ']]);
				}
				else {
					array_push($arrayserv,  [['text' => '❌  OLX KZ', 'callback_data' => '/setservice 14 1 ']]);
				}
                if ($json['15'] == '1') {
					array_push($arrayserv,  [['text' => '✅  Booking', 'callback_data' => '/setservice 15 0 ']]);
				}
				else {
					array_push($arrayserv,  [['text' => '❌  Booking', 'callback_data' => '/setservice 15 1 ']]);
				}
				
if ($json['16'] == '1') {
					array_push($arrayserv,  [['text' => '✅  DHL', 'callback_data' => '/setservice 16 0 ']]);
				}
				else {
					array_push($arrayserv,  [['text' => '❌  DHL', 'callback_data' => '/setservice 16 1 ']]);
				}

if ($json['17'] == '1') {
					array_push($arrayserv,  [['text' => '✅  PonyExpress', 'callback_data' => '/setservice 17 0 ']]);
				}
				else {
					array_push($arrayserv,  [['text' => '❌  PonyExpress', 'callback_data' => '/setservice 17 1 ']]);
				}







print_r(json_encode($arrayserv));


// 0 Юла
					// 1 Авито
					// 2 СДЭК
					// 3 ПЭК
					// 4 Боксберри
					// 5 Яндекс 
					// 6 Достависта
					// 7 AVITO Недвижимость
					// 8 YOULA Недвижимость
					// 9 Деловые линии
					// 10 ТК Энергия
					// 11 Почта РФ
					// 12 АВТО РУ
					// 13 ДРОМ
					// 14 OLX KZ
					// 15 Booking
					// 66 Проект
					// 16 DHL
					// 17 PonyExpress
?>