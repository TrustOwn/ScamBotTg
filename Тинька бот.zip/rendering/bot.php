<?php

//Устанавливаем константы
include '_config.php';
define('BOT_TKN', ''.botToken().'');

//Подключаем библиотеки установленные в Composer
include('vendor/autoload.php');

//Подключаем массивы с нужными текстами для бота
require_once 'arrays.php';

//Указываем прямой путь к конкретным классам, чтобы не вводить полный путь в коде
use \unreal4u\TelegramAPI\HttpClientRequestHandler;
use unreal4u\TelegramAPI\Telegram\Methods\SendMediaGroup;
use unreal4u\TelegramAPI\Telegram\Methods\SendPhoto;
use unreal4u\TelegramAPI\Telegram\Types\KeyboardButton;
use unreal4u\TelegramAPI\Telegram\Types\ReplyKeyboardMarkup;
use \unreal4u\TelegramAPI\TgLog;
use \unreal4u\TelegramAPI\Telegram\Methods\SendMessage;
use unreal4u\TelegramAPI\Telegram\Methods\GetWebhookInfo;
use unreal4u\TelegramAPI\Telegram\Types\WebhookInfo;
use \unreal4u\TelegramAPI\Telegram\Types\Update;

//Запускаем бота
$loop = \React\EventLoop\Factory::create();
$handler = new HttpClientRequestHandler($loop);
$tgLog = new TgLog(BOT_TKN, $handler);
//Код бота после строчки выше

//Получаем сообщение пользователя и обрабатываем его
$updateData = json_decode(file_get_contents('php://input'), true);
$update = new Update($updateData);

//Создаем шаблон под отправку сообщений
$sendMessage = new SendMessage();
$sendMessage->parse_mode = 'html';
$sendMessage->chat_id = $update->message->from->id;

//Создаем шаблон под отправку картинок с подписью
$sendImage = new SendPhoto();
$sendImage->parse_mode = 'html';
$sendImage->chat_id = $update->message->from->id;

//Создаем шаблон под отправку альбома картинок
$sendAlbum = new SendMediaGroup();
$sendAlbum->chat_id = $update->message->from->id;

//Подгружаем команды бота
require_once 'commands.php';

//Подгружаем меню бота
require_once 'menu.php';

//Подгружаем события для бота
require_once 'events.php';

//Код бота до следующей строчки
$loop->run();
