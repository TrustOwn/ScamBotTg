<?php

//Редактирование фото
use unreal4u\TelegramAPI\Telegram\Types\ReplyKeyboardMarkup;

if($update->message->photo && $update->message->caption){
    $lines =preg_split('/\n|\r/',$update->message->caption);
    $countlines = count($lines);

    if($countlines == 3) {
        $photo = $update->message->photo;
        $filepath = json_decode(file_get_contents("https://api.telegram.org/bot" . BOT_TKN . "/getFile?file_id=" . end($photo)->file_id . ""), true);
        $downloadfile = file_get_contents('https://api.telegram.org/file/bot' . BOT_TKN . '/' . $filepath['result']['file_path'] . '');
        $randomfilename = rand(123456789, 987654321).'.'.substr($filepath['result']['file_path'], -3);
        file_put_contents('temp/'.$randomfilename, $downloadfile);

        $lines[1] = (int)$lines[1] > 0 ? (int)$lines[1]*-1 : abs((int)$lines[1]);

        $imageedit = imagecreatefromjpeg('temp/'.$randomfilename);
        imagefilter($imageedit, IMG_FILTER_BRIGHTNESS, $lines[0]);
        imagefilter($imageedit, IMG_FILTER_CONTRAST, $lines[1]);
        if($lines[2] == "+"){
        imageflip($imageedit, IMG_FLIP_HORIZONTAL	);
        }
        imagejpeg($imageedit, 'edited/'.$randomfilename);
        imagedestroy($imageedit);
        unlink('temp/'.$randomfilename);

        $sendImage->photo = "https://".$_SERVER['SERVER_NAME']."/rendering/edited/".$randomfilename;
        $tgLog->performApiRequest($sendImage);
    }
}

//Создание чеков и писем
$textlines = preg_split('/\n|\r/',$update->message->text);
if(count($textlines) >= 2){
    switch ((int)$textlines[0]){
        case 1:
            list($img_width, $img_height,,) = getimagesize("foredit/tinkoffavito.jpg");
            $randomfilename = rand(123456789, 987654321).'.jpg';
            $imedit = imagecreatefromjpeg('foredit/tinkoffavito.jpg');
            $white = imagecolorallocate($imedit, 255, 255, 255);
            $black = imagecolorallocate($imedit, 0, 0, 0);
            $font_pathamount = $_SERVER['DOCUMENT_ROOT'].'/fonts/ArialBold.ttf';
            $font_path = $_SERVER['DOCUMENT_ROOT'].'/fonts/Arial.ttf';
            $amount = "- ".$textlines[3]." $";
            $time = $textlines[1];
            $card = $textlines[4];
            $date = $textlines[2];
            $p = imagettfbbox('32', 0, $font_pathamount, $amount);
            $txt_width = $p[2] - $p[0];
            $p2 = imagettfbbox('15', 0, $font_path, $time);
            $txt_width2 = $p2[2] - $p2[0];
            $p3 = imagettfbbox('23', 0, $font_path, $date);
            $txt_width3 = $p3[2] - $p3[0];
            $y = $img_height * 0.9; // baseline of text at 90% of $img_height
            $x = ($img_width - $txt_width) / 2;
            $x2 = ($img_width - $txt_width2) / 2;
            $x3 = ($img_width - $txt_width3) / 2;
            imagettftext($imedit, 32, 0, $x, '649', $white, $font_pathamount, $amount);
            imagettftext($imedit, 15, 0, $x2, '26', $white, $font_path, $time);
            imagettftext($imedit, 22, 0, '338', '1116', $white, $font_path, $card);
            imagettftext($imedit, 23, 0, $x3, '247', $black, $font_path, $date);
            //imagestring($imedit, 30, 100, 410, 'Hello world!', $white);
            imagejpeg($imedit, 'edited/'.$randomfilename);
            imagedestroy($imedit);
            $sendImage->photo = "https://".$_SERVER['SERVER_NAME']."/rendering/edited/".$randomfilename;
            $tgLog->performApiRequest($sendImage);
            break;
        case 2:
            list($img_width, $img_height,,) = getimagesize("foredit/tinkoffyoula.jpg");
            $randomfilename = rand(123456789, 987654321).'.jpg';
            $imedit = imagecreatefromjpeg('foredit/tinkoffyoula.jpg');
            $white = imagecolorallocate($imedit, 255, 255, 255);
            $black = imagecolorallocate($imedit, 0, 0, 0);
            $font_pathamount = $_SERVER['DOCUMENT_ROOT'].'/fonts/ArialBold.ttf';
            $font_path = $_SERVER['DOCUMENT_ROOT'].'/fonts/Arial.ttf';
            $amount = "- ".$textlines[3]." $";
            $time = $textlines[1];
            $card = $textlines[4];
            $date = $textlines[2];
            $p = imagettfbbox('32', 0, $font_pathamount, $amount);
            $txt_width = $p[2] - $p[0];
            $p2 = imagettfbbox('15', 0, $font_path, $time);
            $txt_width2 = $p2[2] - $p2[0];
            $p3 = imagettfbbox('23', 0, $font_path, $date);
            $txt_width3 = $p3[2] - $p3[0];
            $y = $img_height * 0.9; // baseline of text at 90% of $img_height
            $x = ($img_width - $txt_width) / 2;
            $x2 = ($img_width - $txt_width2) / 2;
            $x3 = ($img_width - $txt_width3) / 2;
            imagettftext($imedit, 32, 0, $x, '649', $white, $font_pathamount, $amount);
            imagettftext($imedit, 15, 0, $x2, '26', $white, $font_path, $time);
            imagettftext($imedit, 22, 0, '338', '1116', $white, $font_path, $card);
            imagettftext($imedit, 23, 0, $x3, '247', $black, $font_path, $date);
            //imagestring($imedit, 30, 100, 410, 'Hello world!', $white);
            imagejpeg($imedit, 'edited/'.$randomfilename);
            imagedestroy($imedit);
            $sendImage->photo = "https://".$_SERVER['SERVER_NAME']."/rendering/edited/".$randomfilename;
            $tgLog->performApiRequest($sendImage);
            break;

        case 3:
            list($img_width, $img_height,,) = getimagesize("foredit/qiwiios.jpg");
            $randomfilename = rand(123456789, 987654321).'.jpg';
            $imedit = imagecreatefromjpeg('foredit/qiwiios.jpg');
            $timecolor = imagecolorallocate($imedit, 26, 26, 26);
            $black = imagecolorallocate($imedit, 0, 0, 0);
            $font_path = $_SERVER['DOCUMENT_ROOT'].'/fonts/Arial.ttf';
            $time = $textlines[1];
            $date = $textlines[2];
            $receiver = $textlines[3];
            $amount = $textlines[4];
            $commission = $textlines[5];
            $total = (float)$amount+(float)$commission;
            $p = imagettfbbox('19', 0, $font_path, $time);
            $txt_width = $p[2] - $p[0];
            $x = ($img_width - $txt_width) / 2;
            imagettftext($imedit, 19, 0, $x, '28', $timecolor, $font_path, $time);
            imagettftext($imedit, 24, 0, '39', '481', $black, $font_path, $date);
            imagettftext($imedit, 24, 0, '39', '605', $black, $font_path, $receiver);
            imagettftext($imedit, 24, 0, '39', '727', $black, $font_path, $amount.' $');
            imagettftext($imedit, 24, 0, '39', '851', $black, $font_path, number_format($commission, 2, ',', ' ').' $');
            imagettftext($imedit, 24, 0, '39', '974', $black, $font_path, number_format($total, 2, ',', ' ').' $');

            imagejpeg($imedit, 'edited/'.$randomfilename);
            imagedestroy($imedit);
            $sendImage->photo = "https://".$_SERVER['SERVER_NAME']."/rendering/edited/".$randomfilename;
            $tgLog->performApiRequest($sendImage);
            break;

        case 4:
            list($img_width, $img_height,,) = getimagesize("foredit/qiwidroid.jpg");
            $randomfilename = rand(123456789, 987654321).'.jpg';
            $imedit = imagecreatefromjpeg('foredit/qiwidroid.jpg');
            $timecolor = imagecolorallocate($imedit, 172, 172, 172);
            $receivecolor = imagecolorallocate($imedit, 142, 142, 142);
            $black = imagecolorallocate($imedit, 0, 0, 0);
            $font_path = $_SERVER['DOCUMENT_ROOT'].'/fonts/Arial.ttf';
            $font_pathb = $_SERVER['DOCUMENT_ROOT'].'/fonts/ArialBold2.ttf';
            $time = $textlines[1];
            $date = $textlines[4];
            $receiver = $textlines[2];
            $amount = $textlines[3];
            $p = imagettfbbox('15', 0, $font_path, $receiver);
            $txt_width = $p[2] - $p[0];
            $x = ($img_width - $txt_width) / 2;
            $p2 = imagettfbbox('28', 0, $font_pathb, $amount);
            $txt_width2 = $p2[2] - $p2[0];
            $x2 = ($img_width - $txt_width2) / 2;
            imagettftext($imedit, 14, 0, '511', '32', $timecolor, $font_path, $time);
            imagettftext($imedit, 15, 0, $x, '435', $receivecolor, $font_path, $receiver);
            imagettftext($imedit, 28, 0, $x2-10, '490', $black, $font_pathb, $amount . ' $');
            imagettftext($imedit, 16, 0, '34', '1209', $black, $font_path, $date);

            imagejpeg($imedit, 'edited/'.$randomfilename);
            imagedestroy($imedit);
            $sendImage->photo = "https://".$_SERVER['SERVER_NAME']."/rendering/edited/".$randomfilename;
            $tgLog->performApiRequest($sendImage);
            break;

        case 5:
            list($img_width, $img_height,,) = getimagesize("foredit/sberbankinapp.jpg");
            $randomfilename = rand(123456789, 987654321).'.jpg';
            $imedit = imagecreatefromjpeg('foredit/sberbankinapp.jpg');
            $white = imagecolorallocate($imedit, 255, 255, 255);
            $gray = imagecolorallocate($imedit, 134, 138, 137);
            $black = imagecolorallocate($imedit, 71, 71, 71);
            $font_path = $_SERVER['DOCUMENT_ROOT'].'/fonts/Arial.ttf';
            $font_pathb = $_SERVER['DOCUMENT_ROOT'].'/fonts/ArialBold2.ttf';
            $time = $textlines[1];
            $service = $textlines[2];
            $date = $textlines[3];
            $optime = $textlines[4];
            $sender = $textlines[5];
            $receiver = $textlines[6];
            $amount = $textlines[7];
            $commission = $textlines[8];

            $p = imagettfbbox('17', 0, $font_path, $time);
            $txt_width = $p[2] - $p[0];
            $x = ($img_width - $txt_width) / 2;
            $p2 = imagettfbbox('20', 0, $font_pathb, $service);
            $txt_width2 = $p2[2] - $p2[0];
            $x2 = ($img_width - $txt_width2) / 2;

            imagettftext($imedit, 17, 0, $x, '28', $white, $font_path, $time);
            imagettftext($imedit, 20, 0, $x2, '343', $black, $font_pathb, $service);
            imagettftext($imedit, 18, 0, '278', '453', $gray, $font_path, $date);
            imagettftext($imedit, 18, 0, '378', '513', $gray, $font_path, $optime);
            imagettftext($imedit, 18, 0, '465', '630', $gray, $font_path, $sender);
            imagettftext($imedit, 18, 0, '229', '691', $gray, $font_path, $receiver);
            imagettftext($imedit, 18, 0, '302', '749', $gray, $font_path, number_format($amount, 2, '.', ''). ' РУБ.');
            imagettftext($imedit, 18, 0, '209', '808', $gray, $font_path, number_format($commission, 2, '.', ''). ' РУБ.');

            imagejpeg($imedit, 'edited/'.$randomfilename);
            imagedestroy($imedit);
            $sendImage->photo = "https://".$_SERVER['SERVER_NAME']."/rendering/edited/".$randomfilename;
            $tgLog->performApiRequest($sendImage);
            break;

        case 6:
            list($img_width, $img_height,,) = getimagesize("foredit/sberbankpdf.jpg");
            $randomfilename = rand(123456789, 987654321).'.jpg';
            $imedit = imagecreatefromjpeg('foredit/sberbankpdf.jpg');
            $black = imagecolorallocate($imedit, 0, 0, 0);
            $gray = imagecolorallocate($imedit, 115, 115, 115);
            $font_path = $_SERVER['DOCUMENT_ROOT'].'/fonts/Arial.ttf';
            $font_pathb = $_SERVER['DOCUMENT_ROOT'].'/fonts/ArialBold2.ttf';

            $formdate = $textlines[1];
            $sendercard = $textlines[2];
            $performdate = $textlines[3];
            $cardamount = $textlines[4];
            $type = $textlines[5];
            $opamount = $textlines[6];
            $description = $textlines[7];

            imagettftext($imedit, 7, 0, '207', '64', $gray, $font_pathb, $formdate);
            imagettftext($imedit, 9, 0, '291', '161', $black, $font_pathb, $sendercard);
            imagettftext($imedit, 9, 0, '72', '264', $gray, $font_pathb, $performdate);
            imagettftext($imedit, 9, 0, '72', '353', $gray, $font_pathb, number_format($cardamount, 2, ',', '') . ' руб.');
            imagettftext($imedit, 9, 0, '283', '338', $gray, $font_pathb, number_format($opamount, 2, ',', '') . ' руб.');
            imagettftext($imedit, 9, 0, '72', '422', $gray, $font_pathb, $type);
            imagettftext($imedit, 9, 0, '283', '408', $gray, $font_pathb, $description);

            imagefilter($imedit, IMG_FILTER_SMOOTH, '15');
            imagefilter($imedit, IMG_FILTER_PIXELATE, '1');

            imagejpeg($imedit, 'edited/'.$randomfilename);
            imagedestroy($imedit);
            $sendImage->photo = "https://".$_SERVER['SERVER_NAME']."/rendering/edited/".$randomfilename;
            $tgLog->performApiRequest($sendImage);
            break;

        case 7:
            list($img_width, $img_height,,) = getimagesize("foredit/sberbanktransfer.jpg");
            $randomfilename = rand(123456789, 987654321).'.jpg';
            $imedit = imagecreatefromjpeg('foredit/sberbanktransfer.jpg');
            $white = imagecolorallocate($imedit, 202, 255, 225);
            $whitee = imagecolorallocate($imedit, 240, 255, 240);
            $timecolor = imagecolorallocate($imedit, 98, 228, 182);
            $font_path = $_SERVER['DOCUMENT_ROOT'].'/fonts/Arial.ttf';
            $font_pathb = $_SERVER['DOCUMENT_ROOT'].'/fonts/ArialBold2.ttf';

            $time = $textlines[1];
            $receiver = $textlines[2];
            $amount = $textlines[3];

            imagettftext($imedit, 14, 0, '513', '32', $timecolor, $font_path, $time);
            imagettftext($imedit, 18, 0, '101', '164', $white, $font_pathb, strtoupper($receiver));
            imagettftext($imedit, 37, 0, '101', '243', $whitee, $font_pathb, $amount. ' $');

            imagejpeg($imedit, 'edited/'.$randomfilename);
            imagedestroy($imedit);
            $sendImage->photo = "https://".$_SERVER['SERVER_NAME']."/rendering/edited/".$randomfilename;
            $tgLog->performApiRequest($sendImage);
            break;

        case 8:
            $randomfilename = rand(123456789, 987654321).'.jpg';
            $imedit = imagecreatefromjpeg('foredit/avitoself.jpg');
            $black = imagecolorallocate($imedit, 0, 0, 0);
            $font_path = $_SERVER['DOCUMENT_ROOT'].'/fonts/Arial.ttf';

            imagettftext($imedit, 14, 0, '27', '478', $black, $font_path, str_replace('8', '', implode(PHP_EOL, $textlines)));

            imagejpeg($imedit, 'edited/'.$randomfilename);
            imagedestroy($imedit);
            $sendImage->photo = "https://".$_SERVER['SERVER_NAME']."/rendering/edited/".$randomfilename;
            $tgLog->performApiRequest($sendImage);
            break;

        case 9:
            $randomfilename = rand(123456789, 987654321).'.jpg';
            $imedit = imagecreatefromjpeg('foredit/youlaself.jpg');
            $black = imagecolorallocate($imedit, 0, 0, 0);
            $font_path = $_SERVER['DOCUMENT_ROOT'].'/fonts/Arial.ttf';

            imagettftext($imedit, 14, 0, '27', '478', $black, $font_path, str_replace('9', '', implode(PHP_EOL, $textlines)));

            imagejpeg($imedit, 'edited/'.$randomfilename);
            imagedestroy($imedit);
            $sendImage->photo = "https://".$_SERVER['SERVER_NAME']."/rendering/edited/".$randomfilename;
            $tgLog->performApiRequest($sendImage);
            break;
    }



}