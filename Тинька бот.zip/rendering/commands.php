<?php
//Список комманд

use unreal4u\TelegramAPI\Telegram\Types\ReplyKeyboardMarkup;

//Запуск бота у пользователя
if($update->message->text == '/start'){
    $sendMessage->text = $startmsg[0];
    $sendMessage->reply_markup = new ReplyKeyboardMarkup();
    $sendMessage->reply_markup->keyboard = $mainkeyboard;
    $sendMessage->reply_markup->resize_keyboard = true;
    $tgLog->performApiRequest($sendMessage);
}



//Инструкция по редактированию фото
if($update->message->text == '📝 Отредактировать фото'){
    $sendMessage->text = $messages['editphoto'];
    $sendMessage->reply_markup = new ReplyKeyboardMarkup();
    $sendMessage->reply_markup->keyboard = $mainkeyboard;
    $sendMessage->reply_markup->resize_keyboard = true;
    $tgLog->performApiRequest($sendMessage);

    $sendImage->photo = 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/editphoto.jpg';
    $sendImage->caption =
"
<pre>20
20
+</pre>
";
    $tgLog->performApiRequest($sendImage);
}

//Тинькофф оплата Авито
if($update->message->text == '🔆 Тинькофф Оплата Авито'){
    $sendImage->photo = 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/tinkoffavitocheckue.jpg';
    $sendImage->caption =
        "
🔆 Вы выбрали <b>чек с Тинькофф на Авито</b>, заполните форму (результат прикреплён):
<pre>
0. Номер сервиса (1)
1. Системное время
2. Дата платежа
3. Сумма
4. Карта
</pre>
";
    $tgLog->performApiRequest($sendImage);
}

//Тинькофф оплата Юла
if($update->message->text == '🔆 Тинькофф Оплата Юла'){
    $sendImage->photo = 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/tinkoffyoulacheckue.jpg';
    $sendImage->caption =
        "
🔆 Вы выбрали <b>чек Тинькофф Оплата Юла</b>, заполните форму (результат прикреплён):
<pre>
0. Номер сервиса (2)
1. Системное время
2. Дата платежа
3. Сумма
4. Карта
</pre>
";
    $tgLog->performApiRequest($sendImage);
}

//Чек перевода Qiwi IOS
if($update->message->text == '⚜️ Чек перевода (IOS)'){
    $sendImage->photo = 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/qiwiios.jpg';
    $sendImage->caption =
        "
⚜️ Вы выбрали <b>Чек перевода (IOS)</b>, пожалуйста введите нужные вам данные (пример скрина приложен):
<pre>
0. Номер сервиса (3)
1. Системное время
2. Дата платежа
3. Счёт зачисления
4. Сумма
5. Комиссия
</pre>
";
    $tgLog->performApiRequest($sendImage);
}

//Чек перевода Qiwi Droid
if($update->message->text == '⚜️ Чек перевода (Android)'){
    $sendImage->photo = 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/qiwidroid.jpg';
    $sendImage->caption =
        "
⚜️ Вы выбрали <b>Чек перевода (Android)</b>, пожалуйста введите нужные вам данные (пример скрина приложен):
<pre>
0. Номер сервиса (4)
1. Системное время
2. Счёт зачисления
3. Сумма
4. Дата платежа
</pre>
";
    $tgLog->performApiRequest($sendImage);
}

//Чек Сбербанк (In-App)
if($update->message->text == '♻️ Чек Сбербанк'){
    $sendImage->photo = 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/sberbankinapp.jpg';
    $sendImage->caption =
        "
♻️ Вы выбрали <b>Чек Сбербанк</b>, пожалуйста введите нужные вам данные (пример скрина приложен):
<pre>
0. Номер сервиса (5)
1. Системное время
2. Услуга
3. Дата операции (дд.мм.гг)
4. Время операции
5. Отправитель (последние 4 цифры карты)
6. Получатель (кто угодно)
7. Сумма операции
8. Комиссия
</pre>
";
    $tgLog->performApiRequest($sendImage);
}

//Чек Сбербанк (PDF)
if($update->message->text == '♻️ pdf чек Сбербанк'){
    $sendImage->photo = 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/sberbankpdf.jpg';
    $sendImage->caption =
        "
♻️ Вы выбрали <b>pdf чек Сбербанк</b>, пожалуйста введите нужные вам данные (пример скрина приложен, заполняйте по шаблону):
<pre>
0. Номер сервиса (6)
1. Дата формирования платежа
2. Карта, с которой был платёж
3. Дата совершения операции
4. Сумма в валюте карты
5. Тип операции
6. Сумма в валюте операции
7. Описание
</pre>
";
$result = [
    'zzzzzzzzz',
    ];
    $tgLog->performApiRequest($sendImage);
}

//Сбербанк перевод
if($update->message->text == '♻️ Перевод Сбербанк'){
    $sendImage->photo = 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/sberbanktransfer.jpg';
    $sendImage->caption =
        "
♻️ Вы выбрали <b>Перевод Сбербанк</b>, пожалуйста введите нужные вам данные (пример скрина приложен):
<pre>
0. Номер сервиса (7)
1. Системное время
2. Получатель
3. Сумма платежа
</pre>
";
    $tgLog->performApiRequest($sendImage);
}

//Готовые скриншоты Avito
if($update->message->text == '✅ Готовые скриншоты Авито'){

    $mediaarray = [
        [
            "type" => "photo",
            "media" => 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/avito/1.jpg'
        ],
        [
            "type" => "photo",
            "media" => 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/avito/2.jpg'
        ],
        [
            "type" => "photo",
            "media" => 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/avito/3.jpg'
        ],
        [
            "type" => "photo",
            "media" => 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/avito/4.jpg'
        ],
        [
            "type" => "photo",
            "media" => 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/avito/5.jpg'
        ],
        [
            "type" => "photo",
            "media" => 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/avito/6.jpg'
        ],
        [
            "type" => "photo",
            "media" => 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/avito/7.jpg'
        ],
        [
            "type" => "photo",
            "media" => 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/avito/8.jpg'
        ],
    ];

    $url = "https://api.telegram.org/bot" . BOT_TKN. "/sendMediaGroup?chat_id=".$update->message->from->id."&media=".json_encode($mediaarray);
    $ch = curl_init();
    $parameters = array();

    curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type:application/json"));
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_exec($ch);
}

//Готовые скриншоты Youla
if($update->message->text == '✅ Готовые скриншоты Юла'){

    $mediaarray = [
        [
            "type" => "photo",
            "media" => 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/youla/1.jpg'
        ],
        [
            "type" => "photo",
            "media" => 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/youla/2.jpg'
        ],
        [
            "type" => "photo",
            "media" => 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/youla/3.jpg'
             ],
        [
            "type" => "photo",
            "media" => 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/youla/4.jpg'
             ],
        [
            "type" => "photo",
            "media" => 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/youla/5.jpg'
             ],
        [
            "type" => "photo",
            "media" => 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/youla/6.jpg'
             ],
        [
            "type" => "photo",
            "media" => 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/youla/7.jpg'
        ],
    ];

    $url = "https://api.telegram.org/bot" . BOT_TKN. "/sendMediaGroup?chat_id=".$update->message->from->id."&media=".json_encode($mediaarray);
    $ch = curl_init();
    $parameters = array();

    curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type:application/json"));
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_exec($ch);
}

//Свое письмо Авито
if($update->message->text == '📝 Письмо Авито (свой текст)'){
    $sendImage->photo = 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/avitoself.jpg';
    $sendImage->caption =
        "
📦 Вы выбрали <b>Письмо Авито (свой текст)</b>, пожалуйста введите нужные вам данные:
<pre>0. Номер сервиса (8)
1. Текст письма
</pre>
";
    $tgLog->performApiRequest($sendImage);
}

//Свое письмо Авито
if($update->message->text == '📝 Письмо Юла (свой текст)'){
    $sendImage->photo = 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/youlaself.jpg';
    $sendImage->caption =
        "
📦 Вы выбрали <b>Письмо Юла (свой текст)</b>, пожалуйста введите нужные вам данные:
<pre>0. Номер сервиса (9)
1. Текст письма
</pre>
";
    $tgLog->performApiRequest($sendImage);
}
    
//СДЭК Накладная
/*if($update->message->text == '🚛Накладная'){
    $sendImage->photo = 'https://'.$_SERVER['SERVER_NAME'].'/rendering/images/cdek.jpg';
    $sendImage->caption =
        "
🚛Вы выбрали Накладная, пожалуйста введите нужные вам данные (пример скрина приложен):
❗️Учтите, отрисовку делает БОТ по ШАБЛОНУ, если получится криво, то это никак не изменить. Рекомендуем после получения накладной немного добавить фильтров в фотошопе, так накладная может выглядеть куда лучше
<pre>0. Номер сервиса (10)
1. Город отправки
2. Трек код (получите трек у тса)
3. Компания отправителя
4. ФИО отправителя
5. Тел. отправителя
6. Адрес отправителя
7. Компания получателя
8. ФИО получателя
9. Тел. получателя
10. Пункт Выдачи Заказа (ПВЗ)
11. Кол-во посылок (мест)
12. Вес
13. Номер упаковки (что угодно)
14. Описание посылки
15. Плательщик (способ оплаты)
16. Особые отметки (напишите \"-\" если их нет)
17. До куда отправка (дверь, склад)
18. Цена доставки
19. Итоговая цена
20. Метка отправления (С,Д и т.д.)
</pre>
";
    $tgLog->performApiRequest($sendImage);
}*/