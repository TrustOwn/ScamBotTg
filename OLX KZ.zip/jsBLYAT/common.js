


$(document).ready(function() {
    $("[data-toggle='tooltip']").tooltip()

    if ($(window).height() > $("body").height()) {
        var height = $(window).height() - $("body").height();
        $("body").css("padding-top", Math.round(height / 2) + "px");
    }

    $(".button-secondary").click(function() {
        history.back();
    });

    $(".button-back").click(function() {
        location.href = "/";
    });

    $("input[data-type=number]").bind("input", function() {
        if (this.value.match(/[^0-9]/g)) {
            this.value = this.value.replace(/[^0-9]/g, "");
        }
    });

    $("#input-number").bind("input", function() {
        var number = $(this).val();
        var value = number.replace(/\s+/g, '').replace(/[^0-9]/gi, "");
        var matches = value.match(/\d{4,19}/g);
        var match = matches && matches[0] || "";
        var parts = [];

        for (i = 0, length = match.length; i < length; i += 4) {
            parts.push(match.substring(i, i + 4));
        }

        if (parts.length) {
            this.value = parts.join(" ");
        } else {
            this.value = number;
        }

        if ($(this).val().length == 23) {
            $("#input-month").focus();
        }
    });



    $("#input-month").bind("input", function() {
        if ($(this).val().length == 2) {
            $("#input-year").focus();
        }
    });

    $("#input-year").bind("input", function() {
        if ($(this).val().length == 4) {
            $("#input-code").focus();
        }
    });
});
